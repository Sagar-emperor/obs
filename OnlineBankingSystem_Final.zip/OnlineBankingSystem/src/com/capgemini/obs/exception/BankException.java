package com.capgemini.obs.exception;

public class BankException extends Exception {

	private static final long serialVersionUID = 3474054013029539371L;
	
	public BankException(String message) {
		
		super(message);		

	}
	
}
