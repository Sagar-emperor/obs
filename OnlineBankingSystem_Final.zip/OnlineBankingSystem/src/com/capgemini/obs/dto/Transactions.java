package com.capgemini.obs.dto;

import java.time.LocalDate;

public class Transactions {
	
	private long transactionId;
	private String tranDescription;
	private  LocalDate dateOfTransaction;
	private String transactionType;
	private long tranAmount;
	private long accountId;
	
	
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public String getTranDescription() {
		return tranDescription;
	}
	public void setTranDescription(String tranDescription) {
		this.tranDescription = tranDescription;
	}
	public LocalDate getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(LocalDate dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public long getTranAmount() {
		return tranAmount;
	}
	public void setTranAmount(long tranAmount) {
		this.tranAmount = tranAmount;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	
	
	

}
