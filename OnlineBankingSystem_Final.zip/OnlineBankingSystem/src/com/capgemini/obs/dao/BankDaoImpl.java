package com.capgemini.obs.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import java.util.ArrayList;
import java.util.List;

import com.capgemini.obs.dto.AccountMaster;
import com.capgemini.obs.dto.Customer;
import com.capgemini.obs.dto.FundTransfer;
import com.capgemini.obs.dto.Payees;
import com.capgemini.obs.dto.ServiceTracker;
import com.capgemini.obs.dto.Transactions;
import com.capgemini.obs.dto.User;
import com.capgemini.obs.exception.BankException;
import com.capgemini.obs.util.DBConnection;

public class BankDaoImpl implements IBankDao {

	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	
	public BankDaoImpl() throws BankException{
		
		connection = DBConnection.getInstance().getConnection();

	}
	
	@Override
	public boolean isValidUser(long accountNumber, String password,String loginTable) throws BankException {
	
		boolean isValidUser = false;
		
		try {
			
			// checking the user exists or not 
			
			preparedStatement = connection.prepareStatement(QueryMapper.VALID_USER.replace("$tableName", loginTable));
			
			preparedStatement.setLong(1, accountNumber);
			resultSet = preparedStatement.executeQuery();
			
			if (resultSet.next()) {
				// if the user exists check the password is correct
				preparedStatement = connection.prepareStatement(QueryMapper.VALID_USER_PASSWORD.replace("$tableName", loginTable));
				preparedStatement.setLong(1, accountNumber);
				preparedStatement.setString(2, password);
				resultSet = preparedStatement.executeQuery();
				
				if (resultSet.next()) {
					//if the account number and password is correct
					isValidUser = true;
					
				} else {
					//if the account number and password is incorrect
					isValidUser = false;
					
				}
								
			} else {
				// users not found 
				throw (new BankException("\nUser with Account number : "+accountNumber+" does not exist\n"));
				
			}
			
		} catch (SQLException e) {
			//Sql Exception 
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		} 
		// if the Account number and password is correct then true otherwise false return 
		return isValidUser;
	}
	
	@Override
	public int getUserAttempts(long accountNumber,String loginTable) throws BankException {
		
		int attempts = 0;
		
		try {
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.PASSWORD_ATTEMPTS.replace("$tableName", loginTable));
			preparedStatement.setLong(1, accountNumber);
			resultSet = preparedStatement.executeQuery();
			
			// checking if data found in query for id
			if (resultSet.next()) {
				// if attempts are here
				attempts = resultSet.getInt(1);
				
			
			} 		
			
			
		} catch (SQLException e) {
			//Sql Exception 
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} finally {
			
			// releasing the connections and objects
			resultSet = null;
			preparedStatement = null;
			connection = null;			
		}
		
		
		return attempts;
	
	}

	@Override
	public void lockAccount(long accountNumber,String loginTable) throws BankException {
	
		//int result=0;
		try {
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.LOCK_ACCOUNT.replace("$tableName", loginTable));
			preparedStatement.setLong(1, accountNumber);
			//result = preparedStatement.executeUpdate();
			preparedStatement.executeUpdate();
			
		
			
		} catch (SQLException e) {
			
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} finally {
			
			resultSet = null;
			preparedStatement = null;
			connection = null;
			
		}
		
		
	}

	@Override
	public void setUserAttempts(long accountNumber,String loginTable) throws BankException {
	
		
		//int result=0;
		try {
			connection = DBConnection.getInstance().getConnection();
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.SETPASSWORD_ATTEMPTS.replace("$tableName", loginTable));
			preparedStatement.setLong(1, accountNumber);
			//result = preparedStatement.executeUpdate();
			preparedStatement.executeUpdate();
			
		
			
		} catch (SQLException e) {
			//Sql Exception 
			throw (new BankException("\nTechnical Error, Unable to Connect durin setting\n"));
			
			
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} finally {
			
			// releasing the connections and objects
			resultSet = null;
			preparedStatement = null;
			connection = null;
	
		}
	}

	@Override
	public String getUserQuestion(long accountNumber,String loginTable) throws BankException {
        
		String question = null;
		
		try {

			connection = DBConnection.getInstance().getConnection();
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.GET_QUESTION.replace("$tableName", loginTable));
			preparedStatement.setLong(1, accountNumber);
			resultSet = preparedStatement.executeQuery();


			if (resultSet.next()) {
				question = resultSet.getString("secret_question");
			
			} 		
			
			
		} catch (SQLException e) {
			//Sql Exception 
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} finally {
			
			// releasing the connections and objects
			resultSet = null;
			preparedStatement = null;
			connection = null;

		}
		
		
		return question;
	}

	@Override
	public boolean isValidTransactionPassword(String transactionpassword,long accountNumber,String loginTable) throws BankException {
		
		
		String transactpassword=null;
		boolean isValidTransactionPassword=false;
		
		
		try {
			connection = DBConnection.getInstance().getConnection();
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.TRANSACTION_PASSWORD.replace("$tableName", loginTable));
			preparedStatement.setLong(1, accountNumber);
			resultSet = preparedStatement.executeQuery();
			
			// checking if data found in query for id
			if (resultSet.next()) {
				// if attempts are here
				transactpassword = resultSet.getString(1);
				
				if(transactpassword.equals(transactionpassword))
				{
					
					isValidTransactionPassword=true;
				}
				else
					isValidTransactionPassword=false;
			
			} 		
			
			
			
			
		} catch (SQLException e) {
			//Sql Exception 
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} finally {
			
			// releasing the connections and objects
			resultSet = null;
			preparedStatement = null;
			connection = null;

		}
		
		return isValidTransactionPassword;
		
	}

	@Override
	public void unLockAccount(long accountNumber,String loginTable) throws BankException {
		
		//ResultSet resultSet =null;
		
		try {

			preparedStatement=null;
			connection = DBConnection.getInstance().getConnection();
			preparedStatement = connection.prepareStatement(QueryMapper.UNLOCK_ACCOUNT.replace("$tableName", loginTable));

			preparedStatement.setLong(1, accountNumber);
			//resultSet = preparedStatement.executeQuery();
			preparedStatement.executeQuery();
			
			
		} catch (SQLException e) {
			//sql exception
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} finally {
		
			resultSet = null;
			preparedStatement = null;
			connection = null;
			
		}
		
	}
	
	@Override
	public void updatePassword(long accountNumber,String newPassword,String loginTable) throws BankException {
		
		//int result=0;
		try {
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_PASSWORD.replace("$tableName", loginTable));
			preparedStatement.setString(1, newPassword);
			preparedStatement.setLong(2, accountNumber);
			//result = preparedStatement.executeUpdate();
			preparedStatement.executeUpdate();
			
		
			
		} catch (SQLException e) {
			//Sql Exception 
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} finally {
			
			// releasing the connections and objects
			resultSet = null;
			preparedStatement = null;
			connection = null;
			
		}
		
		
		
	}

	@Override
	public boolean isLockedAccount(long accountNumber,String loginTable) throws BankException {

	
		String lockStatus=null;
		boolean isLockedAccount=false;
		connection = DBConnection.getInstance().getConnection();
		
		try {
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.LOCK_STATUS.replace("$tableName", loginTable));
			preparedStatement.setLong(1, accountNumber);
			resultSet = preparedStatement.executeQuery();
			
			// checking if data found in query for id
			if (resultSet.next()) {
				// if attempts are here
				lockStatus = resultSet.getString(1).trim();
				
				if(lockStatus.equals("L")) {
				
					isLockedAccount=true;
				
				}
				else {
					
					isLockedAccount=false;
				}
			} 		
			
		} catch (SQLException e) {
			//Sql Exception
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		}catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} finally {
			
			// releasing the connections and objects
			resultSet = null;
			preparedStatement = null;
			connection = null;

		}
		
		
		return isLockedAccount;
		
	}

	@Override
	public void setUserAttemptsZero(long accountNumber,String loginTable) throws BankException {
		
		//int result=0;
		
		try {
			connection = DBConnection.getInstance().getConnection();
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.SETPASSWORD_ATTEMPTS_ZERO.replace("$tableName", loginTable));
			preparedStatement.setLong(1, accountNumber);
			//result = preparedStatement.executeUpdate();
			preparedStatement.executeUpdate();
			
		
			
		} catch (SQLException e) {
			//Sql Exception 

			throw (new BankException("\nTechnical Error, Unable to Connect durin setting\n"));
			
			
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} finally {
			
			// releasing the connections and objects
			resultSet = null;
			preparedStatement = null;
			connection = null;
				
		}
		
	}

	@Override
	public long createAccount(AccountMaster accountMaster, User user, Customer customer) throws BankException {
		
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;	
		PreparedStatement preparedStatement1=null;
		PreparedStatement preparedStatement2=null;	
		PreparedStatement preparedStatement3=null;
		ResultSet resultSet = null;
		
		long accountID =0;
		
		int queryResult=0;
		
		try
		{	
			
			//--------------------------------------------------------------------------------------------
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_USER_QUERY);
			
			preparedStatement.setString(1,user.getLoginPass());
			preparedStatement.setString(2,user.getSecretQuestion());
			preparedStatement.setString(3,user.getTransactionPassword());
			preparedStatement.setString(4,"A");
			
			queryResult=preparedStatement.executeUpdate();
			//--------------------------------------------------------------------------------------------
			
			

			//--------------------------------------------------------------------------------------------
			preparedStatement1=connection.prepareStatement(QueryMapper.INSERT_ACCOUNT_QUERY);
		
			preparedStatement1.setString(1,accountMaster.getAccountType());
			preparedStatement1.setLong(2,accountMaster.getAccountBalance());	
								
			queryResult=preparedStatement1.executeUpdate();
			//--------------------------------------------------------------------------------------------
			
			
			

			//--------------------------------------------------------------------------------------------
			preparedStatement3=connection.prepareStatement(QueryMapper.INSERT_CUSTOMER_QUERY);
		 
		 	preparedStatement3.setString(1, customer.getCustomerName());
		 	preparedStatement3.setString(2, customer.getEmail());
		 	preparedStatement3.setString(3, customer.getAddress());
		 	preparedStatement3.setString(4, customer.getPancard());
		 	preparedStatement3.setString(5,customer.getMobileNumber());
			
		 	queryResult=preparedStatement3.executeUpdate();
			//--------------------------------------------------------------------------------------------
			
			

			//--------------------------------------------------------------------------------------------
			preparedStatement2 = connection.prepareStatement(QueryMapper.ACCOUNTID_QUERY_SEQUENCE);
			resultSet=preparedStatement2.executeQuery();
			//--------------------------------------------------------------------------------------------
			
			
			
			if(resultSet.next()) { 
				
				accountID=resultSet.getLong(1);
						
			}
	
			if(queryResult==0) {
				
				throw new BankException("Inserting donor details failed ");

			}
			else {
			
				return accountID;
			}

		}
		catch(SQLException sqlException) {
	
			throw new BankException("\nTechnical Error, Unable to Connect durin setting\n");
		
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} finally {
			
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				
				throw new BankException("Error in closing db connection");

			}
		}
	}

	@Override
	public List<Transactions> viewMiniStateMent(long accountNum)throws BankException {
		
		List< Transactions> trList = new ArrayList<Transactions>();
		try {
			
			Connection connection = DBConnection.getInstance().getConnection();
	
			preparedStatement = connection.prepareStatement(QueryMapper.MINI_STATEMENTS);
			preparedStatement.setLong(1, accountNum);
			resultSet = preparedStatement.executeQuery();
			
			
			int rowNum = 1;
			Transactions transaction = new Transactions();
			
			while(resultSet.next()){
			
				if(rowNum <= 10){
					transaction.setTransactionId(resultSet.getLong(1));
					transaction.setTranDescription(resultSet.getString(2));
					transaction.setDateOfTransaction(resultSet.getDate(3).toLocalDate());
					transaction.setTransactionType(resultSet.getString(4));
					transaction.setTranAmount(resultSet.getLong(5));
					transaction.setAccountId(accountNum);
					trList.add(transaction);
					transaction = new Transactions();
					
					rowNum++;
				}
		
			}
			
		}

		catch(SQLException sqlException) {

			throw new BankException("\nTechnical Error, Unable to Connect durin setting\n");
		
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} 
		
		if(trList == null || trList.isEmpty()){
		
			return null;
		
		} else {
		
			return trList;
		
		}
	}

	@Override
	public List<Transactions> viewDetailedStatement(long accountNum,
			Date startDate, Date endDate) throws BankException {
		List< Transactions> trList = new ArrayList<Transactions>();
		
		
		try {
			PreparedStatement preparedStatementTran = null;
			Connection connection = DBConnection.getInstance().getConnection();
	
			preparedStatement = connection.prepareStatement(QueryMapper.PANCARD_ACCOUNT_NUM);
			preparedStatement.setLong(1, accountNum);
			resultSet = preparedStatement.executeQuery();
			
			
			ResultSet resultTran = null;
			long accNum=0l;
			while(resultSet.next()){
				
				accNum = resultSet.getLong(1);
				preparedStatementTran = connection.prepareStatement(QueryMapper.DETAILED_STATEMENTS);
				preparedStatementTran.setLong(1, accNum);
				preparedStatementTran.setDate(2, new java.sql.Date(startDate.getTime()));
				preparedStatementTran.setDate(3, new java.sql.Date(endDate.getTime()));
				resultTran = preparedStatementTran.executeQuery();
				
				Transactions transaction = new Transactions();	
				while(resultTran.next()){
					
					transaction.setTransactionId(resultTran.getLong(1));
					transaction.setTranDescription(resultTran.getString(2));
					transaction.setDateOfTransaction(resultTran.getDate(3).toLocalDate());
					transaction.setTransactionType(resultTran.getString(4));
					transaction.setTranAmount(resultTran.getLong(5));
					transaction.setAccountId(accNum);
					trList.add(transaction);
					transaction = new Transactions();
				}
			}			
		}
		
		catch(SQLException sqlException){
			
			throw new BankException(sqlException.getMessage());
		}
		
		if(trList == null || trList.isEmpty()){
			return null;
		} else {
			return trList;
		}
	}

	@Override
	public Customer getCustomerDetails(long accountNumber) throws BankException {
		
		Connection connection=DBConnection.getInstance().getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		Customer bean=	new Customer();
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BANK_DETAILS_QUERY);
			preparedStatement.setLong(1,accountNumber);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
			
				bean.setAccountId(resultset.getLong(1));
				bean.setCustomerName((resultset.getString(2)));
				bean.setEmail((resultset.getString(3)));
				bean.setAddress((resultset.getString(4)));
				bean.setPancard((resultset.getString(5)));
				bean.setMobileNumber(resultset.getString(6));
				
			}
		 return bean;
			
		} catch(SQLException sqlException) {

			throw new BankException("\nTechnical Error, Unable to Connect durin setting\n");
		
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} 
		finally
		{
			
			resultset = null;
			preparedStatement= null;
			connection= null;
			
		}
	}

	@Override
	public int updateMobileNumber(long accountNumber, String newMobileNumber) throws BankException {
		
		Connection conn=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		int resultset2=0;
		
		
		try {
			
			preparedStatement = conn.prepareStatement(QueryMapper.UPDATE_MOBILE_NUMBER);
			preparedStatement.setString(1,newMobileNumber);
			preparedStatement.setLong(2,accountNumber);
			resultset2 = preparedStatement.executeUpdate();

		} catch(SQLException sqlException) {
	
			throw new BankException("\nTechnical Error, Unable to Connect durin setting\n");
		
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} 
		finally {
			
			preparedStatement= null;
			connection= null;
			
		}
		
		return resultset2;
	}

	@Override
	public int updateAddress(long accountNumber, String newAddress) throws BankException {
		
		Connection conn=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		int resultset2=0;
		
		//TrainBean bean = new TrainBean();
		try {
			
			preparedStatement = conn.prepareStatement(QueryMapper.UPDATE_MOBILE_NUMBER);
			preparedStatement.setString(1,newAddress);
			preparedStatement.setLong(2,accountNumber);
			resultset2 = preparedStatement.executeUpdate();

		}  catch(SQLException sqlException) {

			throw new BankException("\nTechnical Error, Unable to Connect durin setting\n");
		
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} 
		finally	{

			preparedStatement= null;
			connection= null;
			
		}
		
		return resultset2;
	}

	@Override
	public boolean requestCheckBook(ServiceTracker serviseTracker) throws BankException {
		Connection conn = null;
		PreparedStatement preparedStatement=null;
		int isInserted = 0;
		boolean isInsertedValues = false;
		
		try {
			conn = DBConnection.getInstance().getConnection();
			preparedStatement = conn.prepareStatement(QueryMapper.INSERT_REQUEST);
			preparedStatement.setString(1, serviseTracker.getServiceDescription());
			preparedStatement.setLong(2, serviseTracker.getAccountId());
			preparedStatement.setString(3, serviseTracker.getServiceStatus());
			
			isInserted= preparedStatement.executeUpdate();
			
			if(isInserted != 0){
				isInsertedValues= true;
			}else{
				isInsertedValues= false;
						
			}
		
		} catch(SQLException sqlException) {
		
			throw new BankException("\nTechnical Error, Unable to Connect durin setting\n");
		
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} 
		finally
		{
			
			preparedStatement= null;
			connection= null;
			
		}
		
		
		return isInsertedValues;
		
	}

	@Override
	public boolean checkRequestAvailable(long accountId) throws BankException{
		
		Connection conn = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		boolean isAvailable = false;
		
		//TrainBean bean = new TrainBean();
		try {
			
			preparedStatement = conn.prepareStatement(QueryMapper.CHECK_SERVICE);
			preparedStatement.setLong(1,accountId);
			
			resultset = preparedStatement.executeQuery();

			if(resultset.next()){
				isAvailable = true;
			}
		}  catch(SQLException sqlException) {

			throw new BankException("\nTechnical Error, Unable to Connect durin setting\n");
		
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} 
		finally
		{
			
			resultset = null;
			preparedStatement= null;
			connection= null;
			
		}
		
		return isAvailable;
		
	}

		@Override
	public ServiceTracker trackServiceRequest(long accountNumber)

				throws BankException {
			Connection conn = null;
			PreparedStatement preparedStatement=null;
			ResultSet resultset = null;
			ServiceTracker serviceTracker = null;
			
			try {
				conn=DBConnection.getInstance().getConnection();
				preparedStatement=conn.prepareStatement(QueryMapper.SELECT_REQUEST);
				preparedStatement.setLong(1, accountNumber);
				resultset = preparedStatement.executeQuery();
				
				if(resultset.next())
				{
					serviceTracker = new ServiceTracker();
					serviceTracker.setServiceId(resultset.getInt(1));
					serviceTracker.setServiceDescription(resultset.getString(2));
					serviceTracker.setAccountId(accountNumber);
					serviceTracker.setServiceRaisedDate(resultset.getDate(3).toLocalDate());
					serviceTracker.setServiceStatus(resultset.getString(4));
				}
				
				
			} catch(SQLException sqlException) {
				
				throw new BankException("\nTechnical Error, Unable to Connect durin setting\n");
			
			} catch (Exception e) {
				//unknown Exception 
				throw (new BankException("\nUnknown Error\n"));
				
			} 
			finally
			{
				
				resultset = null;
				preparedStatement= null;
				connection= null;
				
			}
			return serviceTracker;
		}

		@Override
	public List<Transactions> getTransactions(String transactionType,
				long accountNumber,int number ) throws BankException {
			
			Connection conn = null;
			PreparedStatement preparedStatement=null;
			ResultSet resultset = null;
			List<Transactions> listTransactions = new ArrayList<Transactions>();
			
			try {
				conn = DBConnection.getInstance().getConnection();
				if(transactionType.equals("daily"))
					preparedStatement = conn.prepareStatement(QueryMapper.VIEW_TRANSACTION_BY_DAILY);
				
				else if (transactionType.equals("monthly"))
					preparedStatement = conn.prepareStatement(QueryMapper.VIEW_TRANSACTION_BY_MONTH);
				
				else if (transactionType.equals("yearly"))
					preparedStatement = conn.prepareStatement(QueryMapper.VIEW_TRANSACTION_BY_YEAR);
				
				
				preparedStatement.setInt(1,number);
				resultset = preparedStatement.executeQuery();
				
				Transactions transaction = new Transactions();
				
				while(resultset.next()){
					transaction.setTransactionId(resultset.getInt(1));
					transaction.setTranDescription(resultset.getString(2));
					transaction.setDateOfTransaction(resultset.getDate(3).toLocalDate());
					transaction.setTransactionType(resultset.getString(4));
					transaction.setTranAmount(resultset.getLong(5));
					transaction.setAccountId(resultset.getLong(6));
					listTransactions.add(transaction);
					transaction = new Transactions();
				}
				
			} catch(SQLException sqlException) {
			
				throw new BankException("\nTechnical Error, Unable to Connect durin setting\n");
			
			} catch (Exception e) {
				//unknown Exception 
				throw (new BankException("\nUnknown Error\n"));
				
			} 
			finally
			{
				
				resultset = null;
				preparedStatement= null;
				connection= null;
				
			}
			
			
			return listTransactions;
		}

	@Override
	public List<Long> getAccountNumbers(long accountNumber)
				throws BankException {
			Connection conn = null;
			PreparedStatement preparedStatement=null;
			ResultSet resultset = null;
			List<Long> listAccount = new ArrayList<Long>();
			try {
				
				conn = DBConnection.getInstance().getConnection();
				preparedStatement = conn.prepareStatement(QueryMapper.PANCARD_ACCOUNT_NUM);
				preparedStatement.setLong(1, accountNumber);
				resultset = preparedStatement.executeQuery();
				
				
				while(resultset.next()){
					
					listAccount.add(resultset.getLong(1));
					
				}
				
				
			} catch(SQLException sqlException) {
			
				throw new BankException("\nTechnical Error, Unable to Connect durin setting\n");
			
			} catch (Exception e) {
				//unknown Exception 
				throw (new BankException("\nUnknown Error\n"));
				
			} 
			finally
			{
				
				resultset = null;
				preparedStatement= null;
				connection= null;
				
			}
			return listAccount;
		}

	@Override
	public List<Payees> getAllPayees(long bankAccountNumber)
				throws BankException {
			Connection conn = null;
			PreparedStatement preparedStatement=null;
			ResultSet resultset = null;
			List<Payees> payeeList = new ArrayList<Payees>();
			
			try {
				
				conn = DBConnection.getInstance().getConnection();
				preparedStatement = conn.prepareStatement(QueryMapper.GET_ALL_PAYEE);
				preparedStatement.setLong(1, bankAccountNumber);
				resultset = preparedStatement.executeQuery();
				
				Payees payees = new Payees();
				
				while(resultset.next()){
					
					payees.setAccountId(bankAccountNumber);
					payees.setPayeeAccountId(resultset.getLong(1));
					payees.setNickName(resultset.getString(2));
					payeeList.add(payees);
					payees = new Payees();
				
				}		
				
			} catch(SQLException sqlException) {
			
				throw new BankException("\nTechnical Error, Unable to Connect durin setting\n");
			
			} catch (Exception e) {
				//unknown Exception 
				throw (new BankException("\nUnknown Error\n"));
				
			} 
			finally
			{
				
				resultset = null;
				preparedStatement= null;
				connection= null;
				
			}
			return payeeList;
		}

	@Override
	public FundTransfer fundTransfer(long bankAccountNumber,
				long payeeAccountNumber,long transferAmount) throws BankException {

			Connection conn = null;
			PreparedStatement preparedStatementSelf=null;
			PreparedStatement preparedStatementPayee=null;
			PreparedStatement preparedStatementTransfer = null;
			PreparedStatement preparedStatementTransactionDebit = null;
			PreparedStatement preparedStatementTransactionCredit = null;
			
			FundTransfer fundTransfer = new FundTransfer();
			
			int insertedRows = 0;
			
			try {
				conn = DBConnection.getInstance().getConnection();
				int isDeducted = 0;
				int isIncremented = 0;
				
				preparedStatementSelf = conn.prepareStatement(QueryMapper.BALANCE_DEDUCTION);
				preparedStatementSelf.setLong(1, transferAmount); 
				preparedStatementSelf.setLong(2, bankAccountNumber);
				isDeducted = preparedStatementSelf.executeUpdate();
				
				
				preparedStatementPayee = conn.prepareStatement(QueryMapper.BALANCE_INCREMENT);
				preparedStatementPayee.setLong(1, transferAmount); 
				preparedStatementPayee.setLong(2, payeeAccountNumber);
				isIncremented = preparedStatementPayee.executeUpdate();				
				
				
				
				if(isIncremented > 0 && isDeducted > 0){

					preparedStatementTransfer = conn.prepareStatement(QueryMapper.FUND_TRANSFER);
					preparedStatementTransfer.setLong(1, bankAccountNumber);
					preparedStatementTransfer.setLong(2, payeeAccountNumber);
					preparedStatementTransfer.setLong(3, transferAmount);
					
					insertedRows = preparedStatementTransfer.executeUpdate();
					
					if(insertedRows > 0 ){

						fundTransfer.setAccountId(bankAccountNumber);
						fundTransfer.setPayeeAccountId(payeeAccountNumber);
						fundTransfer.setTranferAmmount(transferAmount);
						
					}
					

					preparedStatementTransactionDebit = conn.prepareStatement(QueryMapper.TRANSFER);
					preparedStatementTransactionDebit.setString(1, "Online Fund Transfer");
					preparedStatementTransactionDebit.setString(2, "D");
					preparedStatementTransactionDebit.setLong(3, transferAmount);
					preparedStatementTransactionDebit.setLong(4, bankAccountNumber);
					preparedStatementTransactionDebit.executeUpdate();

					preparedStatementTransactionCredit = conn.prepareStatement(QueryMapper.TRANSFER);
					preparedStatementTransactionCredit.setString(1, "Online Fund Transfer");
					preparedStatementTransactionCredit.setString(2, "C");
					preparedStatementTransactionCredit.setLong(3, transferAmount);
					preparedStatementTransactionCredit.setLong(4, payeeAccountNumber);
					preparedStatementTransactionCredit.executeUpdate();
					
					
				}
				
				
			} catch(SQLException sqlException) {
				
				throw new BankException("\nTechnical Error, Unable to Connect durin setting\n");
			
			} catch (Exception e) {
				//unknown Exception 
				throw (new BankException("\nUnknown Error\n"));
				
			} 
			finally	{
				
				preparedStatement= null;
				connection= null;
				
			}
			
			return fundTransfer;
		}

	@Override
	public long isAmountTransferable(long bankAccountNumber,
			long transferAmmount) throws BankException {
		
		Connection conn = null;
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		long accountBalance=0;
	
		try
		{
		conn = DBConnection.getInstance().getConnection();
		preparedStatement = conn.prepareStatement(QueryMapper.GET_AMOUNT);
		preparedStatement.setLong(1, bankAccountNumber);
		resultset = preparedStatement.executeQuery();
		
		while(resultset.next()){
			
			accountBalance=resultset.getLong(1);
		
		}
		
		
		
		} catch(SQLException sqlException) {
			
			throw new BankException("\nTechnical Error, Unable to Connect durin setting\n");
		
		} catch (Exception e) {
			//unknown Exception 
			throw (new BankException("\nUnknown Error\n"));
			
		} 
		finally
		{
			
			resultset = null;
			preparedStatement= null;
			connection= null;
			
		}
		
		
		return accountBalance;
	}
		
		
}
		
		
		
	

