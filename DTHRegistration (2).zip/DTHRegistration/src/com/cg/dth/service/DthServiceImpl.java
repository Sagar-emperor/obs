package com.cg.dth.service;

import com.cg.dth.bean.DthBean;
import com.cg.dth.dao.DthDaoImpl;
import com.cg.dth.dao.IDthDao;
import com.cg.dth.exception.DthException;

public class DthServiceImpl implements IDthService{
	IDthDao dthDao = new DthDaoImpl();

	@Override
	public void addCustomer(DthBean dto) throws DthException {
		// TODO Auto-generated method stub
		dthDao.addCustomer(dto);
	}

	

	
}
