package com.cg.dth.service;

import com.cg.dth.bean.DthBean;
import com.cg.dth.exception.DthException;

public interface IDthService {

	public void addCustomer(DthBean dto) throws DthException;

	
	
}
