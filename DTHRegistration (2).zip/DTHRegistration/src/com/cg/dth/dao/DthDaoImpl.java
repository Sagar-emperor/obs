package com.cg.dth.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dth.bean.DthBean;
import com.cg.dth.exception.DthException;
import com.cg.dth.utility.DbConnection;

public class DthDaoImpl implements IDthDao {
	
	PreparedStatement preparedStatement = null;
	Connection conn = null;
	ResultSet resultSet = null;
	DthBean dto = null;
	
	public void addCustomer(DthBean dto) throws DthException {
		// TODO Auto-generated method stub
		int result = 0;
		
		try {
		
			
				conn = DbConnection.getConnection();
			
			preparedStatement = conn.prepareStatement(QueryMapper.INSERTQUERY);
		
			//preparedStatement.setInt(1, bean.getBill_num());
				preparedStatement.setString(1, dto.getCustomerName());
				preparedStatement.setString(2, dto.getUserName());
				preparedStatement.setString(3, dto.getPassword());
				//preparedStatement.setDate(4, java.sql.Date.valueOf(dto.getJourneyDate()));
				preparedStatement.setString(4, dto.getMobileNumber());
				//preparedStatement.setDouble(5, dto.getAmount());	
				//preparedStatement.setDate(5, java.sql.Date.valueOf(dto.getBillDate()));
				//System.out.println(dto.getCustomerName()+" "+dto.getUserName()+" "+dto.getPassword()+""+dto.getMobileNumber()+""+dto.getAmount());
				
				result = preparedStatement.executeUpdate();
				
				

				

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Invalid USer");
		}

		
		
	}
}
