package com.cg.dth.dao;

import com.cg.dth.bean.DthBean;
import com.cg.dth.exception.DthException;

public interface IDthDao {


	public void addCustomer(DthBean dto) throws DthException;
}

