package com.cg.dth.dao;

public class QueryMapper {
	public static String INSERTQUERY ="INSERT INTO CUSTOMER(customer_name,user_name,password,mobile_number) VALUES(?,?,?,?)";
}
