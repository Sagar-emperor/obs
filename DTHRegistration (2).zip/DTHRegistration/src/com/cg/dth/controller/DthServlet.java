package com.cg.dth.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dth.bean.DthBean;
import com.cg.dth.exception.DthException;
import com.cg.dth.service.DthServiceImpl;
import com.cg.dth.service.IDthService;

/**
 * Servlet implementation class DthServlet
 */
@WebServlet("*.obj")
public class DthServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DthServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		IDthService dthService = null;
		DthBean dto = null;
		String target = "";
		PrintWriter out = response.getWriter();
		

		HttpSession session = request.getSession(true);
		// Object creations
		dto =  new DthBean();
		dthService = new DthServiceImpl();

		String targetRegister = "register.jsp";
		String targetWelcome = "welcome.jsp";
		String targetBill = "bill.jsp";
		String targetSuccess = "success.jsp";
		String path = request.getServletPath().trim();

		switch (path) {
		
		case "/register.obj":
		
			target = targetRegister;
			break;
		
		case "/welcome.obj":
			String customername=request.getParameter("customername");
			String username=request.getParameter("username");
			String mobilenumber=request.getParameter("mobileno");
			dto.setCustomerName(customername);
			dto.setMobileNumber(mobilenumber);
			dto.setUserName(username);
			dto.setPassword(request.getParameter("password"));
			session.setAttribute("username",username);
			session.setAttribute("mobilenumber",mobilenumber);
			try {
				dthService.addCustomer(dto);
			} catch (DthException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			target = targetWelcome;
			break;
		
		case "/payment.obj":
			target = targetBill;
			break;
			
		case "/success.obj":
			int amount=Integer.parseInt(request.getParameter("value"));
			amount=1000-amount;
			session.setAttribute("value",amount);//$
			
			target = targetSuccess;
			break;
		}
	
		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}

}
