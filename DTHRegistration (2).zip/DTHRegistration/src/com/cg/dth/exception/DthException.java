package com.cg.dth.exception;

public class DthException extends Exception{

	public DthException(String message)
	{
		super(message);
	}

}
