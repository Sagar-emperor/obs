CREATE TABLE customer(
customername VARCHAR(30),
username VARCHAR(20),
password VARCHAR(20),
mobilenumber VARCHAR(10),
amount NUMBER DEFAULT 1000,
billdate DATE);