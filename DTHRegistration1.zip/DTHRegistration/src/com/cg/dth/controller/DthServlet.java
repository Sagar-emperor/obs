package com.cg.dth.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dth.bean.DthBean;
import com.cg.dth.service.DthServiceImpl;


/**
 * Servlet implementation class DthController
 */
@WebServlet("*.obj")
public class DthServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DthServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		DthServiceImpl dthService = null;
		DthBean dto = null;
		String target = "";
		PrintWriter out = response.getWriter();
		

		HttpSession session = request.getSession(true);
		// Object creations
		dto =  new DthBean();
		dthService = new DthServiceImpl();
		//int donorId = 0;
		
		String targetSuccess = "success.jsp";
		
		String targetError = "error.jsp";
		String targetHome = "index.jsp";
		String targetRegister = "register.jsp";
		
		String path = request.getServletPath().trim();

		switch (path) {
		
		case "/register.obj":
			session.setAttribute("custname", request.getParameter("custname"));
			session.setAttribute("mobilenum", request.getParameter("mobilenum"));
			session.setAttribute("username", request.getParameter("username"));
			session.setAttribute("password", request.getParameter("password"));
			target = targetRegister;
			break;
			
		}
		
	}

}
