package com.cg.dth.exception;

public class DthException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DthException(String message)
	{
		super(message);
	}

}
