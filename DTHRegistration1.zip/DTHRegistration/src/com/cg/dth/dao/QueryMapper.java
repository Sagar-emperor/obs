package com.cg.dth.dao;

public class QueryMapper {

	public static String INSERTQUERY ="INSERT INTO CUSTOMER VALUES(?,?,?,?,?,?)";

}
