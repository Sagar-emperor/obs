package com.cg.dth.dao;

import com.cg.dth.bean.DthBean;
import com.cg.dth.exception.DthException;
import com.cg.dth.utility.DbConnection;

public interface IDthDao {
	public void addCustomer(DthBean dto) throws DthException;
}