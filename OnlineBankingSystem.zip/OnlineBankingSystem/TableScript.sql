--USER TABLE FOR LOGIN

CREATE TABLE UserTable(
	Account_ID NUMBER PRIMARY KEY,
	user_id NUMBER,
	login_password VARCHAR2(15),
	secret_question VARCHAR2(50),
	Transaction_password VARCHAR2(15),
	lock_status VARCHAR2(1)
);

insert into usertable values(1234567890,User_id_seq.NEXTVAL,'qwerty','COLOR?','qwerty2','A');
insert into usertable values(1234567891,User_id_seq.NEXTVAL,'1aA$aaaaaa','COLOR?','qwerty3','A');
insert into usertable values(1234567892,User_id_seq.NEXTVAL,'1aA$aaaaaa','COLOR?','qwerty4','A');

CREATE TABLE AdminTable(
Account_ID NUMBER PRIMARY KEY,
	user_id NUMBER,
	login_password VARCHAR2(15),
	secret_question VARCHAR2(50),
	Transaction_password VARCHAR2(15),
	lock_status VARCHAR2(1)
);
insert into AdminTable values(1234567899,Admin_id_seq.NEXTVAL,'qwerty','COLOR?','qwerty2','A');



--ATTEMPTS OF THE USER LOGIN
CREATE TABLE Attempts(
	Account_ID NUMBER PRIMARY KEY,
	attempts NUMBER DEFAULT 0
);
insert into Attempts values(1234567890,0);
insert into Attempts values(1234567891,0);
insert into Attempts values(1234567892,0);
insert into Attempts values(1234567899,0);

--SEQUENCE FOR THE USER ID  IN USER TABLE 

CREATE SEQUENCE User_id_seq 
START WITH 1000 NOCACHE NOCYCLE;

CREATE SEQUENCE Admin_id_seq 
START WITH 1000 NOCACHE NOCYCLE;

CREATE SEQUENCE AccountID_Seq 
START WITH 123456780 NOCACHE NOCYCLE;

CREATE SEQUENCE Transaction_id_seq 
START WITH 1000 NOCACHE NOCYCLE;



-- CUSTOMER DETAILS TABLE 

CREATE TABLE Customer(
	Account_ID NUMBER(10) PRIMARY KEY, 
	customer_name VARCHAR2(50), 
	Email VARCHAR2(30), 
	Address VARCHAR2(100), 
	Pancard VARCHAR2(15),
	mobileNumber VARCHAR2(10),
	FOREIGN KEY (Account_ID) REFERENCES UserTable(Account_ID)
);
insert into Customer values(1234567890,'ishwar','ishwarstark@gmail.com','Kota','ABCDE1234F','9876543210');
insert into Customer values(1234567891,'ishwari','ishwaristark@gmail.com','Kota','ABCDE1234F','9876543210');
insert into Customer values(1234567892,'eeshwari','eeshwaristark@gmail.com','Kota','ABCDE1234F','9876543210');

--ACCOUNT MASTER TABLE FOR ACCOUNT INFORMATION

CREATE TABLE AccountMaster(
	Account_ID NUMBER(10) PRIMARY KEY , 
	Account_Type VARCHAR2(25), 
	Account_Balance NUMBER(15) ,
	Open_Date DATE,
	FOREIGN KEY (Account_ID) REFERENCES UserTable(Account_ID)
);
insert into AccountMaster values(1234567890,'SAVING','34000','11-Sep-16');
insert into AccountMaster values(1234567891,'SAVING','34000','11-Sep-16');
insert into AccountMaster values(1234567892,'SAVING','34000','11-Sep-16');




--TRANSACTIONS TABLE 


CREATE TABLE Transactions(
	Transaction_ID NUMBER PRIMARY KEY ,
	Tran_description VARCHAR2(100), 
	DateofTransaction DATE , 
	TransactionType VARCHAR2(1) ,
	TranAmount NUMBER(15) ,
	Account_ID NUMBER(10),
	FOREIGN KEY (Account_ID) REFERENCES UserTable(Account_ID)
);


insert into Transactions values(Transaction_id_seq.NEXTVAL,'beverages',SYSDATE,'C',5000,1234567891);

---Service Tracker

CREATE TABLE Service_Tracker(
	Service_ID NUMBER PRIMARY KEY,
	Service_Description VARCHAR2(100),
	Account_ID NUMBER,
	Service_Raised_Date DATE ,
	Service_status VARCHAR2(20)
);	

CREATE SEQUENCE Service_ID_seq 
START WITH 1000 NOCACHE NOCYCLE;




