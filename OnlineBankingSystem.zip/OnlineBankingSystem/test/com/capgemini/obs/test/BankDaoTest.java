package com.capgemini.obs.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.BeforeClass;







import org.junit.Test;

import com.capgemini.obs.dao.BankDaoImpl;
import com.capgemini.obs.dto.AccountMaster;
import com.capgemini.obs.dto.Customer;
import com.capgemini.obs.dto.ServiceTracker;
import com.capgemini.obs.dto.Transactions;
import com.capgemini.obs.dto.User;
import com.capgemini.obs.exception.BankException;

public class BankDaoTest {
	
	static BankDaoImpl dao;
	static  AccountMaster accountMaster;
	static Customer customer;
	static ServiceTracker serviceTracker;
	static Transactions transactions;
	static User user;
	
	
	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		try {
			dao = new BankDaoImpl();
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		accountMaster = new AccountMaster();
		customer = new Customer();
		serviceTracker = new ServiceTracker();
		transactions = new Transactions();
		user = new User();
		
	}

	@Test
	public void updateMobileNumberTest()
	{
		
		try {
			assertNotNull(dao.updateMobileNumber(1234567890, "9848427207"));
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void updateAddressTest()
	{
		
		try {
			assertNotNull(dao.updateAddress(1234567890, "andhra"));
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void isValidTransactionPasswordTest()
	{
		
		try {
			assertNotNull(dao.isValidTransactionPassword("qwerty2",1234567890, "usertable"));
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}
	
	@Test
	public void isLockedAccountTest()
	{
		
		try {
			assertNotNull(dao.isLockedAccount(1234567890, "usertable"));
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}
	
	@Test
	public void getUserQuestionTest()
	{
		
		try {
			assertEquals("COLOR?", dao.getUserQuestion(1234567890, "usertable"));
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}
	

	@Test
	public void isValidUserTest()
	{
		
		try {
			assertNotNull( dao.isValidUser(1234567890,"qwerty", "usertable"));
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}
	
	
	

	
	
	
	
}
