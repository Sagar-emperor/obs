package com.capgemini.obs.dao;

public interface QueryMapper {

	public static final String VALID_USER = "SELECT Account_ID from $tableName WHERE Account_ID=?";
	public static final String VALID_USER_PASSWORD = "SELECT Account_ID from $tableName WHERE Account_ID=? AND login_password=?";
	public static final String PASSWORD_ATTEMPTS = "SELECT Attempts from Attempts WHERE Account_Id=?";
	public static final String LOCK_ACCOUNT ="UPDATE  $tableName SET lock_status='L' WHERE Account_Id=? ";
	public static final String SETPASSWORD_ATTEMPTS = "UPDATE Attempts SET Attempts=Attempts+1 WHERE  Account_Id=? ";
	public static final String SETPASSWORD_ATTEMPTS_ZERO = "UPDATE Attempts SET Attempts=0 WHERE  Account_Id=? ";
	public static final String GET_QUESTION = "SELECT secret_question from $tableName WHERE Account_ID=? ";
	public static final String UNLOCK_ACCOUNT = "UPDATE  $tableName SET lock_status='A' WHERE Account_Id=? ";
	public static final String UPDATE_PASSWORD = "UPDATE  $tableName SET login_password=? WHERE Account_Id=?";
	public static final String TRANSACTION_PASSWORD = "SELECT Transaction_password from $tableName WHERE Account_ID=? ";
	public static final String LOCK_STATUS = "select lock_status from $tableName where Account_Id=?";
	public static final String INSERT_ACCOUNT_QUERY ="INSERT INTO AccountMaster VALUES(AccountID_Seq.CURRVAL,?,?,SYSDATE)";
	public static final String ACCOUNTID_QUERY_SEQUENCE = "SELECT AccountID_Seq.CURRVAL FROM DUAL";
	public static final String INSERT_USER_QUERY = "INSERT INTO usertable VALUES(AccountID_Seq.NEXTVAL,User_id_seq.NEXTVAL,?,?,?,?)";
	public static final String INSERT_CUSTOMER_QUERY = "INSERT INTO Customer VALUES(AccountID_Seq.CURRVAL,?,?,?,?,?)";
	public static final String MINI_STATEMENTS = "SELECT transaction_id,tran_description,dateoftransaction,transactiontype,tranamount FROM transactions where account_id=? ORDER BY dateoftransaction DESC ";
	public static final String DETAILED_STATEMENTS = "SELECT transaction_id,tran_description,dateoftransaction,transactiontype,tranamount FROM transactions where account_id=? AND dateoftransaction BETWEEN ? AND ? ORDER BY dateoftransaction DESC ";	
	public static final String PANCARD_ACCOUNT_NUM = "SELECT Account_id from Customer where PanCard=(SELECT Pancard from Customer where Account_id=?)";
	public static final String VIEW_BANK_DETAILS_QUERY="SELECT * FROM Customer WHERE Account_id=?";
	public static final String UPDATE_MOBILE_NUMBER = "update customer set mobilenumber=? where Account_id=?";
	public static final String CHECK_SERVICE  = "SELECT account_Id FROM Service_Tracker where account_Id=?";
	public static final String REQUEST_QUERY_SEQUENCE = "SELECT Service_ID_seq.CURRVAL FROM DUAL";
	public static final String INSERT_REQUEST = "INSERT INTO Service_Tracker values(Service_ID_seq.NEXTVAL,?,?,SYSDATE,?)";
	public static final String SELECT_REQUEST ="SELECT Service_ID,Service_Description,Service_Raised_Date,Service_status FROM service_tracker WHERE Account_Id=?";
	public static final String VIEW_TRANSACTION_BY_DAILY="SELECT Transaction_ID,Tran_description,DateofTransaction,TransactionType,TranAmount,Account_ID FROM Transactions WHERE EXTRACT( DAY FROM DateofTransaction)=?";
	public static final String VIEW_TRANSACTION_BY_MONTH="SELECT Transaction_ID,Tran_description,DateofTransaction,TransactionType,TranAmount,Account_ID FROM Transactions WHERE EXTRACT( MONTH FROM DateofTransaction)=?";
	public static final String VIEW_TRANSACTION_BY_YEAR="SELECT Transaction_ID,Tran_description,DateofTransaction,TransactionType,TranAmount,Account_ID FROM Transactions WHERE EXTRACT( YEAR FROM DateofTransaction)=?";
	public static final String GET_ALL_PAYEE="SELECT Payee_account_id, nick_name from PayeeTable where account_id =?";
	public static final String BALANCE_DEDUCTION = "UPDATE AccountMaster SET Account_Balance=Account_Balance-? WHERE Account_id=?";
	public static final String BALANCE_INCREMENT = "UPDATE AccountMaster SET Account_Balance=Account_Balance+? WHERE Account_id=?";
	public static final String FUND_TRANSFER = "INSERT INTO Fund_Transfer VALUES(FundTrasfer_ID_seq.NEXTVAL,?,?,SYSDATE,?)";
	public static final String TRANSFER = "insert into Transactions values(Transaction_id_seq.NEXTVAL,?,SYSDATE,?,?,?)";
	public static final String GET_AMOUNT="SELECT ACCOUNT_BALANCE FROM AccountMaster WHERE Account_id=?";
	public static final String INSERT_INTO_ATTEMPTS="INSERT INTO attempts values(AccountID_Seq.CURRVAL,0)";
}
