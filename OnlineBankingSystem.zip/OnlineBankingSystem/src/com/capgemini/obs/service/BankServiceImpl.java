package com.capgemini.obs.service;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;









import com.capgemini.obs.dao.BankDaoImpl;
import com.capgemini.obs.dao.IBankDao;
import com.capgemini.obs.dto.AccountMaster;
import com.capgemini.obs.dto.Customer;
import com.capgemini.obs.dto.FundTransfer;
import com.capgemini.obs.dto.Payees;
import com.capgemini.obs.dto.ServiceTracker;
import com.capgemini.obs.dto.Transactions;
import com.capgemini.obs.dto.User;
import com.capgemini.obs.exception.BankException;

public class BankServiceImpl implements IBankService {

	private IBankDao iBankDao;// creating reference of the DAO Interface
	
	public BankServiceImpl() throws BankException {
		
		iBankDao = new BankDaoImpl();//assigning  object of the Implementation class that contains methods
	}


	@Override
	public boolean isValidUser(long accountNumber, String password,String loginTable) throws BankException {
		
		boolean isValidUser = false;
		
		isValidUser = iBankDao.isValidUser(accountNumber,password,loginTable);
		
		return isValidUser;
	}
	
	@Override
	public int getUserAttempts(long accountNumber,String loginTable) throws BankException {
		
		int attempts = 0;// default number of attempts
		
		attempts = iBankDao.getUserAttempts(accountNumber,loginTable);// retrieving number of attempts
		
		return attempts;
	
	}


	@Override
	public List<String> validateCredentials( String cusName,String password,String panCard ,String emailId,long initBalance) {
		// TODO Auto-generated method stub
		List<String> validationErrors = new ArrayList<>();
		

		if(!(isValidCustomerName(cusName)))
		{
			validationErrors.add("\nthe Customer name will not alow Special characters \n");
		}
	
		
		if(!(isValidPassword(password))) {
			validationErrors.add("\n Account Password should contain a digit,a lowercase letter, a uppercase letter,one special symbols in the list (@#$%),minimum 6 characters maximum 20  \n");
		}
		
		if(!(isValidPanCard(panCard)))
		{
			validationErrors.add("\n Enter a valid PANCARD Number \n");
		}
		if(!(isValidEmail(emailId)))
		{
			validationErrors.add("\n Enter a valid Email Address \n");
		}
		
		
		if(!(isValidInitBalance(initBalance)))
		{
			validationErrors.add("\n The Minimum Account Balance Should be 500 \n");
		}
		
		return validationErrors;
	}
	
	
	boolean isValidInitBalance(long initBalance)
	{
		if(initBalance > 500)
			return true;
		else
			return false;
	}
	
	boolean isValidCustomerName(String cusName)
	{
		String regex ="^[a-zA-Z\\s]+"; 
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(cusName);
		return  matcher.matches();
		
	}
	
	boolean isValidPanCard( String panCard)
	{
		Pattern pattern = Pattern.compile("[A-Z]{5}[0-9]{4}[A-Z]{1}");
		
		/*
		   [A-Z]{5} - match five literals which can be A to Z
		   [0-9]{4} - followed by 4 numbers 0 to 9
		   [A-Z]{1} - followed by one literal which can A to Z
		
		 */
		Matcher matcher = pattern.matcher(panCard);
		return matcher.matches();
	}
	 
	boolean isValidEmail(String emailID)
	{
		String regex = "^(.+)@(.+)$"; 
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(emailID);
		return  matcher.matches();
		
	}
	 
	 
	 boolean isValidPassword(String password)
	 {
		 String passwordPatternString = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
	/*  (				# Start of group
  		(?=.*\d)		#   must contains one digit from 0-9
  		(?=.*[a-z])		#   must contains one lowercase characters
  		(?=.*[A-Z])		#   must contains one uppercase characters
  		(?=.*[@#$%])	#   must contains one special symbols in the list "@#$%"
              .			#   match anything with previous condition checking
                {6,20}	#   length at least 6 characters and maximum of 20
			)			# End of group                     
	*/
		 Pattern passwordPattern = Pattern.compile(passwordPatternString);
		 Matcher passwordPatternMatcher = passwordPattern.matcher(password);
		 return passwordPatternMatcher.matches();
	 }


	@Override
	public void lockAccount(long accountNumber,String loginTable) throws BankException {
		
		iBankDao.lockAccount(accountNumber,loginTable);
		
	}


	@Override
	public void setUserAttempts(long accountNumber,String loginTable) throws BankException {
		
		iBankDao.setUserAttempts(accountNumber,loginTable);
		
	}


	@Override
	public String getUserQuestion(long accountNumber,String loginTable) throws BankException {
		
		String question =iBankDao.getUserQuestion(accountNumber,loginTable);
		return question;
	}


	@Override
	public boolean isValidTransactionPassword(String transactionpassword,long accountNumber,String loginTable) throws BankException {
		boolean isValidTransactionPassword = iBankDao.isValidTransactionPassword(transactionpassword, accountNumber, loginTable);
		return isValidTransactionPassword;
	}


	@Override
	public void unLockAccount(long accountNumber,String loginTable) throws BankException {
		
		iBankDao.unLockAccount(accountNumber, loginTable);
		
	}


	@Override
	public void updatePassword(long accountNumber,String newPassword,String loginTable) throws BankException {
		
		
		iBankDao.updatePassword(accountNumber, newPassword,loginTable);
	}


	@Override
	public boolean isLockedAccount(long accountNumber,String loginTable) throws BankException {
	
		boolean isLockedAccount=iBankDao.isLockedAccount(accountNumber,loginTable);
	return isLockedAccount;
		
	}


	@Override
	public void setUserAttemptsZero(long accountNumber,String loginTable) throws BankException {
		// TODO Auto-generated method stub
		iBankDao.setUserAttemptsZero(accountNumber,loginTable);
	}


	@Override
	public long createAccount(AccountMaster accountMaster, User user,
			Customer customer) throws BankException {
		long  accountId=iBankDao.createAccount(accountMaster, user, customer);
		return accountId;
	}


	@Override
	public boolean isValiddates(String startDate, String endDate) {


		//LocalDate ld1 = new java.sql.Date(sdate.getTime()).toLocalDate();
		boolean isValidDate = false;
		try {
			
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/YYYY");
			dateFormat.setLenient(false);
			
			dateFormat.parse(startDate);
			dateFormat.parse(endDate);
			
			isValidDate = true;
			
		} catch(ParseException parseException) {
			//parseException.printStackTrace();
			isValidDate = false;
			
		}
		return isValidDate;
	}


	@Override
	public List<Transactions> viewMiniStatement(long accountNum)  throws BankException{
		List<Transactions> tranList = null;
		
		tranList = iBankDao.viewMiniStateMent(accountNum);
		
		return tranList;
		
	}


	@Override
	public List<Transactions> viewDetailedStatement(long accountNum,Date startDate, Date endDate) throws BankException {
		List<Transactions> tranList = null;
		
		tranList = iBankDao.viewDetailedStatement(accountNum,startDate,endDate);

		return tranList;
	}


	@Override
	public Customer getCustomerDetails(long accountNumber) throws BankException {
		Customer customer= iBankDao.getCustomerDetails(accountNumber);
		return customer;
	}


	@Override
	public int updateMobileNumber(long accountNumber, String newMobileNumber)
			throws BankException {
		
		int result = iBankDao.updateMobileNumber(accountNumber, newMobileNumber);
		return result;
	}


	@Override
	public int updateAddress(long accountNumber, String newAddress) throws BankException {
		
		return iBankDao.updateAddress(accountNumber, newAddress);
	}


	@Override
	public boolean requestCheckBook(ServiceTracker serviseTracker) throws BankException {
		
		return iBankDao.requestCheckBook(serviseTracker);
		
	}


	@Override
	public boolean checkRequestAvailable(long accountId) throws BankException {
		return iBankDao.checkRequestAvailable(accountId); 
		
	}


	@Override
	public ServiceTracker trackServiceRequest(long accountNumber)
			throws BankException {
		return iBankDao.trackServiceRequest(accountNumber);
	}


	@Override
	public List<Transactions> getTransactions(String transactionType, long accountNumber,int number)
			throws BankException {

		return iBankDao.getTransactions( transactionType,  accountNumber,number);
	}


	@Override
	public List<Long> getAccountNumbers(long accountNumber)
			throws BankException {

		return iBankDao.getAccountNumbers(accountNumber);
	}


	@Override
	public List<Payees> getAllPayees(long bankAccountNumber)
			throws BankException {
		
		return iBankDao.getAllPayees(bankAccountNumber);
	}


	@Override
	public FundTransfer fundTransfer(long bankAccountNumber, long payeeAccountNumber,long transferAmount)
			throws BankException {
		
		return iBankDao.fundTransfer(bankAccountNumber,payeeAccountNumber,transferAmount);
	}


	@Override
	public long isAmountTransferable(long bankAccountNumber,
			long transferAmmount) throws BankException {
	
		return iBankDao.isAmountTransferable(bankAccountNumber, transferAmmount);
	}
	

}
