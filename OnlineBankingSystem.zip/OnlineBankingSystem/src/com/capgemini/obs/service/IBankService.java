/**
 * 
 */
package com.capgemini.obs.service;

import java.sql.Date;
import java.util.List;

import com.capgemini.obs.dto.AccountMaster;
import com.capgemini.obs.dto.Customer;
import com.capgemini.obs.dto.ServiceTracker;
import com.capgemini.obs.dto.Transactions;
import com.capgemini.obs.dto.User;
import com.capgemini.obs.exception.BankException;

public interface IBankService {

	int getUserAttempts(long accountNumber,String loginTable) throws BankException;

	boolean isValidUser(long accountNumber, String password,String loginTable) throws BankException;
	
	List<String> validateCredentials(String cusName,String password,String panCard,String emailId,long initBalance); 
	
	void lockAccount(long accountNumber,String loginTable) throws BankException;
	
	void setUserAttempts(long accountNumber,String loginTable) throws BankException;
	
	String getUserQuestion(long accountNumber,String loginTable) throws BankException ;
	
	boolean isValidTransactionPassword(String transactionpassword,long accountNumber,String loginTable) throws BankException;
	
	void unLockAccount(long accountNumber,String loginTable) throws BankException;
	
	void updatePassword(long accountNumber,String newPassword,String loginTable) throws BankException;
	
	boolean isLockedAccount(long accountNumber,String loginTable) throws BankException;

	void setUserAttemptsZero(long accountNumber,String loginTable) throws BankException;
	
	long createAccount(AccountMaster accountMaster,User user,Customer customer) throws BankException;

	boolean isValiddates(String startDate, String endDate) throws BankException;

	List<Transactions> viewMiniStatement(long accountNum) throws BankException;

	List<Transactions> viewDetailedStatement(long accountNum, Date startDate,
			Date endDate) throws BankException;
	
	Customer getCustomerDetails(long accountNumber) throws BankException;
	
	int updateMobileNumber(long accountNumber, String newMobileNumber) throws BankException;
	
	int updateAddress(long accountNumber, String newAddress) throws BankException;

	boolean requestCheckBook(ServiceTracker serviseTracker) throws BankException;

	boolean checkRequestAvailable(long accountId) throws BankException;

	ServiceTracker trackServiceRequest(long accountNumber)throws BankException;
	
	

}
