package com.capgemini.obs.dto;

import java.time.LocalDate;

public class FundTransfer {

	private int fundTransferId ;
	private long accountId;
	private long payeeAccountId;
	private LocalDate transferDate;
	private long tranferAmmount;
	
	public int getFundTransferId() {
		return fundTransferId;
	}
	public void setFundTransferId(int fundTransferId) {
		this.fundTransferId = fundTransferId;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public long getPayeeAccountId() {
		return payeeAccountId;
	}
	public void setPayeeAccountId(long payeeAccountId) {
		this.payeeAccountId = payeeAccountId;
	}
	public LocalDate getTransferDate() {
		return transferDate;
	}
	public void setTransferDate(LocalDate transferDate) {
		this.transferDate = transferDate;
	}
	public long getTranferAmmount() {
		return tranferAmmount;
	}
	public void setTranferAmmount(long tranferAmmount) {
		this.tranferAmmount = tranferAmmount;
	}
	
}
