package com.capgemini.obs.dto;

import java.time.LocalDate;

public class ServiceTracker {
	
	private int serviceId;
	private String serviceDescription;
	private long accountId;
	private LocalDate serviceRaisedDate;
	private String serviceStatus;
	
	
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceDescription() {
		return serviceDescription;
	}
	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public LocalDate getServiceRaisedDate() {
		return serviceRaisedDate;
	}
	public void setServiceRaisedDate(LocalDate serviceRaisedDate) {
		this.serviceRaisedDate = serviceRaisedDate;
	}
	public String getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}

	
		
		
		
}
