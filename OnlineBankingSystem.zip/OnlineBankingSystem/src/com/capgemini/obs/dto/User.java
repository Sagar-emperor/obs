package com.capgemini.obs.dto;

public class User {

		private long accountId;
		private long userId;
		private String loginPass;
		private String secretQuestion;
		private String transactionPassword;
		private String lockStatus;
		
		
		public long getAccountId() {
			return accountId;
		}
		public void setAccountId(long accountId) {
			this.accountId = accountId;
		}
		public long getUserId() {
			return userId;
		}
		public void setUserId(long userId) {
			this.userId = userId;
		}
		public String getLoginPass() {
			return loginPass;
		}
		public void setLoginPass(String loginPass) {
			this.loginPass = loginPass;
		}
		public String getSecretQuestion() {
			return secretQuestion;
		}
		public void setSecretQuestion(String secretQuestion) {
			this.secretQuestion = secretQuestion;
		}
		public String getTransactionPassword() {
			return transactionPassword;
		}
		public void setTransactionPassword(String transactionPassword) {
			this.transactionPassword = transactionPassword;
		}
		public String getLockStatus() {
			return lockStatus;
		}
		public void setLockStatus(String lockStatus) {
			this.lockStatus = lockStatus;
		}
		
		
		
		
		
}
