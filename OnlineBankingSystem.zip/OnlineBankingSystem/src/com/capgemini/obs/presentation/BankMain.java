/**
 * 
 */
package com.capgemini.obs.presentation;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.obs.dto.AccountMaster;
import com.capgemini.obs.dto.Customer;
import com.capgemini.obs.dto.ServiceTracker;
import com.capgemini.obs.dto.Transactions;
import com.capgemini.obs.dto.User;
import com.capgemini.obs.exception.BankException;
import com.capgemini.obs.service.BankServiceImpl;
import com.capgemini.obs.service.IBankService;

public class BankMain {

	static final int ATTEMPT_LIMIT=3;// Attempt limits for the wrong password
	
	// --------Default values for the accountNumber and password
	static long accountNumber = 0l ;
	static String password = "UNKNOWN";
	static IBankService iBankService = null;
	
	 //Console object for the input from the user
	static Logger logger = Logger.getRootLogger();// Logger object for log generation

	private static Scanner sc;
	
	public static void main(String[] args) {
	
		PropertyConfigurator.configure("resources//log4j.properties");
		IBankService iBankService = null;// Create a bank service object 
		//List<String> errors=null ;
		int attempts=0;
		sc = new Scanner(System.in);
		boolean flag = true;
		String loginTable = "";

		
		//-----------------------------------------------------------
		do {
			System.out.println("Login as : ");
			System.out.println("----------------------------");
			System.out.println("1. Admin");
			System.out.println("2. Customer");
			
			int choice = sc.nextInt();
			
			switch(choice){
			
				case 1 : 
					loginTable = "AdminTable";
					flag = false;
					break;
				
				case 2 : 
					loginTable = "UserTable";
					flag = false;
					break;
					
				default:
					System.out.println("Please enter a valid option");
			}
			
		}while(flag);
		
		//-----------------------------------------------------------
		
		
		while(true){
				System.out.print("Enter Account Number : ");
				accountNumber = Long.parseLong(sc.next());

				System.out.print("Enter Password : ");
				password = sc.next();
			
				
	
			try {
				
				iBankService = new BankServiceImpl();
				boolean isValidUser = iBankService.isValidUser(accountNumber,password,loginTable);
				boolean isValid = false;
				if(isValidUser){
					System.out.println("VALID USER");
					
					isValid = true;
				}else {
					System.out.println("Enter VALID USER CREDENTIALS");
					isValid = false;
				}
				
			
			if(isValid){
				iBankService = new BankServiceImpl();
				attempts = iBankService.getUserAttempts(accountNumber,loginTable);
				
				iBankService = new BankServiceImpl();
				boolean isLocked = false;
				
				isLocked = iBankService.isLockedAccount(accountNumber,loginTable);
				
				while(isLocked) {
					System.out.println("Please Change Your Password.");
					System.out.println("Enter New Password");
					
				String password= sc.next();
					
					System.out.println("Re Enter Your Password");
					String rePassword = sc.next();
					
					
					if(password.equals(rePassword))
					{
						iBankService = new BankServiceImpl();
						iBankService.updatePassword(accountNumber, rePassword,loginTable);
						iBankService = new BankServiceImpl();
						iBankService.unLockAccount(accountNumber,loginTable);
						iBankService = new BankServiceImpl();
						isLocked = iBankService.isLockedAccount(accountNumber,loginTable);
						iBankService = new BankServiceImpl();
						iBankService.setUserAttemptsZero(accountNumber,loginTable);
					}
					else
					{
						System.out.println("Please Try Again!");
					}
				}
				if(attempts < ATTEMPT_LIMIT){
								
					System.out.println("YOU HAVE USED "+attempts+" ATTEMPTS");
				
				
				} else {
				
						}	
			} else {
				//password incorrect
				iBankService = new BankServiceImpl();
				iBankService.setUserAttempts(accountNumber,loginTable);
				
				iBankService = new BankServiceImpl();
				if(iBankService.getUserAttempts(accountNumber,loginTable) == ATTEMPT_LIMIT){
					iBankService = new BankServiceImpl();
					iBankService.lockAccount(accountNumber,loginTable);
				}
				
			}
			iBankService = new BankServiceImpl();
			System.out.println("Please  "+iBankService.getUserAttempts(accountNumber,loginTable));
			
			
			
			
			
			
			
			iBankService = new BankServiceImpl();
			if(iBankService.getUserAttempts(accountNumber,loginTable) > ATTEMPT_LIMIT){
				System.out.println("YOU HAVE USED ALL THE "+ ATTEMPT_LIMIT+"  ATTEMPTS");
				iBankService = new BankServiceImpl();
				iBankService .lockAccount(accountNumber,loginTable);
				
				System.out.println("Forget Password?");
				System.out.println("Answer this Question.To retrive your account");
				
				
				iBankService = new BankServiceImpl();
				String question= iBankService.getUserQuestion(accountNumber,loginTable);
				System.out.println(question);
				
				
				System.out.println("Enter the transaction password?");
				String transactionpassword =sc.next();
				iBankService = new BankServiceImpl();
				
				
				boolean isValidTransactionPassword=iBankService.isValidTransactionPassword(transactionpassword,accountNumber,loginTable);
				if(isValidTransactionPassword)
				{
					
					System.out.println("your new password is sbq500# .Please Reset As early as possible");
					String newPassword="sbq500#";
					iBankService = new BankServiceImpl();
					iBankService.updatePassword(accountNumber, newPassword,loginTable);
					
					
				}
				else
					System.out.println("You Have Again Entered the Wrong Answer ! Please Reach Us at the Nearest Branch!");
				
					
				}
				
				
			///////////////////////////////////////
			
				if(loginTable.equals("AdminTable") && isValid && attempts<ATTEMPT_LIMIT) {
					
					System.out.println("Select An Option :");
					System.out.println("---------------------------");
					System.out.println("1. Open an Account");
					System.out.println("2. View Transactions");
					System.out.println("2. Exit");
					int choice = sc.nextInt();
					
					
					switch(choice){
					case 1 :
						openAccount();
						
						break;
						
					case 2 :
						viewTransactions();
						break;
					
					case 3 :
						System.exit(0);
						break;
					default :
						
					
					}
								
				} else if(loginTable.equals("UserTable")&& isValid && attempts<ATTEMPT_LIMIT) {
					
					System.out.println("Select An Option :");
					System.out.println("---------------------------");
					System.out.println("1. View/Mini Detailed Statement");
					System.out.println("2. Change in address/mobile number");
					System.out.println("3. Request for cheque book");
					System.out.println("4. Track service request");
					System.out.println("5. Fund Transfer");
					System.out.println("6. Change password");
					System.out.println("7. Exit");
					int choice = sc.nextInt();
					
					
					switch(choice){
					case 1 :
						viewMiniDetailedStatements(accountNumber);		
						break;		
					case 2 :
						changeDetails(accountNumber);
						break;
					
					case 3 :
						requestCheckBook(accountNumber);
						break;
					case 4:
						trackServiceRequest(accountNumber);
						break;
					case 5:
						fundTransfer();
						break;
					case 6:
						changePassword();
						break;		
					case 7:
						System.exit(0);
						break;
					default :
						
					
					}
					
				
				
			}
						
				
			} catch (BankException bankException) {
				
				logger.error("Exception Eccured : ", bankException);				
				System.out.println("Exception Eccured : "+ bankException);
				
			}
		
			
			
		}	
		
	}

	private static void changePassword() {
		System.out.println("Enter the New Password :");
		String newPassword = sc.next();
		System.out.println("Re Enter the New Password");
		String reNewPassword=sc.next();
		if(newPassword.equals(reNewPassword))
		{
			
			try {
				iBankService = new BankServiceImpl();
				iBankService.updatePassword(accountNumber, reNewPassword,"UserTable");
				
				iBankService = new BankServiceImpl();
				iBankService.setUserAttemptsZero(accountNumber,"UserTable");
				
				System.out.println("Your Password Has been Updated Succesfully!");
			} catch (BankException bankException) {
				
				logger.error("Exception Eccured : ", bankException);				
				System.out.println("Exception Eccured : "+ bankException);
			}
			
			
		}
		else
		{
			System.out.println("Please Try Again");
		}
		
	}

	private static void fundTransfer() {
		// TODO Auto-generated method stub
		
	}

	private static void trackServiceRequest( long accountNumber) {
		ServiceTracker serviceTracker = null;
		try{
			iBankService = new BankServiceImpl();
			serviceTracker = iBankService.trackServiceRequest(accountNumber);
			
			if(serviceTracker!=null)
			{
				showServiceDetals(serviceTracker);
			}
			else
			{
				System.out.println("No Request Available for Account Number : "+accountNumber);
			}
			
		}catch(BankException bankException){

			logger.error("Exception Eccured : ", bankException);				
			System.out.println("Exception Eccured : "+ bankException);
		}
		
	}
	
	private static void showServiceDetals(ServiceTracker serviceTracker) {
		System.out.println("Your Servise Request Details for account no"+serviceTracker.getAccountId()+" : ");
		System.out.println("----------------------------------------------");
		System.out.println("Service id : "+serviceTracker.getServiceId());
		System.out.println("Description : "+serviceTracker.getServiceDescription());
		System.out.println("Requested date : "+serviceTracker.getServiceRaisedDate());
		System.out.println("Service Status : "+serviceTracker.getServiceStatus());
		System.out.println("-----------------------------------------------");
		
	}

	private static void requestCheckBook(long accountId) {
		
		try {
			iBankService = new BankServiceImpl();
			if(iBankService.checkRequestAvailable(accountId))
			{
				iBankService = new BankServiceImpl();
				
				ServiceTracker serviseTracker = pupulateServiceTracker(accountId);
				
				boolean isRequested = iBankService.requestCheckBook(serviseTracker);
				if(isRequested){
					System.out.println("Your Request for CheckBook has been submitted");
				}else{
					System.out.println("Your Request for CheckBook cannot be submitted");
				}
			}
			else
			{
				System.out.println("You have not Requested for your check book");
			}
		}catch (BankException bankException){

			logger.error("Exception Eccured : ", bankException);				
			System.out.println("Exception Eccured : "+ bankException);
		}
	}

	private static ServiceTracker pupulateServiceTracker(long accountId) {

		ServiceTracker serviceTracker = new ServiceTracker();

		serviceTracker.setAccountId(accountId);
		
		String serviceDescription = "Request for Checkbook";
		serviceTracker.setServiceDescription(serviceDescription);
		
		String serviceStatus = "Requested";
		serviceTracker.setServiceStatus(serviceStatus);
		
		return serviceTracker;
	}

	private static void changeDetails(long accountNumber) {
		
		try {
			iBankService = new BankServiceImpl();
			Customer customer =iBankService.getCustomerDetails(accountNumber);
			System.out.println("The Pervious Details are:");
			System.out.println("Mobile Number :" +customer.getMobileNumber());
			System.out.println("Address:"+customer.getAddress());
			System.out.println("which Details has to be Updated:");
			System.out.println("1.MobileNumber");
			System.out.println("2.Address");
			
			int choice = sc.nextInt();
			switch(choice){
			case 1 :
				System.out.println("Enter new Mobile Number");
				String newMobileNumber= sc.next();
				iBankService = new BankServiceImpl();
				int result=iBankService.updateMobileNumber(accountNumber, newMobileNumber);
				if(result>0)
					System.out.println("Succesfully Updated!");
				else
					System.out.println("Not Succesfull");
				break;
				
			case 2 :
				
				System.out.println("Enter new Address");
				String newAddress= sc.next();
				iBankService = new BankServiceImpl();
				int result2=iBankService.updateMobileNumber(accountNumber, newAddress);
				if(result2>0)
					System.out.println("Succesfully Updated!");
				else
					System.out.println("Not Succesfull");
				
				break;
			
			
			default :
				
			
			}
			
			
			
		} catch (BankException bankException) {
			logger.error("Exception Eccured : ", bankException);				
			System.out.println("Exception Eccured : "+ bankException);
		}
		
		
		
		
	}

	private static void viewMiniDetailedStatements(long accountNum) {
		
		System.out.println("Select An Option :");
		System.out.println("---------------------------");
		System.out.println("1. Mini statements");
		System.out.println("2. Detailed Statements");
		System.out.println("2. Exit");
		int choice = sc.nextInt();
		
		
		switch(choice){
		case 1 :
			System.out.println("Mini Statement : ");
			/*
			 *  call for getting mini statement
			 *
			 * */
			viewMiniStatement(accountNum);
			break;
			
		case 2 :
			System.out.println("Detailed Statement : ");
			/*
			 *  call for getting detailed statement
			 * 
			 * */
			viewDetailedStatement(accountNum);
			break;
		
		case 3 :
			System.exit(0);
			break;
		default :
		}
			
		
		
		
		
	}

	private static void viewMiniStatement(long accountNum) {

		List<Transactions> transactionList = null;
		
		try {
			iBankService = new BankServiceImpl();
		
			transactionList = iBankService.viewMiniStatement(accountNum);
			System.out.println("Mini Statement : ");
			System.out.println("--------------------------------------");
			viewStatement(transactionList);
		
		} catch (BankException bankException ){
				
			logger.error("Exception Eccured : ", bankException);				
			System.out.println("Exception Eccured : "+ bankException);
			
		}
	}

	private static void viewDetailedStatement(long accountNum) {
		
		List<Transactions> transactionList = null;
		try {
			iBankService = new BankServiceImpl();
			

			
				
			String startDate = "";
			String endDate = "";
			do {
				
				System.out.println("Enter dates in [DD/MM/YYYY] format : ");
				
				System.out.print("Enter Starting Date : ");
					startDate = sc.next();
				System.out.print("Enter Ending Date : ");
					endDate = sc.next();
				
			} while(! iBankService.isValiddates(startDate,endDate));
				
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
				Date startDte = new java.sql.Date(dateFormat.parse(startDate).getTime());
				Date endDte = new java.sql.Date(dateFormat.parse(endDate).getTime());
				
				iBankService = new BankServiceImpl();
			
				transactionList = iBankService.viewDetailedStatement(accountNum,startDte,endDte);
					
				System.out.println("Detailed Statement : ");
				System.out.println("--------------------------------------");
	
				viewStatement(transactionList);
		
		
		} catch(ParseException parseException ) {
			
			logger.error("Exception Eccured : ", parseException);				
			System.out.println("Exception Eccured : "+ parseException);
			
		} catch(BankException bankException ) {
			
			logger.error("Exception Eccured : ", bankException);				
			System.out.println("Exception Eccured : "+ bankException);
			
		}
	}
	
	private static void viewStatement(List<Transactions> transactionList) throws BankException {			
			
			
			if(transactionList == null){
				
				System.out.println("No Transactions Available");
				
			} else {
			
				//System.out.println("Your all Account's Statement : ");
				//System.out.println("-----------------------------------------");
				
				if(!transactionList.isEmpty()){
					
					System.out.println("Transaction id\tDescription\tDate\tType[Debit(D)/Credit(C)]\tAmmount\tAccount ID");
					
					for(Transactions tBean : transactionList){
						
						System.out.print(tBean.getTransactionId()+"\t");
						System.out.print(tBean.getTranDescription()+"\t");
						System.out.print(tBean.getDateOfTransaction()+"\t");
						System.out.print(tBean.getTransactionType()+"\t");
						System.out.print(tBean.getTranAmount()+"\t");
						System.out.print(tBean.getAccountId()+"\t");
				
						System.out.println();
						
					}
					
				} else {
					
					System.out.println("No Transactions Available");
					
				}
				
			}
		
	}

	private static void viewTransactions() {
		// TODO Auto-generated method stub		
		
	}

	private static void openAccount() {
		
		AccountMaster accountMaster = new AccountMaster();
		Customer customer = new Customer();
		User user = new User();
		List<String> validationErrors = new ArrayList<>();
		
		
			
		System.out.println("Enter the Details : ");
		System.out.println("===========================================");
		
		
		System.out.println("Enter Profile details : ");
		System.out.println("-------------------------------");
		System.out.print("Enter the Name : ");		
			sc.nextLine();
			String cusName= sc.nextLine();
		System.out.print("Enter the Email id:");	
			String email= sc.nextLine();
		System.out.print("Enter the Address:");		
			String address= sc.nextLine();
		System.out.print("Enter PANCARD Number");	
			String pancard = sc.nextLine();
		 System.out.println("Enter Mobile Number:");
		    String mobileNumber=sc.nextLine();
		System.out.println("\n-------------------------------\n");
		
		
		
		System.out.println("Enter Account Details : ");
		System.out.println("-------------------------------");
		boolean flagAccountType = true;
		String accountType = "";
		
		while(flagAccountType){
			
			System.out.println("Choose your Account type : ");
			System.out.println("1. Saving");
			System.out.println("2. Current");
			
			int accOption = sc.nextInt();
			
			switch(accOption){
				
			case 1:
				accountType = "Saving";
				flagAccountType = false;
				break;
			
			case 2 :
				accountType = "Current";
				flagAccountType = false;
				break;
				
			default:
				System.out.println("\nPlease Enter correct choice...!\n");
			}
		}
		
		System.out.print("Enter initial Balance : ");
			long initBalance = sc.nextLong();
		
		
		System.out.println("\n-------------------------------\n");
			
		System.out.println("Enter Account Login Details : ");
		System.out.println("-------------------------------");
		
		boolean passwordCheck = true;
		String password ="";
		String retypePassword = "";
		while (passwordCheck){
			System.out.print("Enter account login password : ");
				password = sc.next();
			System.out.print("Retype account login password : ");
				retypePassword = sc.next();
			
			if( ! password.equals(retypePassword)){
				
				System.out.println("\nPassword incorrect, please enter again \n");
			
			} else {
			
				passwordCheck = false;
			
			}
		}
		String securityQuestion = "";
		boolean flagQuestionCheck = true;
		
		while (flagQuestionCheck){
			System.out.println("\nChoose a security question : ");
			System.out.println("1. What is your favourite color ?");
			System.out.println("2. What is the name of your pet ?");
			System.out.println("3. What is your mother's maiden name ?");
			
			int questionOption = sc.nextInt();
			
			switch (questionOption) {
			
			case 1 :
				securityQuestion = "What is your favourite color ?";
				flagQuestionCheck = false;
				break;
				
			case 2 :
				securityQuestion = "What is the name of your pet ?";
				flagQuestionCheck = false;
				break;
				
			case 3 :
				securityQuestion = "What is your mother's maiden name ?";
				flagQuestionCheck = false;
				break;

			default:
				System.out.println("\nPlease Enter correct choice...!\n");
				break;
			}
			
		}
		System.out.print("Enter Answer / Transaction password : ");
		sc.nextLine();
		String answer = sc.nextLine();
		
		
		//validating the entered credentials
		
		try {
			BankServiceImpl iBankService = new BankServiceImpl();
			validationErrors =iBankService.validateCredentials(cusName, retypePassword, pancard, email, initBalance);
		} catch (BankException bankException) {
			// TODO Auto-generated catch block
			logger.error("Exception Eccured : ", bankException);				
			System.out.println("Exception Eccured : "+ bankException);
		}
		
		
		
		
		// populate beans
		
		
		
		if(validationErrors.isEmpty()) {
			
			customer.setCustomerName(cusName);
			customer.setEmail(email);
			customer.setAddress(address);
			customer.setPancard(pancard);
			customer.setMobileNumber(mobileNumber);
			
			accountMaster.setAccountType(accountType);
			accountMaster.setAccountBalance(initBalance);
	
			user.setLoginPass(password);
			user.setSecretQuestion(securityQuestion);
			user.setTransactionPassword(answer);
			
			try {
			
				BankServiceImpl iBankService = new BankServiceImpl();
				long accountId=iBankService.createAccount(accountMaster, user, customer);
				System.out.println("Your account has been created with the Account Number : "+accountId);
			
			} catch (BankException bankException) {
				logger.error("Exception Eccured : ", bankException);				
				System.out.println("Exception Eccured : "+ bankException);
			}
		
		} else {
			
			for(String errors:validationErrors) {
				
				System.out.println(errors);
			
			}
			
		}
				
	}

}
