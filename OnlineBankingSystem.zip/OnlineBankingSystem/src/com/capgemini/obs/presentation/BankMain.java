/**
 * 
 */
package com.capgemini.obs.presentation;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.obs.dto.AccountMaster;
import com.capgemini.obs.dto.Customer;
import com.capgemini.obs.dto.FundTransfer;
import com.capgemini.obs.dto.Payees;
import com.capgemini.obs.dto.ServiceTracker;
import com.capgemini.obs.dto.Transactions;
import com.capgemini.obs.dto.User;
import com.capgemini.obs.exception.BankException;
import com.capgemini.obs.service.BankServiceImpl;
import com.capgemini.obs.service.IBankService;

public class BankMain {

	static final int ATTEMPT_LIMIT=3;// Attempt limits for the wrong password
	
	// --------Default values for the accountNumber and password
	static long accountNumber = 0l ;
	static String password = "UNKNOWN";
	static IBankService iBankService = null;
	
	 //Console object for the input from the user
	static Logger logger = Logger.getRootLogger();// Logger object for log generation

	private static Scanner sc;
	
	public static void main(String[] args) {
	
		PropertyConfigurator.configure("resources//log4j.properties");
		IBankService iBankService = null;// Create a bank service object 
		//List<String> errors=null ;
		int attempts=0;
		sc = new Scanner(System.in);
		boolean flag = true;
		String loginTable = "";
		boolean isLoggedIn = false;
		boolean isValid = false;
		boolean isValidUser = false;
		boolean isValidOption = false;
		//-----------------------------------------------------------

		
		//-----------------------------------------------------------
		System.out.println("\t\n\n******************** Welcome to the Bank Application ********************\n\n");
		do {
		
			try {
				
			if(!isLoggedIn || !isValid) {
				
				do {
					System.out.println("\tLogin as : ");
					System.out.println("\t----------------------------");
					System.out.println("\t1. Admin");
					System.out.println("\t2. Customer");
					
					int choice = sc.nextInt();
					
					switch(choice){
					
						case 1 : 
							loginTable = "AdminTable";
							flag = false;
							break;
						
						case 2 : 
							loginTable = "UserTable";
							flag = false;
							break;
							
						default:

							System.out.println("\n\n==================================================================");
							System.out.println("\tPlease enter a valid option");
							System.out.println("\n\n==================================================================");
					}
					
				}while(flag);
				
				
				System.out.print("\tEnter Account Number : ");
				accountNumber = Long.parseLong(sc.next());

				System.out.print("\tEnter Password : ");
				password = sc.next();
			
				iBankService = new BankServiceImpl();
				
				isValidUser = iBankService.isValidUser(accountNumber,password,loginTable);
				
			}
			

				
	

			
				if(!isValid) {
					iBankService = new BankServiceImpl();
					isValidUser = iBankService.isValidUser(accountNumber,password,loginTable);
					

					System.out.println("\n\n==================================================================");
					if(isValidUser){
						System.out.println("\t\t\nLogin Success\n\n");
						isLoggedIn = true;
						isValid = true;
					}else {
						System.out.println("\t\nEnter valid User Credentials\n");
						isValid = false;
					}
					System.out.println("\n\n==================================================================");
				}
			
				
			if(isValidUser){
				iBankService = new BankServiceImpl();
				attempts = iBankService.getUserAttempts(accountNumber,loginTable);
				
				iBankService = new BankServiceImpl();
				boolean isLocked = false;
				
				isLocked = iBankService.isLockedAccount(accountNumber,loginTable);
				
				while(isLocked) {
					System.out.println("\tPlease Change Your Password.");
					System.out.println("----------------------------------------------------");
					System.out.print("\tEnter New Password");
					
				String password= sc.next();
					
					System.out.print("\tRe Enter Your Password");
					String rePassword = sc.next();
					
					
					if(password.equals(rePassword))
					{
						iBankService = new BankServiceImpl();
						iBankService.updatePassword(accountNumber, rePassword,loginTable);
						iBankService = new BankServiceImpl();
						iBankService.unLockAccount(accountNumber,loginTable);
						iBankService = new BankServiceImpl();
						isLocked = iBankService.isLockedAccount(accountNumber,loginTable);
						iBankService = new BankServiceImpl();
						iBankService.setUserAttemptsZero(accountNumber,loginTable);
					}
					else
					{
						System.out.println("\tPlease Try Again!");
					}
				}
				
			} else {
				//password incorrect
				iBankService = new BankServiceImpl();
				iBankService.setUserAttempts(accountNumber,loginTable);
				
				iBankService = new BankServiceImpl();
				if(iBankService.getUserAttempts(accountNumber,loginTable) == ATTEMPT_LIMIT){
					iBankService = new BankServiceImpl();
					iBankService.lockAccount(accountNumber,loginTable);
				}
				
			}
				
			
			
			
			iBankService = new BankServiceImpl();
			if(iBankService.getUserAttempts(accountNumber,loginTable) > ATTEMPT_LIMIT){
				

				System.out.println("\n\n==================================================================");
				System.out.println("\tYOU HAVE USED ALL THE "+ ATTEMPT_LIMIT+"  ATTEMPTS");
				System.out.println("\n\n==================================================================");
				iBankService = new BankServiceImpl();
				iBankService .lockAccount(accountNumber,loginTable);
				
				System.out.println("\tForget Password?");
				System.out.println("\tAnswer this Question.To retrive your account");
				
				
				iBankService = new BankServiceImpl();
				String question= iBankService.getUserQuestion(accountNumber,loginTable);
				System.out.println(question);
				
				
				System.out.println("\tEnter the transaction password?");
				String transactionpassword =sc.next();
				iBankService = new BankServiceImpl();
				
				
				boolean isValidTransactionPassword=iBankService.isValidTransactionPassword(transactionpassword,accountNumber,loginTable);
				if(isValidTransactionPassword)
				{
					
					System.out.println("\tyour new password is sbq500# .Please Reset As early as possible");
					String newPassword="sbq500#";
					iBankService = new BankServiceImpl();
					iBankService.updatePassword(accountNumber, newPassword,loginTable);
					
					
				}
				else{

					System.out.println("\n\n==================================================================");
					System.out.println("\tYou Have Again Entered the Wrong Answer ! Please Reach Us at the Nearest Branch!");
					System.out.println("\n\n==================================================================");
				}
					
				}
				
				
			
				if(loginTable.equals("AdminTable") && isValid && attempts<ATTEMPT_LIMIT) {
					
					System.out.println("\tSelect An Option :");
					System.out.println("\t---------------------------");
					System.out.println("\t1. Open an Account");
					System.out.println("\t2. View Transactions");
					System.out.println("\t3. Exit / Logout");
					int choice = sc.nextInt();
					
					
					switch(choice){
					case 1 :
						openAccount();
						
						break;
						
					case 2 :
						viewTransactions();
						break;
					
					case 3 :
						isLoggedIn = false;
						break;
					default :
						
					
					}
								
				} else if(loginTable.equals("UserTable")&& isValid && attempts<ATTEMPT_LIMIT) {
					
					System.out.println("\tSelect An Option :");
					System.out.println("\t---------------------------");
					System.out.println("\t1. View/Mini Detailed Statement");
					System.out.println("\t2. Change in address/mobile number");
					System.out.println("\t3. Request for cheque book");
					System.out.println("\t4. Track service request");
					System.out.println("\t5. Fund Transfer");
					System.out.println("\t6. Change password");
					System.out.println("\t7. Exit/ Logout");
					int choice = sc.nextInt();
					
					
					switch(choice){
					case 1 :
						viewMiniDetailedStatements(accountNumber);		
						break;		
					case 2 :
						changeDetails(accountNumber);
						break;
					
					case 3 :
						requestCheckBook(accountNumber);
						break;
					case 4:
						trackServiceRequest(accountNumber);
						break;
					case 5:
						fundTransfer(accountNumber);
						break;
					case 6:
						changePassword();
						break;		
					case 7:
						isLoggedIn = false;
						break;
					default :
						
					
					}
					
				
				
			}
						
				
			} catch (BankException bankException) {
				
				logger.error("Exception Eccured : ", bankException);				
				System.out.println("\tException Eccured : "+ bankException);
				
			}

			int choiceLogout = 1;
			
			do{
						
				System.out.println("\tSelect option : ");
				System.out.println("\t1. Continue Application ");
				System.out.println("\t2. Confirm Exit / Logout");

				choiceLogout = sc.nextInt();
				

				System.out.println("\n\n==================================================================");
				switch (choiceLogout){
				
					case 1:
					
						
						System.out.println("\t\n\nContinued....\n\n");
						isLoggedIn = true;
						isValidOption = true;
						break; 
					
					case 2 : 
						
						System.out.println("\tLogged Out");
						isLoggedIn = false;
						isValidOption = true;
						isValid = false;
						break;
						
						
					default :
						System.out.println("\tInvalid Choice ...\nPlease enter Again\n");
						
				
				}

				System.out.println("\n\n==================================================================");
			}while(!isValidOption);
		
		}while(isValidOption);
		
		
	}

	private static void changePassword() {
		System.out.println("\tEnter the New Password :");
		String newPassword = sc.next();
		System.out.println("\tRe Enter the New Password");
		String reNewPassword=sc.next();
		if(newPassword.equals(reNewPassword))
		{
			
			try {
				iBankService = new BankServiceImpl();
				iBankService.updatePassword(accountNumber, reNewPassword,"UserTable");
				
				iBankService = new BankServiceImpl();
				iBankService.setUserAttemptsZero(accountNumber,"UserTable");

				System.out.println("\n\n==================================================================");
				System.out.println("\tYour Password Has been Updated Succesfully!");
				System.out.println("\n\n==================================================================");
				
			} catch (BankException bankException) {
				
				logger.error("Exception Eccured : ", bankException);				
				System.out.println("\tException Eccured : "+ bankException);
			}
			
			
		}
		else
		{

			System.out.println("\n\n==================================================================");
			System.out.println("\tPlease Try Again");
			System.out.println("\n\n==================================================================");
		}
		
	}

	private static void fundTransfer(long accountNumber) {
		
		try {
			
			iBankService = new BankServiceImpl();
			List<Long> accountNumbers = iBankService.getAccountNumbers(accountNumber);
			
			System.out.println("\tYour Account numbers in our bank :");
			System.out.println("\t------------------------------------------");
			
			for(int i=0;i<accountNumbers.size();i++){
				System.out.println((i+1)+" . "+accountNumbers.get(i));
			}
			System.out.println("\t------------------------------------------");
			
			
			
			int bankAccountIndex = 1;
			do {
				
				if(bankAccountIndex <=0 || bankAccountIndex > accountNumbers.size()){
					System.out.println("\tSelect Valid Account number ");
				}
				
				System.out.println("\tSelect your bank account : ");
				bankAccountIndex = sc.nextInt();
				
				
			}while(bankAccountIndex <=0 || bankAccountIndex > accountNumbers.size());
			
			long bankAccountNumber = accountNumbers.get(bankAccountIndex-1);
			
			
			
			
			System.out.println("here");
			
			iBankService = new BankServiceImpl();
			List<Payees> payeeList = iBankService.getAllPayees(bankAccountNumber);
			
			
			
			if(payeeList.isEmpty()){

				System.out.println("\n\n==================================================================");
				System.out.println("\tContact Admin to add Payee for Account Number : "+bankAccountNumber);
				System.out.println("\n\n==================================================================");
			}else{
				long availableBalance = 0l;
				System.out.println("\tYour Payees for Account number "+bankAccountNumber+" Are : ");
				System.out.println("\t------------------------------------------");
				
				System.out.println("\tPayee Account Number\tPayee Nick Name ");
				int i =1;
				for(Payees payee : payeeList){
					
					System.out.println("\t"+i+". "+payee.getPayeeAccountId()+"\t"+payee.getNickName());
					i++;
				}
				
				System.out.println("\tSelect Your Payee : ");

				int payeeAccountIndex = 1;
				do {
					if(payeeAccountIndex <=0 || payeeAccountIndex > payeeList.size()){
						System.out.println("\tSelect Valid Payee Account number ");
					}
					
					payeeAccountIndex = sc.nextInt();
					
				}while(payeeAccountIndex <=0 || payeeAccountIndex > payeeList.size());
				
				long payeeAccountNumber = payeeList.get(payeeAccountIndex-1).getPayeeAccountId();
				
				System.out.println("\tEnter Transfer Ammount : ");
				System.out.println("\t------------------------------------------");
				long transferAmmount = sc.nextLong();
				
				iBankService = new BankServiceImpl();
				 availableBalance = iBankService.isAmountTransferable(bankAccountNumber, transferAmmount);
				
				
				if(availableBalance >= transferAmmount)
				{
				iBankService = new BankServiceImpl();
				FundTransfer fundTransfer = iBankService.fundTransfer(bankAccountNumber,payeeAccountNumber,transferAmmount);
				
				if(fundTransfer != null){
					
					showFundTransaction(fundTransfer);
					
				}
				}
				else {
					
					System.out.println("\tFund Transfere Failed \n\t Your Available Balance is "+availableBalance);
					
				}
								
			}

		}catch(BankException bankException){
			
			logger.error("Exception Occured : ", bankException);				
			System.out.println("\tException Occured : "+ bankException);
		}
		
	}

	private static void showFundTransaction(FundTransfer fundTransfer) {

		System.out.println("\tFund Transfer : ");
		System.out.println("\t--------------------------------------------");
		System.out.println("\tYour Account no : "+fundTransfer.getAccountId());
		System.out.println("\tPayee Account no : "+fundTransfer.getPayeeAccountId());
		System.out.println("\tTransfered amount : "+fundTransfer.getTranferAmmount());
		
	}

	private static void trackServiceRequest( long accountNumber) {
		ServiceTracker serviceTracker = null;
		try{
			iBankService = new BankServiceImpl();
			serviceTracker = iBankService.trackServiceRequest(accountNumber);
			
			if(serviceTracker!=null)
			{
				showServiceDetals(serviceTracker);
			}
			else
			{

				System.out.println("\n\n==================================================================");
				System.out.println("\tNo Request Available for Account Number : "+accountNumber);
				System.out.println("\n\n==================================================================");
			}
			
		}catch(BankException bankException){

			logger.error("Exception Eccured : ", bankException);				
			System.out.println("\tException Eccured : "+ bankException);
		}
		
	}
	
	private static void showServiceDetals(ServiceTracker serviceTracker) {
		System.out.println("\tYour Servise Request Details for account no"+serviceTracker.getAccountId()+" : ");
		System.out.println("\t----------------------------------------------");
		System.out.println("\tService id : "+serviceTracker.getServiceId());
		System.out.println("\tDescription : "+serviceTracker.getServiceDescription());
		System.out.println("\tRequested date : "+serviceTracker.getServiceRaisedDate());
		System.out.println("\tService Status : "+serviceTracker.getServiceStatus());
		System.out.println("\t-----------------------------------------------");
		
	}

	private static void requestCheckBook(long accountId) {

		try {
			
			System.out.println("\n\n==================================================================");
			iBankService = new BankServiceImpl();
			if(iBankService.checkRequestAvailable(accountId)) {
				System.out.println("\tYou have already Requested for your check book");
			}
			else
			{
				
				iBankService = new BankServiceImpl();
				
				ServiceTracker serviseTracker = pupulateServiceTracker(accountId);
				
				boolean isRequested = iBankService.requestCheckBook(serviseTracker);
				if(isRequested){
					System.out.println("\tYour Request for CheckBook has been submitted");
				}else{
					System.out.println("\tYour Request for CheckBook cannot be submitted");
				}
			}

			System.out.println("\n\n==================================================================");
		}catch (BankException bankException){

			logger.error("Exception Eccured : ", bankException);				
			System.out.println("\tException Eccured : "+ bankException);
		}
	}

	private static ServiceTracker pupulateServiceTracker(long accountId) {

		ServiceTracker serviceTracker = new ServiceTracker();

		serviceTracker.setAccountId(accountId);
		
		String serviceDescription = "Request for Checkbook";
		serviceTracker.setServiceDescription(serviceDescription);
		
		String serviceStatus = "Requested";
		serviceTracker.setServiceStatus(serviceStatus);
		
		return serviceTracker;
	}

	private static void changeDetails(long accountNumber) {
		
		try {
			iBankService = new BankServiceImpl();
			Customer customer =iBankService.getCustomerDetails(accountNumber);
			System.out.println("\tThe Pervious Details are:");
			System.out.println("\tMobile Number :" +customer.getMobileNumber());
			System.out.println("\tAddress:"+customer.getAddress());
			System.out.println("\twhich Details has to be Updated:");
			System.out.println("\t1.MobileNumber");
			System.out.println("\t2.Address");
			
			int choice = sc.nextInt();
			switch(choice){
			case 1 :
				System.out.println("\tEnter new Mobile Number");
				String newMobileNumber= sc.next();
				iBankService = new BankServiceImpl();
				int result=iBankService.updateMobileNumber(accountNumber, newMobileNumber);
				System.out.println("\n\n==================================================================");
				if(result>0)
					System.out.println("\tSuccesfully Updated!");
				else
					System.out.println("\tNot Succesfull");
				System.out.println("\n\n==================================================================");
				
				break;
				
			case 2 :
				
				System.out.println("\tEnter new Address");
				String newAddress= sc.next();
				iBankService = new BankServiceImpl();
				int result2=iBankService.updateMobileNumber(accountNumber, newAddress);
				System.out.println("\n\n==================================================================");
				if(result2>0)
					System.out.println("\tSuccesfully Updated!");
				else
					System.out.println("\tNot Succesfull");
				System.out.println("\n\n==================================================================");
				
				break;
			
			
			default :
				
			
			}
			
			
			
		} catch (BankException bankException) {
			logger.error("Exception Eccured : ", bankException);				
			System.out.println("\tException Eccured : "+ bankException);
		}
		
		
		
		
	}

	private static void viewMiniDetailedStatements(long accountNum) {
		
		System.out.println("\tSelect An Option :");
		System.out.println("\t---------------------------");
		System.out.println("\t1. Mini statements");
		System.out.println("\t2. Detailed Statements");

		int choice = sc.nextInt();
		
		
		switch(choice){
		case 1 :
			System.out.println("\tMini Statement : ");
			/*
			 *  call for getting mini statement
			 *
			 * */
			viewMiniStatement(accountNum);
			break;
			
		case 2 :
			System.out.println("\tDetailed Statement : ");
			/*
			 *  call for getting detailed statement
			 * 
			 * */
			viewDetailedStatement(accountNum);
			break;
		

		default :
		}
			
		
		
		
		
	}

	private static void viewMiniStatement(long accountNum) {

		List<Transactions> transactionList = null;
		
		try {
			iBankService = new BankServiceImpl();
		
			transactionList = iBankService.viewMiniStatement(accountNum);
			//System.out.println("\tMini Statement : ");
			//System.out.println("\t--------------------------------------");
			viewStatement(transactionList);
		
		} catch (BankException bankException ){
				
			logger.error("Exception Eccured : ", bankException);				
			System.out.println("\tException Eccured : "+ bankException);
			
		}
	}

	private static void viewDetailedStatement(long accountNum) {
		
		List<Transactions> transactionList = null;
		try {
			iBankService = new BankServiceImpl();
			

			
				
			String startDate = "";
			String endDate = "";
			do {
				
				System.out.println("\tEnter dates in [DD/MM/YYYY] format : ");
				
				System.out.print("\tEnter Starting Date : ");
					startDate = sc.next();
				System.out.print("\tEnter Ending Date : ");
					endDate = sc.next();
				
			} while(! iBankService.isValiddates(startDate,endDate));
				
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
				Date startDte = new java.sql.Date(dateFormat.parse(startDate).getTime());
				Date endDte = new java.sql.Date(dateFormat.parse(endDate).getTime());
				
				iBankService = new BankServiceImpl();
			
				transactionList = iBankService.viewDetailedStatement(accountNum,startDte,endDte);
					
				System.out.println("\tDetailed Statement : ");
				System.out.println("\t--------------------------------------");
	
				viewStatement(transactionList);
		
		
		} catch(ParseException parseException ) {
			
			logger.error("Exception Eccured : ", parseException);				
			System.out.println("\tException Eccured : "+ parseException);
			
		} catch(BankException bankException ) {
			
			logger.error("Exception Eccured : ", bankException);				
			System.out.println("\tException Eccured : "+ bankException);
			
		}
	}
	
	private static void viewStatement(List<Transactions> transactionList) throws BankException {			
			
			if(transactionList == null){
				
				System.out.println("\n\n==================================================================");
				System.out.println("\tNo Transactions Available");
				System.out.println("\n\n==================================================================");
				
			} else {
			
				//System.out.println("\tYour all Account's Statement : ");
				//System.out.println("\t-----------------------------------------");
				
				if(!transactionList.isEmpty()){
					System.out.println("\t***********************************************************************************************************************");
					System.out.println("\tTransaction id\t\t|Description\t\t|Date\t|Type[Debit(D)/Credit(C)]\t|Amount\t\t|Account ID\n");
					System.out.println("\t-----------------------------------------------------------------------------------------------------------------------");
					for(Transactions tBean : transactionList){
						System.out.print("\t");
						System.out.print(" "+tBean.getTransactionId()+"\t");
						System.out.print("         |"+tBean.getTranDescription()+"\t");
						System.out.print("    |"+tBean.getDateOfTransaction()+"\t");
						System.out.print(" |"+tBean.getTransactionType()+"\t");
						System.out.print("      \t\t\t|"+tBean.getTranAmount()+"\t");
						System.out.print("         |"+tBean.getAccountId()+"\t\n");
						System.out.print("\t**********************************************************************************************************************");
						System.out.println();
						
					}
					
				} else {
					System.out.println("\n\n==================================================================");
					System.out.println("\tNo Transactions Available");
					System.out.println("\n\n==================================================================");
				}
				
			}
		
	}

	private static void viewTransactions() {
		
		boolean isValidTransactions = false;
		
		do {
			System.out.println("\tEnter Your Choice : \n");
			System.out.println("\t1. Daily Transaction");
			System.out.println("\t2. Monthly Transaction");
			System.out.println("\t3. Yearly Transaction");
			
			int choice = sc.nextInt();
			
			switch(choice){
			
			case 1 :
				System.out.println("\tEnter Date (DD): ");
				int day = sc.nextInt();
				viewTransaction("daily",accountNumber,day);
				isValidTransactions = true;
				break;
				
			case 2 :
				System.out.println("\tEnter Month in digits (MM): ");
				int month = sc.nextInt();
				viewTransaction("monthly",accountNumber,month);
				isValidTransactions = true;
				break;
			
			case 3 :
				System.out.println("\tEnter Year in digits (YY): ");
				int year = sc.nextInt();
				viewTransaction("yearly",accountNumber,year);
				isValidTransactions = true;
				break;
			
			default :
				System.out.println("\tPlease enter right choice ...!");
			}
			
		}while(!isValidTransactions);
	}

	private static void viewTransaction(String transactionType,long accountNumber, int number) {
		
		try{
			
			iBankService = new BankServiceImpl();
			List<Transactions> transactionList = null;
			
			transactionList = iBankService.getTransactions(transactionType, accountNumber,number);
			
			viewStatement(transactionList);
			
		}catch(BankException bankException){
			
			logger.error("Exception Eccured : ", bankException);				
			System.out.println("\tException Eccured : "+ bankException);
			
		}
		
	}

	private static void openAccount() {
		
		AccountMaster accountMaster = new AccountMaster();
		Customer customer = new Customer();
		User user = new User();
		List<String> validationErrors = new ArrayList<>();
		
		
			
		System.out.println("\tEnter the Details : ");
		System.out.println("\t===========================================");
		
		int isCorrectDetail = 1;
		
		
		boolean isSave = false;
		String cusName = "";
		String email = "";
		String address = "";
		String pancard = "";
		String mobileNumber = "";
		String accountType = "";
		String password ="";
		String retypePassword = "";
		long initBalance =0l;
		String securityQuestion = "";
		String answer ="";
		
		
		do {
			
			System.out.println("\tEnter Profile details : ");
			System.out.println("\t-------------------------------");
			System.out.print("\tEnter the Name : ");		
				sc.nextLine();
				cusName= sc.nextLine();
			System.out.print("\tEnter the Email id:");	
				email= sc.nextLine();
			System.out.print("\tEnter the Address:");		
				address= sc.nextLine();
			System.out.print("\tEnter PANCARD Number");	
				pancard = sc.nextLine();
			 System.out.print("\tEnter Mobile Number:");
			    mobileNumber=sc.nextLine();
			System.out.println("\t\n-------------------------------\n");
			

		
			System.out.println("\tEnter Account Details : ");
			System.out.println("\t-------------------------------");
			boolean flagAccountType = true;
			
			
			while(flagAccountType){
				
				System.out.println("\tChoose your Account type : ");
				System.out.println("\t1. Saving");
				System.out.println("\t2. Current");
				
				int accOption = sc.nextInt();
				
				switch(accOption){
					
				case 1:
					accountType = "Saving";
					flagAccountType = false;
					break;
				
				case 2 :
					accountType = "Current";
					flagAccountType = false;
					break;
					
				default:
					System.out.println("\t\nPlease Enter correct choice...!\n");
				}
			}
			
			System.out.print("\tEnter initial Balance : ");
				initBalance = sc.nextLong();
			
			
			System.out.println("\t\n-------------------------------\n");
				
			System.out.println("\tEnter Account Login Details : ");
			System.out.println("\t-------------------------------");
			
			boolean passwordCheck = true;

			while (passwordCheck){
				System.out.print("\tEnter account login password : ");
					password = sc.next();
				System.out.print("\tRetype account login password : ");
					retypePassword = sc.next();
				
				if( ! password.equals(retypePassword)){
					System.out.println("");
					System.out.println("\t\nPassword incorrect, please enter again \n");
				
				} else {
				
					passwordCheck = false;
				
				}
			}
			
			boolean flagQuestionCheck = true;
			
			while (flagQuestionCheck){
				System.out.println("\t\nChoose a security question : ");
				System.out.println("\t1. What is your favourite color ?");
				System.out.println("\t2. What is the name of your pet ?");
				System.out.println("\t3. What is your mother's maiden name ?");
				
				int questionOption = sc.nextInt();
				
				switch (questionOption) {
				
				case 1 :
					securityQuestion = "What is your favourite color ?";
					flagQuestionCheck = false;
					break;
					
				case 2 :
					securityQuestion = "What is the name of your pet ?";
					flagQuestionCheck = false;
					break;
					
				case 3 :
					securityQuestion = "What is your mother's maiden name ?";
					flagQuestionCheck = false;
					break;
	
				default:
					System.out.println("\t\nPlease Enter correct choice...!\n");
					break;
				}
				
			}
			System.out.print("\n\tEnter Answer / Transaction password : ");
			sc.nextLine();
			answer = sc.nextLine();
			
			System.out.println("Select option : ");
			System.out.println("1. Save And Proceed");
			System.out.println("2. Re-Enter ");
			
			isCorrectDetail = sc.nextInt();
			boolean correctOption = false;
			do {
				switch (isCorrectDetail) {
				case 1:
					System.out.println("Saved Profile Details...");
					isSave = true;
					correctOption = true;
					break;
	
				case 2 :
					System.out.println("Re- Enter Data :");
					isSave = false;
					correctOption = true;
					break;
				default:
					System.out.println("Please Choose correct option");
					break;
				}
			}while (!correctOption);
			
			
		}while(!isSave);
		
		
		
		//validating the entered credentials
		
		try {
			BankServiceImpl iBankService = new BankServiceImpl();
			validationErrors =iBankService.validateCredentials(cusName, retypePassword, pancard, email, initBalance);
		} catch (BankException bankException) {
			// TODO Auto-generated catch block
			logger.error("Exception Eccured : ", bankException);				
			System.out.println("\tException Eccured : "+ bankException);
		}
		
		
		
		
		// populate beans
		
		
		
		if(validationErrors.isEmpty()) {
			
			customer.setCustomerName(cusName);
			customer.setEmail(email);
			customer.setAddress(address);
			customer.setPancard(pancard);
			customer.setMobileNumber(mobileNumber);
			
			accountMaster.setAccountType(accountType);
			accountMaster.setAccountBalance(initBalance);
	
			user.setLoginPass(password);
			user.setSecretQuestion(securityQuestion);
			user.setTransactionPassword(answer);
			
			try {
			
				BankServiceImpl iBankService = new BankServiceImpl();
				long accountId=iBankService.createAccount(accountMaster, user, customer);
				System.out.println("\n\n==================================================================");
				System.out.println("\n\n\tYour account has been created with the Account Number : "+accountId+"\n\n");
				System.out.println("\n\n==================================================================");
			
			} catch (BankException bankException) {
				logger.error("Exception Eccured : ", bankException);				
				System.out.println("\tException Eccured : "+ bankException);
			}
		
		} else {
			
			for(String errors:validationErrors) {
				
				System.out.println(errors);
			
			}
			
		}
				
	}

}
