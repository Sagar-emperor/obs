$('#showMyModal').on('click', function () {
	
	$(".loader").fadeIn("slow");
	$.ajax({
        url: 'showAddUser.obj',
        type: 'GET',
        data:'' ,
    }).done(function(responseText, statusText, xhr, $form){
    	$(".loader").fadeOut("fast");
    	$('#myModal').html(responseText);
        $('#myModal').modal('show');
        $('#userFormBtn').text("Create User");
        })
        .fail(function(responseText, statusText, xhr, $form){
        	$(".loader").fadeOut("fast");
        	alert('Server not responding...');
        	 $('#userFormBtn').text("Create User");
        });
	
});

$('#showQuestionModal').on('click', function () {


        $('#questionModal').modal('show');
        
      
});

$('#questionType').on('change', function () {
	
	if($(this).val()!=0){
		$("#questionType").next().next().html("");
	}

	if($(this).val()==1||$(this).val()==2){
		$('#AppendOption').html('<center><a class="btn btn-info btn-md" id="AddOption">Add Option</a><div id="optError" class="redText"></div></center>');}
	else{
		$('#AppendOption').html(''); 
	}
	$('#allOptions').html(''); 
});

$('#AppendOption').on('click','a#AddOption', function(e) {
	 $('#allOptions').append('<strong>Option : </strong><input type="text" class="form-control optionText" name="options"/><span class="glyphicon glyphicon-trash" onclick="optionRemove(this)"></span><br/><div class="redText"></div>');
	  
	});

function optionRemove(a) {
	$(a).next().remove();
	$(a).prev().prev().remove();
	$(a).prev().remove();
	$(a).remove();
	  
}

$('.editUser').on('click', function () {
	
	$(".loader").fadeIn("slow");
	$.ajax({
        url: 'showEditUsers.obj',
        type: 'POST',
        data:{userId:$(this).attr("userid")} ,
    }).done(function(responseText, statusText, xhr, $form){
    	$(".loader").fadeOut("fast");
    	$('#myModal').html(responseText);
        $('#myModal').modal('show');
        $('#userFormBtn').text("Update");
        })
        .fail(function(responseText, statusText, xhr, $form){
        	$(".loader").fadeOut("fast");
        	alert('Server not responding...');
        	 $('#userFormBtn').text("Update");
        });
	
});

$(document).ready(function() {
	$('#myModal').on('click','button#userFormBtn', function(e) {
          
		$(".loader").fadeIn("slow");
            e.preventDefault();
           var action= $('#userFormBtn').text();
           var targetPage="";
           if(action=="Create User"){targetPage="createUser.obj"}
           else{targetPage="updateUserDetails.obj"}
           
            var $form = $('#userForm');
            
            $.ajax({
                url: targetPage,
                type: 'POST',
                data: $form.serialize(),
                
            }).done(function(responseText, statusText, xhr, $form) {
            	$(".loader").fadeOut("fast");
            	$('#myModal').html(responseText);
                // console.log(responseText);
            }).fail(function(responseText, statusText, xhr, $form){
            	$(".loader").fadeOut("fast");
            	alert('Server not responding...');
            });
        });
});


function validateQuestion(){
	var result=true;
	var errorListLength=$(".redText").length;
	for(var i=0;i<errorListLength;i++){
		$(".redText")[0].innerHTML='';
	}
	
	if($("#quesText").val().trim()==""){
		$("#quesText").next().next().html("question text field cannot be empty");
		return false;
	}
	
	if($("#questionType").val()==0){
		$("#questionType").next().next().html("select a question type");
		$("#questionType").focus();
		return false;
	}
	else{
		if($("#questionType").val()==1||$("#questionType").val()==2)
		{
			optlength=$("input[type='text']").length;
			if(optlength==0){
				$("#optError").html("add atleast one option for the question");
				return false;
			}
			
			for(var i=0;i<optlength;i++){
				
				if($("input[type='text']")[i].value.trim()==""){
					$("input[type='text']")[i].nextSibling.nextSibling.nextSibling.innerHTML="options field cannot be empty";
					$("input[type='text']")[i].focus();
					result=false;
				}
				else{
					$("input[type='text']")[i].nextSibling.nextSibling.nextSibling.innerHTML="";
					
				}
			}
	
			
		}
		
		
	}
	if(result){
		$("#userForm").submit();
	}	
	
}


function validateDistributionList(){
	
	var result =true;
	var days=$("#expiryTxt").val();
	
	if(isNaN($("#expiryTxt").val())){
		$("#expiryError").html("value should be a number");
		result =false;
	}
	else{
		$("#expiryError").html("");
	}
	if($("#expiryTxt").val().trim()==""){
		$("#expiryError").html("field should not be blank");
		result =false;
	}
	
	
	var distList=$("input[type='checkbox']");
	var distListLength=distList.length;
	var count=0;
	for(var i=0;i<distListLength;i++)
	{
		if($("input[type='checkbox']")[i].checked){count++;}
	}
	
	if(count==0){
		$("#distributionListError").html("Select atleast one responder");
		result =false;
	}
	else{
		$("#distributionListError").html("");
	}
	
	if(result){$("#distributeForm").submit();}
	
}