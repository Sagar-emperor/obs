package com.igate.surveymanagement.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.igate.surveymanagement.bean.UserBean;

@Repository
public class CommonDAOImpl implements ICommonDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	CommonRowMapper commonMapper;
	
	@Override
	public List<UserBean> validate(UserBean user) {
		// TODO Auto-generated method stub
		
		System.out.println("in dao ");
		List<UserBean> user1=new ArrayList<UserBean>();
		
		String status="y"; 
		String query="SELECT USER_ID,FIRST_NAME,LAST_NAME,USER_TYPE,USER_ACTIVE,USER_PASSWORD FROM user_master WHERE USER_ID=? AND USER_PASSWORD=? AND USER_ACTIVE='y'";
		Object[] params=new Object[]{user.getUserId(),user.getUserPassword()};
		
	
		user1= jdbcTemplate.query(query, params,commonMapper);
		
		return  user1;
	}

	
	
	
	
	@Override
	public int newUser(UserBean newuser) {
		// TODO Auto-generated method stub
		
		
		
		
			String id_query="SELECT id_seq.nextval FROM DUAL ";
			
			String add_user_query="INSERT INTO USER_MASTER VALUES(?,?,?,?,?,?)";
			
			String user_status="y";
			int user_id=jdbcTemplate.queryForObject(id_query,Integer.class);
			
			String check_user_query="SELECT COUNT(*) FROM user_master WHERE user_id=? ";
			Object[] param1=new Object[]{user_id};
			int user_count=jdbcTemplate.queryForObject(check_user_query,param1,Integer.class);
			
			if(user_count>0)
			{
				return 0;
			}
			
			else
			{
			Object[] params=new Object[]{user_id,newuser.getUserPassword(),newuser.getFirstName(),newuser.getLastName(),newuser.getUserType(),user_status};		
			int new_user_count=jdbcTemplate.update(add_user_query, params);
			return user_id;
			
		}
		
		
	}





	@Override
	public List<UserBean> getAllUserList() {
			
		String sql="SELECT USER_ID,FIRST_NAME,LAST_NAME,USER_TYPE,USER_ACTIVE,USER_PASSWORD From user_master ";
		List<UserBean> userList=(List<UserBean>) jdbcTemplate.query(sql, commonMapper);
		return userList;
	}






	@Override
	public UserBean setUserStatus(String status) {
		String setStatus="";
		if(status.equalsIgnoreCase("y")){setStatus="n";}
		if(status.equalsIgnoreCase("n")){setStatus="y";}
		
		String sql="Update ";
		Object[] params=new Object[]{Integer.parseInt(setStatus)};
		return null;
	}





	@Override
	public UserBean getUserDetails(String userId) {
		String sql="SELECT USER_ID,FIRST_NAME,LAST_NAME,USER_TYPE,USER_ACTIVE,USER_PASSWORD From user_master Where user_id=? ";
		Object[] params=new Object[]{Integer.parseInt(userId)};
		return (UserBean) jdbcTemplate.queryForObject(sql,params, commonMapper);
	}





	@Override
	public Boolean updateUserDetails(UserBean user) {
		Boolean result=false;
		String sql="Update user_master set first_name=?, last_name=?,user_type=?,USER_PASSWORD=? where user_id=?";
		Object[] params=new Object[]{user.getFirstName(),user.getLastName(),user.getUserType(),user.getUserPassword(),Integer.parseInt(user.getUserId())};
		int count=jdbcTemplate.update(sql,params);
		if(count>0){
			result=true;
		}
		else{
			result=false;
		}
		return result;
	}






}
