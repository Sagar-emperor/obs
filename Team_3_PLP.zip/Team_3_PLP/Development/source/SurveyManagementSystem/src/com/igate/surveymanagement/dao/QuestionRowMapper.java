package com.igate.surveymanagement.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.igate.surveymanagement.bean.QuestionBean;


@Repository("questionRowMapper")
public class QuestionRowMapper implements RowMapper {

	@Override
	public Object mapRow(ResultSet rs, int index) throws SQLException {
		
		QuestionBean question=new QuestionBean();
		question.setQuesId((new Integer(rs.getInt(1))).toString());
		question.setQuesType((new Integer(rs.getInt(2))).toString());
		question.setQuesText(rs.getString(3));
		question.setAnswers(null);
		question.setOptions(null);
		return question;
	}

}
