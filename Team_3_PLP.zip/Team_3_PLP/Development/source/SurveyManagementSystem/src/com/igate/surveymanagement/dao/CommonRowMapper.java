package com.igate.surveymanagement.dao;



import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.igate.surveymanagement.bean.UserBean;

@Repository
public class CommonRowMapper implements RowMapper {

	@Override
	public Object mapRow(ResultSet rs, int index) throws SQLException {
		// TODO Auto-generated method stub
		
		UserBean user=new UserBean();
		
		user.setUserId(rs.getString(1));
		user.setFirstName(rs.getString(2));
		user.setLastName(rs.getString(3));
		user.setUserType(rs.getString(4));
		user.setActiveUser(rs.getString(5));
		user.setUserPassword(rs.getString(6));

		return user;
	}

}
