package com.igate.surveymanagement.dao;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.helpers.Loader;
import java.net.URL;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

//@Aspect
public class LogInfo {
	
	//	@Pointcut("execution(* com.igate.demo.*.*(..))")
		public void configure(){ }
	    
	    	    
	//	@Before("configure()")
	    public void configureLogging() throws Throwable {
	         Object point = null;
	         Logger myLog = Logger.getLogger(LogInfo.class);
	         
	         URL url=Loader.getResource("log4j.properties");
	         PropertyConfigurator.configure(url.getFile());
	         
	         try {
	            
	               myLog.info("Date:" + new java.util.Date().toString());
	              
	         } catch (Exception e) {
	               System.out.println("Exception occured");
	      }
	     
	  }
}
