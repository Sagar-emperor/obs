package com.igate.surveymanagement.service;

import java.util.List;






import com.igate.surveymanagement.bean.QuestionBean;
import com.igate.surveymanagement.bean.SurveyBean;
import com.igate.surveymanagement.bean.UserBean;


public interface ISurveyorService {
	public List<QuestionBean> reviewSurvey(String surveyId);
	public boolean createsurveyId(SurveyBean survey,String userId);
	public boolean createSurvey(SurveyBean survey,QuestionBean question);
	public List<UserBean> validate(UserBean login);
	public List<SurveyBean> getDistributedSurveyList();
	
	public List<SurveyBean> getSurveyDistributionList();

	public List<UserBean> getDistributionNumber(String surveyId);
	public  int setDistributionStatus(String[] userList,String expiryDays,String surveyId);
	public List<SurveyBean> getRespondedSurveyList();
	
	public List<SurveyBean> getSurveyList();
	

	public List<QuestionBean> getSurveyQuestions(String surveyId);
	public boolean checkDistributeSurvey(String surveyId);
	public SurveyBean viewSurveyById(String SurveyId);
	public boolean editSurveyDetails(SurveyBean surveyBean);
	public boolean editSurveyQuestions(List<QuestionBean> quesList);
	public boolean deleteQuestions(String quesId);
	public boolean deleteSurvey(String surveyId);

}
