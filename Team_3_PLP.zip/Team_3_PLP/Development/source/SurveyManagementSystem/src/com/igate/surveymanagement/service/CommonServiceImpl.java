package com.igate.surveymanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igate.surveymanagement.bean.UserBean;
import com.igate.surveymanagement.dao.CommonDAOImpl;

@Service
public class CommonServiceImpl implements ICommonService {
	@Autowired
	CommonDAOImpl dao;
	
	@Override
	public List<UserBean> validate(UserBean login) {
		// TODO Auto-generated method stub
		return dao.validate(login);
	}

	
	
	@Override
	public int newUser(UserBean newuser) {
		// TODO Auto-generated method stub
		return dao.newUser(newuser);
	}



	@Override
	public List<UserBean> getAllUserList() {
		
		return dao.getAllUserList();
	}



	@Override
	public UserBean getUserDetails(String userId) {
		
		return dao.getUserDetails(userId);
	}



	@Override
	public Boolean updateUserDetails(UserBean user) {
		// TODO Auto-generated method stub
		return dao.updateUserDetails(user);
	}



	@Override
	public UserBean setUserStatus(String status) {
		// TODO Auto-generated method stub
		return dao.setUserStatus(status);
	}
}
