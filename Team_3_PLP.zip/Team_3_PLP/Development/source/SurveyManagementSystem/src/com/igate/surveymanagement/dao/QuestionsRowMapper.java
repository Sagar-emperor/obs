package com.igate.surveymanagement.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.igate.surveymanagement.bean.QuestionBean;

public class QuestionsRowMapper implements RowMapper{

	@Override
	public Object mapRow(ResultSet resultSet, int index) throws SQLException {
		// TODO Auto-generated method stub
		QuestionBean questionBean=new QuestionBean();
		questionBean.setQuesType(resultSet.getString(1));
		questionBean.setQuesText(resultSet.getString(2));
		Integer quesId=new Integer(resultSet.getInt(3));
		questionBean.setQuesId(quesId.toString());
		return questionBean;
	}

}
