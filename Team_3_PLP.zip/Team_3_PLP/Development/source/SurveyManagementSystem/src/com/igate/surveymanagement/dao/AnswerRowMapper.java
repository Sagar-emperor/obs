package com.igate.surveymanagement.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.igate.surveymanagement.bean.AnswerBean;
import com.igate.surveymanagement.bean.QuestionBean;


@Repository("answerRowMapper")
public class AnswerRowMapper implements RowMapper {

	@Override
	public Object mapRow(ResultSet rs, int index) throws SQLException {
		
		AnswerBean answer=new AnswerBean();
		answer.setUserName(rs.getString(1));
		answer.setUserId((new Integer(rs.getInt(2))).toString());
		answer.setAnswer(rs.getString(3));
		return answer;
	}

}
