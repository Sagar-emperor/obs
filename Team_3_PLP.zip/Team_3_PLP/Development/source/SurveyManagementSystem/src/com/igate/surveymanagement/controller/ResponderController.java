package com.igate.surveymanagement.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriInfo;

import org.jboss.resteasy.spi.HttpRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.igate.surveymanagement.bean.AnswerBean;
import com.igate.surveymanagement.bean.OptionsBean;
import com.igate.surveymanagement.bean.QuestionBean;
import com.igate.surveymanagement.bean.SurveyBean;
import com.igate.surveymanagement.bean.UserBean;
import com.igate.surveymanagement.service.IResponderService;


@Controller
public class ResponderController {
	
	@Autowired
	IResponderService service;
	
	private UserBean user;
	
	@RequestMapping(value="/viewResponderSurveyList")
	public String checkResponderSurveyList(Model model){
		
		model.addAttribute("user",user);
		List<SurveyBean> viewResponderSurvey=service.getSurveyList(user.getUserId());
		model.addAttribute("viewResponderSurvey",viewResponderSurvey);
		model.addAttribute("responderId",user.getUserId());
		return "surveyViewResponderSurveyList";
	}
	
	@RequestMapping(value="/showResponderHome")
	public String viewResponderSurveyList(Model model,HttpSession session){
		user=(UserBean) session.getAttribute("userObj");
		
		model.addAttribute("user",user);
		
		List<SurveyBean> viewResponderSurvey=service.getSurveyList(user.getUserId());
		model.addAttribute("viewResponderSurvey",viewResponderSurvey);
		model.addAttribute("responderId",user.getUserId());
		return "surveyViewResponderSurveyList";
	}
	
	
	@RequestMapping(value="/viewSurvey")
	public String viewSurvey(@RequestParam("surveyId") String surveyId, Model model){
		
		model.addAttribute("user",user);
		List<QuestionBean> responderQuesList=service.getSurveyDetails(surveyId);
		model.addAttribute("responderQuesList",responderQuesList);
		model.addAttribute("surveyId",surveyId);
		return "surveyViewResponderSurvey";
	}
		
	
	@RequestMapping(value="/respondSurvey")
	public String respondSurvey(HttpServletRequest request,Model model){
	
		model.addAttribute("user",user);
		String resultMsg="";
		List<QuestionBean> quesList=new ArrayList<QuestionBean>();
		
		int totalQues=Integer.parseInt(request.getParameter("totalQues"));
		String surveyId=request.getParameter("surveyId");
		if(totalQues>0)
		{
			for(int index=0;index<totalQues;index++){
				
				String id=request.getParameter("ques"+index+"-Id");
				String type=request.getParameter("ques"+index+"-Type");
				String[] options;
				options=request.getParameterValues("ques"+index+"-option");
				
				List<OptionsBean> optList=new ArrayList<OptionsBean>();
				List<AnswerBean> ansList=new ArrayList<AnswerBean>();
				
				if(type.equalsIgnoreCase("1") || type.equalsIgnoreCase("2")){
					for(String str:options){
					
						OptionsBean opt=new OptionsBean();
						opt.setOptionDesc(str);
						optList.add(opt);
					}
				}
				if(type.equalsIgnoreCase("3") || type.equalsIgnoreCase("4")){
					for(String str:options){
					
						AnswerBean ans=new AnswerBean();
						ans.setAnswer(str);
						ansList.add(ans);
					}
				}
				
				
				//adding queslist and anslist to questions
				QuestionBean ques=new QuestionBean();
				ques.setQuesId(id);
				ques.setQuesType(type);
				ques.setOptions(optList);
				ques.setAnswers(ansList);
				quesList.add(ques);
			}
		}
		
		int res=service.respondSurvey(surveyId,user.getUserId(), quesList);
		
		if(res>0){
			resultMsg="Response has been submitted succefully";
		}
		else{
			resultMsg="Failed to submit your response";
		}
		
		model.addAttribute("msg",resultMsg);
		return "surveyViewResponderSurvey";
		
	}
	
}
