package com.igate.surveymanagement.dao;

import java.util.List;

import com.igate.surveymanagement.bean.QuestionBean;
import com.igate.surveymanagement.bean.SurveyBean;


public interface IResponderDAO {
	public List<SurveyBean> getSurveyList(String responderId);
	public List<QuestionBean> getSurveyDetails(String surveyId);
	public int respondSurvey(String surveyId,String userId,List<QuestionBean> quesList);
}
