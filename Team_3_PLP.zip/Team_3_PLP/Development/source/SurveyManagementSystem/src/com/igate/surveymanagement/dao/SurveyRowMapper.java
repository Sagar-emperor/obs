package com.igate.surveymanagement.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.igate.surveymanagement.bean.OptionsBean;
import com.igate.surveymanagement.bean.QuestionBean;
import com.igate.surveymanagement.bean.SurveyBean;


@Repository("surveyRowMapper")
public class SurveyRowMapper implements RowMapper {

	@Override
	public Object mapRow(ResultSet rs, int index) throws SQLException {
		
		SurveyBean survey=new SurveyBean();
		survey.setSurveyId(new Integer(rs.getInt(1)).toString());
		survey.setSurveyTitle(rs.getString(2));
		survey.setSurveyDescription(rs.getString(3));
		return survey;
	}

}
