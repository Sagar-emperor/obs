package com.igate.surveymanagement.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.igate.surveymanagement.bean.OptionsBean;
import com.igate.surveymanagement.bean.QuestionBean;


@Repository("optionsRowMapper")
public class OptionRowMapper implements RowMapper {

	@Override
	public Object mapRow(ResultSet rs, int index) throws SQLException {
		
		OptionsBean option=new OptionsBean();
		option.setOptionId((new Integer(rs.getInt(1))).toString());
		option.setCount(rs.getInt(2));
		option.setOptionDesc(rs.getString(3));
		return option;
	}

}
