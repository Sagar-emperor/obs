package com.igate.surveymanagement.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.igate.surveymanagement.bean.SurveyBean;

public class SurveyorRowMapper implements RowMapper{

	@Override
	public Object mapRow(ResultSet resultSet, int index) throws SQLException {
		// TODO Auto-generated method stub
		SurveyBean surveyBean=new SurveyBean();
		surveyBean.setSurveyTitle(resultSet.getString(1));
		surveyBean.setSurveyDescription(resultSet.getString(2));
		Integer surveyID=new Integer(resultSet.getInt(3));
		surveyBean.setSurveyId(surveyID.toString());
		return surveyBean;
	}

}
