package com.igate.surveymanagement.bean;

import java.util.Date;

import javax.validation.constraints.Pattern;

import org.springframework.stereotype.Component;


@Component
public class SurveyBean {
	private String surveyId;
	@Pattern(regexp="^[a-zA-z#0-9][a-zA-Z!@#$%^&*(). ]{10,100}$", message="Enter the valid survey title")
	private String surveyTitle;
	@Pattern(regexp="^[a-zA-z#0-9][a-zA-Z!@#$%^&*(). ]{10,250}$",message="Enter the valid survey description")
	private String surveyDescription;
	private String distributionId;
	private Date distributionDate;
	private String expiryDate;
	public String getSurveyId() {
		return surveyId;
	}
	public void setSurveyId(String surveyId) {
		this.surveyId = surveyId;
	}
	public String getSurveyTitle() {
		return surveyTitle;
	}
	public void setSurveyTitle(String surveyTitle) {
		this.surveyTitle = surveyTitle;
	}
	public String getSurveyDescription() {
		return surveyDescription;
	}
	public void setSurveyDescription(String surveyDescription) {
		this.surveyDescription = surveyDescription;
	}
	public String getDistributionId() {
		return distributionId;
	}
	public void setDistributionId(String distributionId) {
		this.distributionId = distributionId;
	}
	
	public Date getDistributionDate() {
		return distributionDate;
	}
	public void setDistributionDate(Date distributionDate) {
		this.distributionDate = distributionDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public SurveyBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
