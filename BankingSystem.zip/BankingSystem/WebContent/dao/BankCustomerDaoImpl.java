package com.cg.bs.dao;

import java.sql.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bs.bean.Attempts;
import com.cg.bs.bean.Customer;
import com.cg.bs.bean.FundTransfer;
import com.cg.bs.bean.Payees;
import com.cg.bs.bean.ServiceTracker;
import com.cg.bs.bean.Transactions;
import com.cg.bs.exception.BankException;


@Repository
@Transactional
public class BankCustomerDaoImpl implements IBankCustomerDao {
	
	@PersistenceContext
	EntityManager entityManager;
	////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public List<Transactions> viewMiniStateMent(long accountNum)
			throws BankException {
		TypedQuery<Transactions> query = entityManager.createQuery("from Transactions", Transactions.class);

		return query.getResultList();
	}

	@Override
	public List<Transactions> viewDetailedStatement(long accountNum,
			Date startDate, Date endDate) throws BankException {
		TypedQuery<Transactions> view = entityManager.createQuery("from Transactions",Transactions.class);
		return view.getResultList();
	}

	@Override
	public Customer getCustomerDetails(long accountNumber) throws BankException {
		TypedQuery<Customer> getDetails = entityManager.createQuery("from Customer",Customer.class);
		return null;
	}

	@Override
	public int updateMobileNumber(Customer customer)
			throws BankException {
		int status=0;
		Customer newBean = entityManager.merge(customer);
		if(newBean!=null)
		{
			status=1;

		}
		return status;
	}

	@Override
	public int updateAddress(Customer customer)
			throws BankException {
		int result=0;
		Customer bean = entityManager.merge(customer);
		if(bean != null)
		{
			result = 1;
		}
		
		return result;
	}
//////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean requestCheckBook(ServiceTracker serviseTracker)
			throws BankException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean checkRequestAvailable(long accountId) throws BankException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ServiceTracker trackServiceRequest(long accountNumber)
			throws BankException {
		// TODO Auto-generated method stub
		return null;
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public List<Long> getAccountNumbers(long accountNumber)
			throws BankException {
		TypedQuery<Transactions> accountNumbers = entityManager.createQuery("from Transactions",Transactions.class);
		return null;
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public List<Payees> getAllPayees(long bankAccountNumber)
			throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FundTransfer fundTransfer(long bankAccountNumber,
			long payeeAccountNumber, long transferAmount) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long isAmountTransferable(long bankAccountNumber,
			long transferAmmount) throws BankException {
		// TODO Auto-generated method stub
		return 0;
	}

	
	}
