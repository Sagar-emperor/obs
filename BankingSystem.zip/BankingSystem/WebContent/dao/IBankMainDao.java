package com.cg.bs.dao;

import com.cg.bs.exception.BankException;

public interface IBankMainDao {

	boolean isValidUser(long accountNumber, String password, String beanName) throws BankException;

	int getUserAttempts(long accountNumber, String beanName) throws BankException;

	boolean lockAccount(long accountNumber, String beanName) throws BankException;
	
	boolean setUserAttempts(long accountNumber, String beanName) throws BankException;
	
	String getUserQuestion(long accountNumber, String beanName) throws BankException ;
	
	boolean isValidTransactionPassword(String transactionpassword,long accountNumber, String beanName) throws BankException;
	
	boolean unLockAccount(long accountNumber, String beanName) throws BankException;
	
	boolean updatePassword(long accountNumber,String newPassword, String beanName) throws BankException;
	
	boolean isLockedAccount(long accountNumber, String beanName) throws BankException;

	boolean setUserAttemptsZero(long accountNumber, String beanName)throws BankException;
	
}
