package com.cg.bs.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bs.bean.Admin;
import com.cg.bs.bean.Attempts;
import com.cg.bs.bean.User;
import com.cg.bs.exception.BankException;

@Repository
@Transactional
public class BankMainDaoImpl implements IBankMainDao {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public boolean isValidUser(long accountNumber, String password,
			String beanName) throws BankException {
		
		boolean isValidUser = false;
		
		if(beanName == "User"){
			
			User user = null;
			
			user = entityManager.find(User.class, accountNumber);
			
			if(user != null){
				
				isValidUser = true;

			}
			
			
		} else if(beanName == "Admin"){
			
			Admin admin = null;
			
			admin = entityManager.find(Admin.class, accountNumber);
			
			if(admin != null){
				
				isValidUser = true;

			}
			
			
		}
		

		
		return isValidUser;
	}

	@Override
	public int getUserAttempts(long accountNumber, String beanName)
			throws BankException {
		
		int attempts = 0;
		
		Attempts attemptsBean = entityManager.find(Attempts.class, accountNumber);
		attempts = attemptsBean.getAttempts();
		
		return attempts;
	}

	@Override
	public boolean lockAccount(long accountNumber, String beanName)
			throws BankException {
		
		boolean isLocked = false;
		
		
		
		if(beanName == "User"){
			
			User user = null;
			
			user = entityManager.find(User.class, accountNumber);
			if(user != null){
				
				user.setLockStatus("L");
				entityManager.merge(user);
				isLocked = true;
			}

			
			
		} else if(beanName == "Admin"){
			
			Admin admin = null;
			
			admin = entityManager.find(Admin.class, accountNumber);
			
			if(admin != null){
				
				admin.setLockStatus("L");
				entityManager.merge(admin);
				isLocked = true;
			}

			
			
		}

		
		return isLocked;
	}

	@Override
	public boolean setUserAttempts(long accountNumber, String beanName)
			throws BankException {
		
		boolean isAttemptsSet = false;
		int attempts = 0;
		
		Attempts attemptBean = entityManager.find(Attempts.class, accountNumber);
		
		if(attemptBean != null){
			
			attempts = attemptBean.getAttempts();
			attemptBean.setAttempts(attempts+1);
			entityManager.merge(attemptBean);
			
		}
		
		
		return isAttemptsSet;
	}

	@Override
	public String getUserQuestion(long accountNumber, String beanName)
			throws BankException {
		
		String question = null;
		
		if(beanName == "User"){
			
			User user = null;
			
			user = entityManager.find(User.class, accountNumber);
			
			if(user != null){
				
				question = user.getSecretQuestion();

			}
			
			
		} else if(beanName == "Admin"){
			
			Admin admin = null;
			
			admin = entityManager.find(Admin.class, accountNumber);
			
			if(admin != null){
				
				question = admin.getSecretQuestion();

			}
			
			
		}
		
		
		return question;
	}

	@Override
	public boolean isValidTransactionPassword(String transactionpassword,
			long accountNumber, String beanName) throws BankException {
		
		boolean isvalidTransactionPassword = false;
		
		if(beanName == "User"){
			
			User user = null;
			
			user = entityManager.find(User.class, accountNumber);
			
			if(user != null){
				
				if(user.getTransactionPassword() == transactionpassword){
					
					isvalidTransactionPassword = true;
					
				}

			}
			
			
		} else if(beanName == "Admin"){
			
			Admin admin = null;
			
			admin = entityManager.find(Admin.class, accountNumber);
			
			if(admin != null){
				
				if(admin.getTransactionPassword() == transactionpassword){
					
					isvalidTransactionPassword = true;
					
				}

			}
			
			
		}
		
		return isvalidTransactionPassword;
	}

	@Override
	public boolean unLockAccount(long accountNumber, String beanName)
			throws BankException {

		boolean isUnlocked = false;
		
		if(beanName == "User"){
			
			User user = null;
			
			user = entityManager.find(User.class, accountNumber);
			if(user != null){
				
				user.setLockStatus("A");
				entityManager.merge(user);
				isUnlocked = true;
			}

			
			
		} else if(beanName == "Admin"){
			
			Admin admin = null;
			
			admin = entityManager.find(Admin.class, accountNumber);
			
			if(admin != null){
				
				admin.setLockStatus("A");
				entityManager.merge(admin);
				isUnlocked = true;
			}

			
			
		}


		return isUnlocked;
	}

	@Override
	public boolean updatePassword(long accountNumber, String newPassword,
			String beanName) throws BankException {

		boolean isUpdated = false;

		if(beanName == "User"){
			
			User user = null;
			
			user = entityManager.find(User.class, accountNumber);
			if(user != null){
				
				user.setLoginPass(newPassword);
				entityManager.merge(user);
				isUpdated = true;
			}

			
			
		} else if(beanName == "Admin"){
			
			Admin admin = null;
			
			admin = entityManager.find(Admin.class, accountNumber);
			
			if(admin != null){
				
				admin.setLoginPass(newPassword);
				entityManager.merge(admin);
				isUpdated = true;
			}
			
		}
		
		return isUpdated;
	}

	@Override
	public boolean isLockedAccount(long accountNumber, String beanName)
			throws BankException {

		boolean isLocked = false;
		String lockStatus = null;
		
		
		if(beanName == "User"){
			
			User user = null;
			
			user = entityManager.find(User.class, accountNumber);
			if(user != null){
				
				lockStatus = user.getLockStatus();
				
				if(lockStatus == "L"){
					
					isLocked = true;
					
				}			
	
			}

			
			
		} else if(beanName == "Admin"){
			
			Admin admin = null;
			
			admin = entityManager.find(Admin.class, accountNumber);
			
			if(admin != null){
				
				lockStatus = admin.getLockStatus();
				
				if(lockStatus == "L"){
					
					isLocked = true;
					
				}

			}
	
		}
		
		return isLocked;
	}

	@Override
	public boolean setUserAttemptsZero(long accountNumber, String beanName)
			throws BankException {
		
		boolean isSetAttemptsZero = false;
		
		Attempts attempts = entityManager.find(Attempts.class, accountNumber);
		
		if(attempts != null){
			
			attempts.setAttempts(0);
			entityManager.merge(attempts);
		}
		
		return isSetAttemptsZero;
	}
	
}
