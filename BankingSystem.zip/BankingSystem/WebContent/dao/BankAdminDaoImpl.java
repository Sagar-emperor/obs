package com.cg.bs.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bs.bean.AccountMaster;
import com.cg.bs.bean.Customer;
import com.cg.bs.bean.Transactions;
import com.cg.bs.bean.User;
import com.cg.bs.exception.BankException;

@Repository
@Transactional
public class BankAdminDaoImpl implements IBankAdminDao {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public long createAccount(AccountMaster accountMaster, User user,
			Customer customer) throws BankException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Transactions> getTransactions(String transactionType,
			long accountNumber, int number) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
}
