package com.cg.bs.dao;

import java.util.List;

import com.cg.bs.bean.AccountMaster;
import com.cg.bs.bean.Customer;
import com.cg.bs.bean.Transactions;
import com.cg.bs.bean.User;
import com.cg.bs.exception.BankException;



public interface IBankAdminDao {

	
	long createAccount(AccountMaster accountMaster,User user,Customer customer) throws BankException;

	List<Transactions> getTransactions(String transactionType,long accountNumber, int number)throws BankException ;
}
