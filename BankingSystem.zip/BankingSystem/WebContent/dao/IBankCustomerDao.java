package com.cg.bs.dao;

import java.sql.Date;
import java.util.List;

import com.cg.bs.bean.Customer;
import com.cg.bs.bean.FundTransfer;
import com.cg.bs.bean.Payees;
import com.cg.bs.bean.ServiceTracker;
import com.cg.bs.bean.Transactions;
import com.cg.bs.exception.BankException;


public interface IBankCustomerDao {

	List<Transactions> viewMiniStateMent(long accountNum) throws BankException;

	List<Transactions> viewDetailedStatement(long accountNum, Date startDate,Date endDate) throws BankException;
	
	Customer getCustomerDetails(long accountNumber) throws BankException;
	
	int updateMobileNumber(Customer customer) throws BankException;
	
	int updateAddress(Customer customer) throws BankException;

	boolean requestCheckBook(ServiceTracker serviseTracker) throws BankException;

	boolean checkRequestAvailable(long accountId) throws BankException;

	ServiceTracker trackServiceRequest(long accountNumber) throws BankException ;

	List<Long> getAccountNumbers(long accountNumber)throws BankException ;

	List<Payees> getAllPayees(long bankAccountNumber)throws BankException ;

	FundTransfer fundTransfer(long bankAccountNumber, long payeeAccountNumber,long transferAmount)throws BankException ;
	
	long isAmountTransferable(long bankAccountNumber,long transferAmmount) throws BankException;

	
}

