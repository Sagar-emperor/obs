package com.cg.bs.test;


import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.cg.bs.bean.AccountMaster;
import com.cg.bs.bean.Customer;
import com.cg.bs.bean.ServiceTracker;
import com.cg.bs.bean.Transactions;
import com.cg.bs.bean.User;
import com.cg.bs.dao.BankAdminDaoImpl;
import com.cg.bs.dao.BankMainDaoImpl;
import com.cg.bs.dao.IBankAdminDao;
import com.cg.bs.dao.IBankMainDao;
import com.cg.bs.exception.BankException;



public class BankDaoLoginTest {

	@Autowired
	
	static IBankAdminDao iBankDao;
	@Autowired
	static IBankMainDao dao;
	static  AccountMaster accountMaster;
	@Autowired
	static User user;
	static Customer customer;
	static ServiceTracker serviceTracker;
	static Transactions transactions;

	
	
	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new BankMainDaoImpl();
		accountMaster = new AccountMaster();
		customer = new Customer();
		serviceTracker = new ServiceTracker();
		transactions = new Transactions();
		user = new User();
		iBankDao = new BankAdminDaoImpl();
		
	}

	//@Ignore
	@Test
	public void isValidUserTest()
	{
		
		try {
			assertTrue(dao.isValidUserAccountId(1234567899,"Admin"));
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
}

