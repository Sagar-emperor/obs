package com.cg.bs.exception;

public class BankException extends Exception {

	private static final long serialVersionUID = 2698024990190061636L;

	public BankException() {

		super();
		
	}
	
	public BankException(String message){
	
		super(message);
	
	}
	
}
