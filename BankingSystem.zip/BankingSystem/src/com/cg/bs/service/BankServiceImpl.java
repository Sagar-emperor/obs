package com.cg.bs.service;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bs.bean.AccountMaster;
import com.cg.bs.bean.Admin;
import com.cg.bs.bean.Customer;
import com.cg.bs.bean.FundTransfer;
import com.cg.bs.bean.Payees;
import com.cg.bs.bean.ServiceTracker;
import com.cg.bs.bean.Transactions;
import com.cg.bs.bean.User;
import com.cg.bs.dao.IBankAdminDao;
import com.cg.bs.dao.IBankCustomerDao;
import com.cg.bs.dao.IBankMainDao;
import com.cg.bs.exception.BankException;

@Service
public class BankServiceImpl implements IBankService {

	@Autowired
	private IBankAdminDao bankAdminDao;
	
	@Autowired
	private IBankCustomerDao bankCustomerDao;
	
	@Autowired
	private IBankMainDao bankMainDao;
	
	@Override
	public boolean isValidUserAccountId(long accountNumber,String beanName) throws BankException {

		return bankMainDao.isValidUserAccountId(accountNumber, beanName);

	}
	
	@Override
	public boolean isValidUserPassword(long accountNumber, String password,
			String beanName) throws BankException {

		return bankMainDao.isValidUserPassword(accountNumber, password, beanName);

	}

	@Override
	public int getUserAttempts(long accountNumber, String beanName)
			throws BankException {
		
		return bankMainDao.getUserAttempts(accountNumber, beanName);
		
	}

	@Override
	public boolean lockAccount(long accountNumber, String beanName)
			throws BankException {

		return bankMainDao.lockAccount(accountNumber, beanName);
		
	}

	@Override
	public boolean setUserAttempts(long accountNumber, String beanName)
			throws BankException {

		
		return bankMainDao.setUserAttempts(accountNumber, beanName);
		
	}

	@Override
	public String getUserQuestion(long accountNumber, String beanName)
			throws BankException {

		return bankMainDao.getUserQuestion(accountNumber, beanName);
		
		
	}

	@Override
	public boolean isValidTransactionPassword(String transactionpassword,
			long accountNumber, String beanName) throws BankException {

		return bankMainDao.isValidTransactionPassword(transactionpassword, accountNumber, beanName);
		
	}

	@Override
	public boolean unLockAccount(long accountNumber, String beanName)
			throws BankException {
		
		return bankMainDao.unLockAccount(accountNumber, beanName);
		
	}

	@Override
	public boolean updatePassword(long accountNumber, String newPassword,
			String beanName) throws BankException {
		
		return bankMainDao.updatePassword(accountNumber, newPassword, beanName);
		
	}

	@Override
	public boolean isLockedAccount(long accountNumber, String beanName)
			throws BankException {
		
		return bankMainDao.isLockedAccount(accountNumber, beanName);
		
	}

	@Override
	public boolean setUserAttemptsZero(long accountNumber, String beanName)
			throws BankException {
		
		return bankMainDao.setUserAttemptsZero(accountNumber, beanName);
		
	}

	/* Admin Functions*/
	


	@Override
	public long createAccount(AccountMaster accountMaster, Customer customer,
			User user) throws BankException {
		
		return bankAdminDao.createAccount(accountMaster,customer,user);
		
	}

	@Override
	public List<Transactions> getTransactions(Date dateOfTransaction,String transactionType)throws BankException {
			
		return bankAdminDao.getTransactions(dateOfTransaction,transactionType);
		
	}
	
	
	
	
	/* Customer Functions */
	
	@Override
	public Customer getCustomerDetails(long accountNumber) throws BankException {

		return bankCustomerDao.getCustomerDetails(accountNumber);
		
	}
		
	@Override
	public Customer updateDetails(Customer customer) throws BankException {
	
		return bankCustomerDao.updateDetails(customer);
		
	}

	@Override
	public boolean requestForCheckBook(long accountId) throws BankException {

		return bankCustomerDao.requestForCheckBook(accountId);
		
	}

	@Override
	public ServiceTracker serviceTrack(long accountId) throws BankException {

		return bankCustomerDao.serviceTrack(accountId);
		
	}

	@Override
	public boolean validateOldPass(long accountId, String oldPass)
			throws BankException {

		return bankCustomerDao.validateOldPass(accountId,oldPass);
		
	}

	@Override
	public boolean changePassword(long accountId, String newPass,String table)
			throws BankException {

		return bankMainDao.changePassword(accountId,newPass,table);
		
	}

	@Override
	public List<Transactions> viewMiniStatement(long accountId)
			throws BankException {

		return bankCustomerDao.viewMiniStatement(accountId);
	}

	@Override
	public List<Transactions> viewDetailedStatement(long accountId,
			Date startDate, Date endDate) throws BankException {
		
		return bankCustomerDao.viewDetailedStatement(accountId,startDate,endDate);
	}

	@Override
	public List<Long> getAccountNumbers(long accountId) throws BankException {
		
		return bankCustomerDao.getAccountNumbers(accountId);
	}

	@Override
	public Map<Long, List<Payees>> getAllPayees(List<Long> accountNumbers)
			throws BankException {
		
		return bankCustomerDao.getAllPayees(accountNumbers);
	}

	@Override
	public List<Payees> getAccountPayees(Long selectAccount)
			throws BankException {
		
		return bankCustomerDao.getAccountPayees(selectAccount);
	}

	@Override
	public FundTransfer fundTransfer(FundTransfer fundTransfer)
			throws BankException {

		return bankCustomerDao.fundTransfer(fundTransfer);
	}

	@Override
	public User searchAccountUser(long accountId) throws BankException {
	
		return bankMainDao.searchAccountUser(accountId);
	}

	@Override
	public Admin searchAccountAdmin(long accountId) throws BankException {
		
		return bankMainDao.searchAccountAdmin(accountId);
	}

	@Override
	public boolean isCorrectSecurityAnswer(long accountId, String answer,
			String table) throws BankException {
		
		return bankMainDao.isCorrectSecurityAnswer(accountId,answer,table);
	}



	



}
