package com.cg.bs.service;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import com.cg.bs.bean.AccountMaster;
import com.cg.bs.bean.Admin;
import com.cg.bs.bean.Customer;
import com.cg.bs.bean.FundTransfer;
import com.cg.bs.bean.Payees;
import com.cg.bs.bean.ServiceTracker;
import com.cg.bs.bean.Transactions;
import com.cg.bs.bean.User;
import com.cg.bs.exception.BankException;

public interface IBankService {

	boolean isValidUserAccountId(long accountNumber, String beanName) throws BankException;
	
	boolean isValidUserPassword(long accountNumber, String password, String beanName) throws BankException;
	
	int getUserAttempts(long accountNumber, String beanName) throws BankException;
	
	boolean lockAccount(long accountNumber, String beanName) throws BankException;
	
	boolean setUserAttempts(long accountNumber, String beanName) throws BankException;
	
	String getUserQuestion(long accountNumber, String beanName) throws BankException ;
	
	boolean isValidTransactionPassword(String transactionpassword,long accountNumber, String beanName) throws BankException;
	
	boolean unLockAccount(long accountNumber, String beanName) throws BankException;
	
	boolean isLockedAccount(long accountNumber, String beanName) throws BankException;

	boolean setUserAttemptsZero(long accountNumber, String beanName)throws BankException;

	Customer getCustomerDetails(long accountNumber) throws BankException;
	
	boolean updatePassword(long accountNumber,String newPassword, String beanName) throws BankException;

	long createAccount(AccountMaster accountMaster, Customer customer, User user) throws BankException;

	List<Transactions> getTransactions(Date dateOfTransaction,String transactionType) throws BankException;

	Customer updateDetails(Customer customer) throws BankException;

	boolean requestForCheckBook(long accountId)throws BankException;

	ServiceTracker serviceTrack(long accountId)throws BankException;

	boolean validateOldPass(long accountId, String oldPass) throws BankException;

	boolean changePassword(long accountId, String newPass,String table) throws BankException;

	List<Transactions> viewMiniStatement(long accountId) throws BankException;

	List<Transactions> viewDetailedStatement(long accountId, Date startDate,
			Date endDate)throws BankException;

	List<Long> getAccountNumbers(long accountId)throws BankException;

	Map<Long, List<Payees>> getAllPayees(List<Long> accountNumbers)throws BankException;

	List<Payees> getAccountPayees(Long selectAccount) throws BankException;

	FundTransfer fundTransfer(FundTransfer fundTransfer)throws BankException;

	User searchAccountUser(long accountId)throws BankException;

	Admin searchAccountAdmin(long accountId) throws BankException;

	boolean isCorrectSecurityAnswer(long accountId, String answer, String table)throws BankException;
	

	
}
