package com.cg.bs.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Attempts")
public class Attempts {
	
	
	@Id
	@Column(name="Account_Id")
	private long acountId;
	@Column(name="Attempts")
	private int attempts;
	
	
	public long getAcountId() {
		return acountId;
	}
	public void setAcountId(long acountId) {
		this.acountId = acountId;
	}
	public int getAttempts() {
		return attempts;
	}
	public void setAttempts(int attempts) {
		this.attempts = attempts;
	}

}
