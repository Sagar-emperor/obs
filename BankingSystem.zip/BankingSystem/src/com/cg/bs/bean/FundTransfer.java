package com.cg.bs.bean;

import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Fund_Transfer")
public class FundTransfer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="FundTransfer_Id")
	private int fundTransferId ;
	@Column(name="Account_Id",length=10)
	private long accountId;
	@Column(name="Payee_Account_Id",length=10)
	private long payeeAccountId;
	@Column(name="Date_Of_Transfer")
	private Date transferDate;
	@Column(name="Transfer_Amount",length=15)
	private long tranferAmmount;
	
	public int getFundTransferId() {
		return fundTransferId;
	}
	public void setFundTransferId(int fundTransferId) {
		this.fundTransferId = fundTransferId;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public long getPayeeAccountId() {
		return payeeAccountId;
	}
	public void setPayeeAccountId(long payeeAccountId) {
		this.payeeAccountId = payeeAccountId;
	}
	public Date getTransferDate() {
		return transferDate;
	}
	public void setTransferDate(Date transferDate) {
		this.transferDate = transferDate;
	}
	public long getTranferAmmount() {
		return tranferAmmount;
	}
	public void setTranferAmmount(long tranferAmmount) {
		this.tranferAmmount = tranferAmmount;
	}
	
}
