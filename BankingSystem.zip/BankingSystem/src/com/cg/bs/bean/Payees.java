package com.cg.bs.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="PayeeTable")
public class Payees {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Payee_Id")
	private int payeeId;
	@Column(name="Account_Id")
	private long accountId;
	@Column(name="Payee_Account_Id")
	private long payeeAccountId;
	@Column(name="Nick_Name")
	private String nickName;
	
	
	
	public int getPayeeId() {
		return payeeId;
	}
	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public long getPayeeAccountId() {
		return payeeAccountId;
	}
	public void setPayeeAccountId(long payeeAccountId) {
		this.payeeAccountId = payeeAccountId;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	@Override
	public String toString() {
		return "Payees [payeeId=" + payeeId + ", accountId=" + accountId
				+ ", payeeAccountId=" + payeeAccountId + ", nickName="
				+ nickName + "]";
	}	
	
	
}
