package com.cg.bs.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="UserTable")

public class User {
	
		
		@Column(name="Account_Id")
		private Long accountId;
		
		@Id
		@SequenceGenerator(name = "user_id",sequenceName="User_id_seq",allocationSize=1)
		@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="user_id")
		@Column(name="User_Id")
		private long userId;

		@Column(name="Login_Password",length=15)
		private String loginPass;
		
		@Column(name="Secret_question",length=50)
		private String secretQuestion;
		
		@Column(name="Transaction_Password",length=15)
		private String transactionPassword;
		
		@Column(name="Lock_Status",length=1)
		private String lockStatus;
		
		

		public Long getAccountId() {
			return accountId;
		}
		public void setAccountId(Long accountId) {
			this.accountId = accountId;
		}
		public long getUserId() {
			return userId;
		}
		public void setUserId(long userId) {
			this.userId = userId;
		}
		public String getLoginPass() {
			return loginPass;
		}
		public void setLoginPass(String loginPass) {
			this.loginPass = loginPass;
		}
		public String getSecretQuestion() {
			return secretQuestion;
		}
		public void setSecretQuestion(String secretQuestion) {
			this.secretQuestion = secretQuestion;
		}
		public String getTransactionPassword() {
			return transactionPassword;
		}
		public void setTransactionPassword(String transactionPassword) {
			this.transactionPassword = transactionPassword;
		}
		public String getLockStatus() {
			return lockStatus;
		}
		public void setLockStatus(String lockStatus) {
			this.lockStatus = lockStatus;
		}
	
		
}
