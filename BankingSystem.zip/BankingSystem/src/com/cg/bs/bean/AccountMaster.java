/**
 * 
 */
package com.cg.bs.bean;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="AccountMaster")
public class AccountMaster {
	
	// Account details of the user
	@Id
	@Column(name="Account_ID")
	private long accountId;// user account id
	@Column(name="Account_Type",length=25)
	private String accountType;// account type example : saving or current
	@Column(name="Account_Balance",length=15)
	private long accountBalance;// current balance
	@Column(name="Open_Date")
	private Date openDate;// account opening date
	
	//default constructor
	public AccountMaster() {
		accountId = 0l;
		accountType ="UNKNOWN";
		accountBalance =0l;
		openDate = Date.valueOf(LocalDate.now());
	}


	/**
	 * @return the accountId
	 */
	public long getAccountId() {
		return accountId;
	}


	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}


	/**
	 * @return the accountType
	 */
	public String getAccountType() {
		return accountType;
	}


	/**
	 * @param accountType the accountType to set
	 */
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}


	/**
	 * @return the accountBalance
	 */
	public long getAccountBalance() {
		return accountBalance;
	}


	/**
	 * @param accountBalance the accountBalance to set
	 */
	public void setAccountBalance(long accountBalance) {
		this.accountBalance = accountBalance;
	}


	/**
	 * @return the openDate
	 */
	public Date getOpenDate() {
		return openDate;
	}


	/**
	 * @param openDate the openDate to set
	 */
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}	
}
