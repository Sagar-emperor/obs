package com.cg.bs.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Transactions")
public class Transactions {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Transaction_Id")
	private long transactionId;
	@Column(name="Tran_Description",length=100)
	private String tranDescription;
	@Column(name="DateOfTransaction")
	private Date dateOfTransaction;
	@Column(name="TransactionType",length=1)
	private String transactionType;
	@Column(name="TranAmount",length=15)
	private long tranAmount;
	@Column(name="Account_Id")
	private long accountId;
	
	
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public String getTranDescription() {
		return tranDescription;
	}
	public void setTranDescription(String tranDescription) {
		this.tranDescription = tranDescription;
	}
	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public long getTranAmount() {
		return tranAmount;
	}
	public void setTranAmount(long tranAmount) {
		this.tranAmount = tranAmount;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	@Override
	public String toString() {
		return "Transactions [transactionId=" + transactionId
				+ ", tranDescription=" + tranDescription
				+ ", dateOfTransaction=" + dateOfTransaction
				+ ", transactionType=" + transactionType + ", tranAmount="
				+ tranAmount + ", accountId=" + accountId + "]";
	}
	
	
	

}
