package com.cg.bs.controller;
import java.sql.Date;
import java.util.Map;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cg.bs.bean.AccountMaster;
import com.cg.bs.bean.Admin;
import com.cg.bs.bean.Customer;
import com.cg.bs.bean.FundTransfer;
import com.cg.bs.bean.Payees;
import com.cg.bs.bean.ServiceTracker;
import com.cg.bs.bean.Transactions;
import com.cg.bs.bean.User;
import com.cg.bs.exception.BankException;
import com.cg.bs.service.IBankService;

@Controller
@SessionAttributes({"customer","user","admin","userType"})
public class BankController {

	private final String HOME_PAGE="index";
	private final String USER_PANEL="userPanel";
	private final String ADMIN_PANEL="adminPanel";
	private final String RESET_PASSWORD="resetPasswordForm";
	private final String ERROR_PAGE="error";
	
	@Autowired
	private IBankService bankService;
	
	private long accountNumber;
	private String password;
	private String beanName;
	
	private static final int ATTEMPT_LIMIT = 3;
	
	
	@RequestMapping("/showLogin")
	public String showHomePage(Model model){

		User user = new User();
		Admin admin = new Admin();
		model.addAttribute("user", user);
		model.addAttribute("admin", admin);
		model.addAttribute("loginForm", true);
		return HOME_PAGE;
		
	}

	
	@RequestMapping(value="/loginUser",method=RequestMethod.POST)
	public String loginCustomer(@ModelAttribute("user") User user,BindingResult result,Model model){
		
		if(result.hasErrors()){
			
			return ERROR_PAGE;
		}
		
		accountNumber = user.getAccountId();
		password = user.getLoginPass();
		beanName = "User";
		
		try {
			System.out.println("Acc no : "+accountNumber+"\nPass : "+password);
			if(! bankService.isValidUserAccountId(accountNumber, beanName)){
				
				model.addAttribute("userError", "Account Number Does not Exist");
				return HOME_PAGE;
				
			}
			
			

			if(! bankService.isValidUserPassword(accountNumber,password, beanName)){
				
				int attempts = bankService.getUserAttempts(accountNumber, beanName);
				
				
				if(attempts >= ATTEMPT_LIMIT){
					
					if(bankService.lockAccount(attempts, beanName)){
		
						return RESET_PASSWORD;
						
					} else {
						
						model.addAttribute("error", "Could not Lock Account");
						return ERROR_PAGE;
						
					}				
					
				}
				
				
				if(bankService.setUserAttempts(accountNumber, beanName)){
				
					model.addAttribute("userError", "Password is Incorrect");
					return HOME_PAGE;
					
				}
			
			}
			
			
			
			
			if(bankService.isLockedAccount(accountNumber, beanName)){
				
				return RESET_PASSWORD;
						
			}
			
			
			if(bankService.setUserAttemptsZero(accountNumber, beanName)){
				
				if(bankService.isLockedAccount(accountNumber, beanName)){
					
					model.addAttribute("firstResetPassword", true);
					return RESET_PASSWORD;
					
				} 
				
				
				Customer customer = bankService.getCustomerDetails(accountNumber);
				
				model.addAttribute("customer", customer);
				model.addAttribute("user", user);
				model.addAttribute("admin", "");
				model.addAttribute("userType", "user");
				return USER_PANEL;
				
				
			} else {
				
				model.addAttribute("error", "Could not Reset Attempts To Zero");
				return ERROR_PAGE;
				
			}
				
			
		} catch (BankException e) {
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}
		
	}

	
	@RequestMapping(value="/loginAdmin",method=RequestMethod.POST)
	public String loginAdmin(@ModelAttribute("admin") Admin admin,BindingResult result, Model model){
		
		if(result.hasErrors()){
			
			return ERROR_PAGE;
		}
		
		accountNumber = admin.getAccountId();
		password = admin.getLoginPass();
		beanName = "Admin";
		
		try {
			

			if(! bankService.isValidUserAccountId(accountNumber, beanName)){
				
				model.addAttribute("userError", "Account Number Does not Exist");
				return HOME_PAGE;
				
			}
			
			

			if(! bankService.isValidUserPassword(accountNumber,password, beanName)){
				
				int attempts = bankService.getUserAttempts(accountNumber, beanName);
				
				
				
				if(attempts >= ATTEMPT_LIMIT){
					
					if(bankService.lockAccount(attempts, beanName)){
						
						return RESET_PASSWORD;
						
					} else {
						
						model.addAttribute("error", "Could not Lock Account");
						return ERROR_PAGE;
						
					}				
					
				}
				
				
				if(bankService.setUserAttempts(accountNumber, beanName)){
					
					model.addAttribute("userError", "Password is Incorrect");
					return HOME_PAGE;
					
				}
			
			}
			
			//-----------------------------------------
			 // account id and password is correct
			
			if(bankService.isLockedAccount(accountNumber, beanName)){
				
				return RESET_PASSWORD;
						
			}
			
			if(bankService.setUserAttemptsZero(accountNumber, beanName)){
				
				if(bankService.isLockedAccount(accountNumber, beanName)){
					
					model.addAttribute("firstResetPassword", true);
					return RESET_PASSWORD;
					
				} 

				model.addAttribute("admin", admin);
				model.addAttribute("user", "");
				model.addAttribute("userType", "admin");
				model.addAttribute("openAccountForm", false);
				model.addAttribute("message","");
				return ADMIN_PANEL;
				
			} else {
				
				model.addAttribute("error", "Could not Reset Attempts To Zero");
				return ERROR_PAGE;
				
			}
			
			
			
		} catch (BankException e) {
		
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
		}
		
		
	}

	
	@RequestMapping("/openAccountForm")
	public String openAccountForm(Model model){
		
		Customer customer = new Customer();
		
		model.addAttribute("customer", customer);
		model.addAttribute("openAccountForm", true);
		model.addAttribute("message","");
		return ADMIN_PANEL;
	}

	
	@RequestMapping("/openAccount")
	public String openAccount(
							@ModelAttribute("customer") Customer customer,
							@RequestParam("accountType") String accountType,
							@RequestParam("openingBal") long openingBal,
							@RequestParam("loginPass") String loginPass,
							@RequestParam("secretQuestion") String secretQuestion,
							@RequestParam("transactionPassword") String transactionPassword,
							BindingResult resultCustomer,
							Model model){
		
		if(resultCustomer.hasErrors()){
			
			return ERROR_PAGE;
			
		}
		
		try {
			AccountMaster accountMaster = new AccountMaster();
			User user = new User();
			
			accountMaster.setAccountType(accountType);
			accountMaster.setAccountBalance(openingBal);
			
			user.setLoginPass(loginPass);
			user.setSecretQuestion(secretQuestion);
			user.setTransactionPassword(transactionPassword);
			
			long accountNumber = bankService.createAccount(accountMaster,customer,user);
			
			if(accountNumber != 0l){
				
				model.addAttribute("message","Account Created");
				model.addAttribute("openAccountForm", false);
				return ADMIN_PANEL;
				
			} else {
				
				model.addAttribute("error", "Error In Opening Account");
				return ERROR_PAGE;
				
			}
			
		}catch (BankException e){
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
		
		}
		
	}
	
	
	@RequestMapping("/viewTransactionForm")
	public String viewTransactionDaily(Model model){
		
		model.addAttribute("transactionForm", true);
		return ADMIN_PANEL;
		
	}


	@RequestMapping("/viewTransaction")
	public String viewTransaction(@RequestParam("dateOfTransaction") Date dateOfTransaction,
									@RequestParam("transaction") String transactionType,
									Model model){
		
		List<Transactions> transactionList = null;
		
		try {
			
			transactionList = bankService.getTransactions(dateOfTransaction,transactionType);
			model.addAttribute("listTransaction", transactionList);
			return ADMIN_PANEL;
			
		} catch(BankException e) {
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}
		
		
	}


	@RequestMapping("/changeDetailForm")
	public String changeDetailForm(Model model,HttpSession session) {
		
		try {
			
			long accNum = ((Customer)session.getAttribute("customer")).getAccountId();
			
			Customer customer = bankService.getCustomerDetails(accNum);
			model.addAttribute("customerDetails", customer);
			return USER_PANEL;
			
		} catch (BankException e){
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}
		
	}

	
	@RequestMapping(value="/changeDetails",method=RequestMethod.POST)
	public String changeDetails(@ModelAttribute Customer customer, Model model){
		try {
		
			Customer newCustomerDetails = bankService.updateDetails(customer);
			model.addAttribute("customerNew", newCustomerDetails);
			return USER_PANEL;
				
		} catch(BankException e){
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}
	}


	@RequestMapping("/requestForCheckBook")
	public String requestForCheckBook(Model model,HttpSession session){
		
		boolean requested = false;
		
		try {
			long accountId = ((Customer)session.getAttribute("customer")).getAccountId();
			
			requested = bankService.requestForCheckBook(accountId);
			
			if(requested){
				
				model.addAttribute("requested", "Your Request For Checkbook is Submitted");
				
			} else {
				
				model.addAttribute("message", "Request for Checkbook has Already Submitted");
				
			}
			
		} catch(BankException e){
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}
		
		return USER_PANEL;
	}

	
	@RequestMapping("/serviceTrack")
	public String serviceTrack(Model model,HttpSession session){
		
		try {
			
			long accountId = ((Customer)session.getAttribute("customer")).getAccountId();
			
			ServiceTracker serviceTracker = bankService.serviceTrack(accountId);
			
			if(serviceTracker != null){
				
				model.addAttribute("serviceDisplay", serviceTracker);
				
			} else {

				model.addAttribute("message", "You have not Submitted Any Request");				
				
			}
			
		} catch(BankException e) {
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}
		
		return USER_PANEL;
		
	}
	
	
	@RequestMapping("/changePasswordForm")
	public String changePasswordForm(Model model){
		
		model.addAttribute("changePasswordForm", true);
		return USER_PANEL;
	}


	@RequestMapping("/changePassword")
	public String changePassword(@RequestParam("oldPass") String oldPass,
								@RequestParam("newPass")String newPass,
								@RequestParam("retypePass")String retypePass,
								Model model, HttpSession session
								){
		
		long accountId = ((Customer)session.getAttribute("customer")).getAccountId();
		
		try {
			
		
			if(bankService.validateOldPass(accountId,oldPass)){
				
				if(newPass.equals(retypePass)){
					
					boolean isUpdated = bankService.changePassword(accountId,newPass,"user");
					
					if( isUpdated ){
						
						model.addAttribute("message", "Password Changed Successfully");
						
					} else {
						
						throw (new BankException("Could Not Change Password Plaese Try After Sometime"));
						
					}
					
				} else {
					
					model.addAttribute("message", "Password and Retype password Does not Match");
					
				}
				
				
			} else {
				
				model.addAttribute("message", "Old Password Does not Match");
				
			}
			

			
		} catch(BankException e){
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}
		
		return USER_PANEL;
	}


	@RequestMapping("/viewMiniStatement")
	public String viewMiniStatement(Model model,HttpSession session){
		
		long accountId = ((Customer)session.getAttribute("customer")).getAccountId();
		
		try {
			
		
			List<Transactions> listTransactions = bankService.viewMiniStatement(accountId);
			
			if(listTransactions.isEmpty()){
				
				model.addAttribute("message", "No Mini Transaction to display");
				
			} else {
				
				model.addAttribute("miniTransaction", true);
				model.addAttribute("listTransaction", listTransactions);
				
			}
			
		} catch (BankException e){
			e.printStackTrace();
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}	
		
		return USER_PANEL;
	}
	
	
	@RequestMapping("/viewDetailedStatementForm")
	public String viewDetailedStatementForm(Model model){
		
		model.addAttribute("viewDetailedTransactionForm", true);
		return USER_PANEL;
		
	}


	@RequestMapping("/viewDetailedStatement")
	public String viewDetailedStatement(@RequestParam("startDate") Date startDate, 
										@RequestParam("endDate") Date endDate,
										HttpSession session,
										Model model){
		
		long accountId = ((Customer)session.getAttribute("customer")).getAccountId();
		try {
			
			
			List<Transactions> listTransactions = bankService.viewDetailedStatement(accountId,startDate,endDate);
			
			if(listTransactions.isEmpty()){
				
				model.addAttribute("message", "No Detailed Transaction to display");
				
			} else {
				
				model.addAttribute("detailedTransaction", true);
				model.addAttribute("listTransaction", listTransactions);
				
			}
			
		} catch (BankException e){
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}	
		
		return USER_PANEL;
	}

	
	@RequestMapping("/fundTransferForm")
	public String fundTransferForm(HttpSession session,Model model){
		
		
		FundTransfer fundTransfer = new FundTransfer();
		long accountId = ((Customer)session.getAttribute("customer")).getAccountId();
		
		try {
	
			List<Long> accountNumbers = bankService.getAccountNumbers(accountId);
			Map<Long, List<Payees>> accountPayees = bankService.getAllPayees(accountNumbers);
			
			model.addAttribute("accountNumbers", accountNumbers);
			model.addAttribute("accountPayees", accountPayees);
			session.setAttribute("accountNumbers", accountNumbers);
			session.setAttribute("accountPayees", accountPayees);
			//session.setAttribute("A","fg");
			//session.invalidate();
			//System.out.println(""+session.getAttribute("A"));
			
		} catch (BankException e) {
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}
		model.addAttribute("fundTransferForm", fundTransfer);
		return USER_PANEL;
	}

	
	@RequestMapping("/setAccountNo")
	public String setAccountNo(@RequestParam("selectAccount") Long selectAccount, 
								HttpSession session,Model model){
		List<Payees> listPayees = null;
		
		FundTransfer fundTransfer = new FundTransfer();
		List<Long> accountNumbers = (List<Long>)session.getAttribute("accountNumbers");
		Map<Long, List<Payees>> accountPayees  = (Map<Long, List<Payees>>)session.getAttribute("accountPayees");
		try {
			
			listPayees = bankService.getAccountPayees(selectAccount);
			
			
		}catch (BankException e){
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}
		
		session.getAttribute("accountPayees");
		
		session.setAttribute("payeesList", listPayees);
		
		model.addAttribute("selectAccountNo",selectAccount);
		model.addAttribute("accountNumbers", accountNumbers);
		model.addAttribute("accountPayees", accountPayees);
		model.addAttribute("payeesList", listPayees);
		model.addAttribute("fundTransferForm", fundTransfer);
		
		return USER_PANEL;
	}

	
	@RequestMapping(value="/fundTransfer",method=RequestMethod.POST)
	public String fundTransfer(@ModelAttribute("fundTransferForm") FundTransfer fundTransfer, 
								Model model){
		try {
		
				FundTransfer fundTransfered = bankService.fundTransfer(fundTransfer);
				
				if(fundTransfer != null){
					
					
					model.addAttribute("fundTranferDetails", fundTransfered);
					
				} else {
					
					model.addAttribute("message", "Fund Transfer Can Not Be Done");
					
				}
				
				
		} catch (BankException e){
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}
		
		model.addAttribute("fundTransferForm", null);
		return USER_PANEL;
	}

	
	@RequestMapping("/logout")
	public String logout(HttpSession session, Model model){
		

		session.removeAttribute("customer");
		session.removeAttribute("user");
		session.removeAttribute("admin");
		session.removeAttribute("userType");
		session.invalidate();
		model.addAttribute("loginForm", true);
		return HOME_PAGE;
	}


	@RequestMapping("/forgetPassWordFormAdmin")
	public String forgetPassWordFormAdmin(Model model){
		
		model.addAttribute("adminS", true);
		model.addAttribute("forgetPassWordForm", true);
		return HOME_PAGE;
	}
	
	@RequestMapping("/forgetPassWordFormUser")
	public String forgetPassWordFormUser(Model model){
		
		model.addAttribute("userS", true);
		model.addAttribute("forgetPassWordForm", true);
		return HOME_PAGE;
	}
	
	
	
	
	@RequestMapping(value="/searchAccountUser",method=RequestMethod.POST)
	public String searchAccountUser(@RequestParam("accountId") long accountId,
									Model model){
		
		try {
			
			User user = bankService.searchAccountUser(accountId);
			
			if(user != null){
				
				if(user.getLockStatus().equals("L")){
					
					model.addAttribute("message", "Your Account Is Locked");
					
				}

				model.addAttribute("changePasswordForm", true);
				model.addAttribute("userValue", user);
				
			} else {
				
				model.addAttribute("forgetPassWordForm", true);
				model.addAttribute("message", "No Account Id Found");
				
			}
			
		} catch(BankException e){
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}
		return HOME_PAGE;
	}	
	
	@RequestMapping(value="/searchAccountAdmin",method=RequestMethod.POST)
	public String searchAccountAdmin(@RequestParam("accountId") long accountId,
									Model model){
		
		try {
			
			Admin admin = bankService.searchAccountAdmin(accountId);
			
			if(admin != null){
				
				if(admin.getLockStatus().equals("L")){
					
					model.addAttribute("message", "Your Account Is Locked");
					
				}

				model.addAttribute("changePasswordForm", true);
				model.addAttribute("adminValue", admin);
				
			} else {
				
				model.addAttribute("forgetPassWordForm", true);
				model.addAttribute("message", "No Account Id Found");
				
			}
			
			
		} catch(BankException e){
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}
		return HOME_PAGE;
	}

	@RequestMapping(value="/adminSubmitAnswerForm",method=RequestMethod.POST)
	public String adminSubmitAnswerForm(@RequestParam("answer")String answer,
										HttpSession session,
										Model model){
		
		try {
			long accountId = ((Customer)session.getAttribute("customer")).getAccountId();
			
			if( ! bankService.isCorrectSecurityAnswer(accountId,answer,"admin") ){
				
				model.addAttribute("message", "Wrong Answer");
				
			} else {
				
				bankService.changePassword(accountId,"sbq500#","admin");
				bankService.setUserAttemptsZero(accountId, "admin");
				
			}
		} catch (BankException e) {
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}
		return HOME_PAGE;
	}
	
	@RequestMapping(value="/userSubmitAnswerForm",method=RequestMethod.POST)
	public String userSubmitAnswerForm(@RequestParam("answer")String answer,
										HttpSession session,
										Model model){
		
		try {
			long accountId = ((Customer)session.getAttribute("customer")).getAccountId();
			
			if( ! bankService.isCorrectSecurityAnswer(accountId,answer,"user") ){
				
				model.addAttribute("message", "Wrong Answer");
				
			} else {
				
				bankService.changePassword(accountId,"sbq500#","user");
				bankService.setUserAttemptsZero(accountId, "user");
				
			}
		} catch (BankException e) {
			
			model.addAttribute("error", e.getMessage());
			return ERROR_PAGE;
			
		}
		return HOME_PAGE;
	}
}
