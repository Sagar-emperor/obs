package com.cg.bs.dao;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import com.cg.bs.bean.Customer;
import com.cg.bs.bean.FundTransfer;
import com.cg.bs.bean.Payees;
import com.cg.bs.bean.ServiceTracker;
import com.cg.bs.bean.Transactions;
import com.cg.bs.exception.BankException;


public interface IBankCustomerDao{

	Customer getCustomerDetails(long accountNumber) throws BankException;

	Customer updateDetails(Customer customer)throws BankException;

	boolean requestForCheckBook(long accountId)throws BankException;

	ServiceTracker serviceTrack(long accountId)throws BankException;

	boolean validateOldPass(long accountId, String oldPass)throws BankException;

	List<Transactions> viewMiniStatement(long accountId)throws BankException;

	List<Transactions> viewDetailedStatement(long accountId, Date startDate,
			Date endDate)throws BankException;

	List<Long> getAccountNumbers(long accountId)throws BankException;

	Map<Long, List<Payees>> getAllPayees(List<Long> accountNumbers)throws BankException;

	List<Payees> getAccountPayees(Long selectAccount)throws BankException;

	FundTransfer fundTransfer(FundTransfer fundTransfer)throws BankException;

	
	
}
