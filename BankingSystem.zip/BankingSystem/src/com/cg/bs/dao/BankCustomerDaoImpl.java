package com.cg.bs.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bs.bean.AccountMaster;
import com.cg.bs.bean.Customer;
import com.cg.bs.bean.FundTransfer;
import com.cg.bs.bean.Payees;
import com.cg.bs.bean.ServiceTracker;
import com.cg.bs.bean.Transactions;
import com.cg.bs.bean.User;
import com.cg.bs.exception.BankException;

@Repository
@Transactional
public class BankCustomerDaoImpl implements IBankCustomerDao {
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public Customer getCustomerDetails(long accountNumber) throws BankException {
		
		try {
		
			return entityManager.find(Customer.class, accountNumber);
		
		} catch (Exception e) {
			
			throw (new BankException("Something went wrong"));
			
		}
	}


	@Override
	public Customer updateDetails(Customer customer) throws BankException {

		try {
			
			Customer oldCustomerDetails = null;
			oldCustomerDetails = entityManager.find(Customer.class, customer.getAccountId());
			System.out.println(customer.getAddress());
			if(oldCustomerDetails != null){
				System.out.println(customer.getAddress());
				customer = entityManager.merge(customer);
				
			} else {
				
				throw (new BankException("Cannnot Update Details"));
				
			}
			
		} catch(Exception e) {
			
			throw (new BankException("Something went wrong"));
			
		}
		return customer;
	}


	@Override
	public boolean requestForCheckBook(long accountId) throws BankException {

		boolean isRequested = false;
		
		try {
			
			if(isAlreadyRequested(accountId)){
				
				return false;
				
			}
			
			ServiceTracker serviceTracker = new ServiceTracker();
			serviceTracker.setAccountId(accountId);
			serviceTracker.setServiceDescription("Checkbook Request");
			serviceTracker.setServiceRaisedDate(Date.valueOf(LocalDate.now()));
			serviceTracker.setServiceStatus("Requested");
			
			entityManager.persist(serviceTracker);
			entityManager.flush();
			
		} catch(Exception e){
			
			throw (new BankException("Something went wrong"));
			
		}
		
		
		return isRequested;
	}


	private boolean isAlreadyRequested(long accountId) {
		
		TypedQuery<ServiceTracker> query = entityManager.createQuery("select s from ServiceTracker s where s.accountId = :accId", ServiceTracker.class);
		query.setParameter("accId", accountId);
		
		List<ServiceTracker> listServices = query.getResultList();
		
		if(listServices.isEmpty()){
			
			return false;
			
		} else if(listServices.size() <=2){
			
			return true;
			
		} else {
			
			return false;
			
		}

	}


	@Override
	public ServiceTracker serviceTrack(long accountId) throws BankException {

		ServiceTracker serviceTracker = null;
		
		try {
			
			TypedQuery<ServiceTracker> query = entityManager.createQuery("select s from ServiceTracker s where s.accountId = :accId", ServiceTracker.class);
			query.setParameter("accId", accountId);
			
			List<ServiceTracker> listServices = query.getResultList();
			
			if(listServices.isEmpty()){
				
				return null;
				
			} else if(listServices.size() <=2) {
				
				serviceTracker = listServices.get(0);
				
			}
			
		} catch (Exception e) {
			
			throw (new BankException("Something went wrong"));
			
		}
		
		return serviceTracker;
	}


	@Override
	public boolean validateOldPass(long accountId, String oldPass)
			throws BankException {
		
		boolean isValidPass = false;
	
		try {
			
			User user = null;
			
			TypedQuery<User> query = entityManager.createQuery("select u from User u where accountId = :accId", User.class);
			query.setParameter("accId", accountId);
			
			user = query.getResultList().get(0);
			
			if(user != null){

				if(user.getLoginPass().equals(oldPass)){
					
					isValidPass = true;
					
				}
				
			}
			
		} catch(Exception e){
			
			throw (new BankException("Something went wrong"));
			
		}
		return isValidPass;
	}




	@Override
	public List<Transactions> viewMiniStatement(long accountId)
			throws BankException {
		
		final int MAX_RESULTS = 10;
		List<Transactions> listTransactions = null;
		System.out.println("1");
		try {
			System.out.println("2");	
			TypedQuery<Transactions> query = entityManager
											.createQuery("select t from Transactions t where t.accountId = :accId order by t.dateOfTransaction desc", Transactions.class)
											.setParameter("accId", accountId)
											.setMaxResults(MAX_RESULTS);
			System.out.println("3");
			listTransactions = query.getResultList();
			System.out.println("4");
			
		} catch(Exception e){
			
			throw (new BankException("Something went wrong"));
			
		}
		

		return listTransactions;
	}


	@Override
	public List<Transactions> viewDetailedStatement(long accountId,
			Date startDate, Date endDate) throws BankException {

		List<Transactions> listTransactions = new ArrayList<Transactions>();
		TypedQuery<Customer> query = null;
		
		try {
						
			query = entityManager.createQuery("select c from Customer c where c.pancard = (select c1.pancard from Customer c1 where c1.accountId = :accId)",Customer.class);
			query.setParameter("accId", accountId);
			
			List<Customer> customerList = query.getResultList();
			TypedQuery<Transactions> queryTransactions = null;
			
			for(Customer c : customerList){
				

				List<Transactions> accountTransactionList = new ArrayList<Transactions>();
				queryTransactions = entityManager.createQuery("select t from Transactions t where accountId = :accId and t.dateOfTransaction between :startDate AND :endDate order by t.dateOfTransaction desc", Transactions.class);
				queryTransactions.setParameter("accId", c.getAccountId());
				queryTransactions.setParameter("startDate", startDate);
				queryTransactions.setParameter("endDate", endDate);
				
				accountTransactionList = queryTransactions.getResultList();
				
				for(Transactions t : accountTransactionList){
					
					listTransactions.add(t);
					
				}
			}
			
			
		} catch (Exception e) {
			
			throw (new BankException("Something went wrong"));
			
		}
		
		return listTransactions;
	}


	@Override
	public List<Long> getAccountNumbers(long accountId) throws BankException {
		
		List<Long> accountNumbers = null;
		
		try {
			List<Customer> listCustomers = null;
			accountNumbers = new ArrayList<Long>();
			
			TypedQuery<Customer> query = entityManager.createQuery("select c from Customer c where c.pancard = (select c1.pancard from Customer c1 where c1.accountId = :accId)",Customer.class);
			query.setParameter("accId", accountId);
			listCustomers = query.getResultList();
			
			for(Customer c : listCustomers){
				
				accountNumbers.add(c.getAccountId());
				
			}
			
			
		} catch(Exception e) {
			
			throw (new BankException("Something went wrong"));
			
		}
		
		return accountNumbers;
	}


	@Override
	public Map<Long, List<Payees>> getAllPayees(List<Long> accountNumbers)
			throws BankException {
		
		Map<Long, List<Payees>> accountPayees = new HashMap<Long, List<Payees>>();
		
		for(Long accountNumber : accountNumbers){
			
			TypedQuery<Payees> query = entityManager.createQuery("select p from Payees p where p.accountId = :accId", Payees.class);
			query.setParameter("accId", accountNumber);
			List<Payees> listPayees = query.getResultList();
			accountPayees.put(accountNumber, listPayees);
		}
		
		return accountPayees;
	}


	@Override
	public List<Payees> getAccountPayees(Long selectAccount)
			throws BankException {
		
		List<Payees> lisPayees = null;
		
		try {
			
			TypedQuery<Payees> query = entityManager.createQuery("select p from Payees p where p.accountId = :accId",Payees.class);
			query.setParameter("accId",selectAccount);
			
			lisPayees = query.getResultList();
			
		} catch (Exception e) {
			
			throw (new BankException("Something went wrong"));
			
		}
		
		return lisPayees;
	}


	@Override
	public FundTransfer fundTransfer(FundTransfer fundTransfer)
			throws BankException {

		
		try {
			
			AccountMaster userAccount = entityManager.find(AccountMaster.class, fundTransfer.getAccountId());
			
			if(userAccount != null){
				
				userAccount.setAccountBalance(
							userAccount.getAccountBalance() - fundTransfer.getTranferAmmount()
							);
				entityManager.merge(userAccount);
				
			}
			
			
			AccountMaster payeeAccount = entityManager.find(AccountMaster.class, fundTransfer.getPayeeAccountId());
			
			if(payeeAccount != null){
				
				payeeAccount.setAccountBalance(
						payeeAccount.getAccountBalance() + fundTransfer.getTranferAmmount()
						);
				entityManager.merge(payeeAccount);
				
			}
			
			
			fundTransfer.setTransferDate(Date.valueOf(LocalDate.now()));
			entityManager.persist(fundTransfer);
			

			Transactions transactionDebit = new Transactions();
			transactionDebit.setAccountId(fundTransfer.getAccountId());
			transactionDebit.setTranAmount(fundTransfer.getTranferAmmount());
			transactionDebit.setTranDescription("Online Fund Transfer");
			transactionDebit.setTransactionType("D");
			transactionDebit.setDateOfTransaction(fundTransfer.getTransferDate());
			
			
			Transactions transactionCredit = new Transactions();
			transactionCredit.setAccountId(fundTransfer.getPayeeAccountId());
			transactionCredit.setTranAmount(fundTransfer.getTranferAmmount());
			transactionCredit.setTranDescription("Online Fund Transfer");
			transactionCredit.setTransactionType("C");
			transactionCredit.setDateOfTransaction(fundTransfer.getTransferDate());
			
			entityManager.persist(transactionDebit);
			entityManager.persist(transactionCredit);
			
			
		} catch(Exception e){
			
			throw (new BankException("Something went wrong"));
			
		}
		
		return fundTransfer;
	}

	
	
}
	

