package com.cg.bs.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bs.bean.Admin;
import com.cg.bs.bean.Attempts;
import com.cg.bs.bean.User;
import com.cg.bs.exception.BankException;

@Repository
@Transactional
public class BankMainDaoImpl implements IBankMainDao {

	@PersistenceContext
	EntityManager entityManager;

	
	@Override
	public boolean isValidUserAccountId(long accountNumber,String beanName) throws BankException{
		
		boolean isValidUser = false;
		
		try {
			
			if(beanName == "User"){
				
				User user = null;
				
				TypedQuery<User> query = entityManager.createQuery("from User where accountId=:accId", User.class);
				query.setParameter("accId", accountNumber);
				user = query.getSingleResult();
				
				if(user != null){
		
					isValidUser = true;
			
				}
				
				
			} else if(beanName == "Admin"){
				
				Admin admin = null;
				
				admin = entityManager.find(Admin.class, accountNumber);
		
				if(admin != null){
		
					isValidUser = true;
		
				}
				
				
			}
			
		} catch (Exception e){
			
			throw (new BankException("Something went Wrong"));
		}
		return isValidUser;
	}
	
	@Override
	public boolean isValidUserPassword(long accountNumber, String password,
			String beanName) throws BankException {
		
		boolean isValidUser = false;
		String oldPassword = null;
		
		try {
			
			if(beanName == "User"){
				
				User user = null;
				
				TypedQuery<User> query = entityManager.createQuery("from User where accountId=:accId", User.class);
				query.setParameter("accId", accountNumber);
				user = query.getSingleResult();
				
				if(user != null){
					
					oldPassword = user.getLoginPass();
					
					if(oldPassword.equals(password)){
						
						isValidUser = true;
						
					}
									
				}
				
				
			} else if(beanName == "Admin"){
				
				Admin admin = null;
				
				admin = entityManager.find(Admin.class, accountNumber);
				
				if(admin != null){
					
					oldPassword = admin.getLoginPass();
					if(oldPassword.equals(password)){
						
						isValidUser = true;
						
					}
	
				}
				
				
			}	
			
		} catch (Exception e){
			
			throw (new BankException("Something went Wrong"));
			
		}
		return isValidUser;
	}
	

	@Override
	public int getUserAttempts(long accountNumber, String beanName)
			throws BankException {
		
		int attempts = 0;
		try {
		
			Attempts attemptsBean = entityManager.find(Attempts.class, accountNumber);
			attempts = attemptsBean.getAttempts();
		
		} catch (Exception e){
			
			throw (new BankException("Something went Wrong"));
			
		}
		return attempts;
	}
	
	

	@Override
	public boolean lockAccount(long accountNumber, String beanName)
			throws BankException {
		
		boolean isLocked = false;
		
		try {
			
			if(beanName == "User"){
				
				User user = null;
				
				user = entityManager.find(User.class, accountNumber);
				if(user != null){
					
					user.setLockStatus("L");
					entityManager.merge(user);
					isLocked = true;
				}
	
				
				
			} else if(beanName == "Admin"){
				
				Admin admin = null;
				
				admin = entityManager.find(Admin.class, accountNumber);
				
				if(admin != null){
					
					admin.setLockStatus("L");
					entityManager.merge(admin);
					isLocked = true;
				}
	
				
				
			}
		
		} catch (Exception e){
			
			throw (new BankException("Something went Wrong"));
			
		}
		
		return isLocked;
	}

	
	
	@Override
	public boolean setUserAttempts(long accountNumber, String beanName)
			throws BankException {
		
		boolean isAttemptsSet = false;
		int attempts = 0;
		
		try {
		
			Attempts attemptBean = entityManager.find(Attempts.class, accountNumber);
			
			if(attemptBean != null){
				
				attempts = attemptBean.getAttempts();
				attemptBean.setAttempts(attempts+1);
				entityManager.merge(attemptBean);
				isAttemptsSet = true;
				
			}
			
		} catch (Exception e){
		
			throw (new BankException("Something went Wrong"));
			
		}
		
		return isAttemptsSet;
	}
	
	

	@Override
	public String getUserQuestion(long accountNumber, String beanName)
			throws BankException {
		
		String question = null;
		
		try {
			
			if(beanName == "User"){
				
				User user = null;
				
				user = entityManager.find(User.class, accountNumber);
				
				if(user != null){
					
					question = user.getSecretQuestion();
	
				}
				
				
			} else if(beanName == "Admin"){
				
				Admin admin = null;
				
				admin = entityManager.find(Admin.class, accountNumber);
				
				if(admin != null){
					
					question = admin.getSecretQuestion();
	
				}
				
				
			}
		
		} catch (Exception e){
			
			throw (new BankException("Something went Wrong"));
			
		}
		
		return question;
	}
	
	

	@Override
	public boolean isValidTransactionPassword(String transactionpassword,
			long accountNumber, String beanName) throws BankException {
		
		boolean isvalidTransactionPassword = false;
		
		try {
			if(beanName == "User"){
				
				User user = null;
				
				user = entityManager.find(User.class, accountNumber);
				
				if(user != null){
					
					if(user.getTransactionPassword() == transactionpassword){
						
						isvalidTransactionPassword = true;
						
					}
	
				}
				
				
			} else if(beanName == "Admin"){
				
				Admin admin = null;
				
				admin = entityManager.find(Admin.class, accountNumber);
				
				if(admin != null){
					
					if(admin.getTransactionPassword() == transactionpassword){
						
						isvalidTransactionPassword = true;
						
					}
	
				}
				
				
			}
		} catch (Exception e){
			
			throw (new BankException("Something went Wrong"));
			
		}
		return isvalidTransactionPassword;
	}
	
	

	@Override
	public boolean unLockAccount(long accountNumber, String beanName)
			throws BankException {

		boolean isUnlocked = false;
		
		try {
			if(beanName == "User"){
				
				User user = null;
				
				user = entityManager.find(User.class, accountNumber);
				if(user != null){
					
					user.setLockStatus("A");
					entityManager.merge(user);
					isUnlocked = true;
				}
	
				
				
			} else if(beanName == "Admin"){
				
				Admin admin = null;
				
				admin = entityManager.find(Admin.class, accountNumber);
				
				if(admin != null){
					
					admin.setLockStatus("A");
					entityManager.merge(admin);
					isUnlocked = true;
				}
	
			}

		} catch(Exception e) {
			
			throw (new BankException("Something went Wrong"));
			
		}

		return isUnlocked;
	}
	
	

	@Override
	public boolean updatePassword(long accountNumber, String newPassword,
			String beanName) throws BankException {

		boolean isUpdated = false;

		try {
			if(beanName == "User"){
				
				User user = null;
				
				user = entityManager.find(User.class, accountNumber);
				if(user != null){
					
					user.setLoginPass(newPassword);
					entityManager.merge(user);
					isUpdated = true;
				}
	
				
				
			} else if(beanName == "Admin"){
				
				Admin admin = null;
				
				admin = entityManager.find(Admin.class, accountNumber);
				
				if(admin != null){
					
					admin.setLoginPass(newPassword);
					entityManager.merge(admin);
					isUpdated = true;
				}
				
			}
		} catch (Exception e){
			
			throw (new BankException("Something went Wrong"));
			
		}
		return isUpdated;
	}

	
	
	@Override
	public boolean isLockedAccount(long accountNumber, String beanName)
			throws BankException {

		boolean isLocked = false;
		String lockStatus = null;
		
		try {
			if(beanName == "User"){
				
				User user = null;
				
				user = entityManager.find(User.class, accountNumber);
				if(user != null){
					
					lockStatus = user.getLockStatus();
					
					if(lockStatus == "L"){
						
						isLocked = true;
						
					}			
		
				}
	
				
				
			} else if(beanName == "Admin"){
				
				Admin admin = null;
				
				admin = entityManager.find(Admin.class, accountNumber);
				
				if(admin != null){
					
					lockStatus = admin.getLockStatus();
					
					if(lockStatus == "L"){
						
						isLocked = true;
						
					}
	
				}
		
			}
		} catch (Exception e){
			
			throw (new BankException("Something went Wrong"));
			
		}
		return isLocked;
	}
	
	

	@Override
	public boolean setUserAttemptsZero(long accountNumber, String beanName)
			throws BankException {
		
		boolean isSetAttemptsZero = false;
		
		try {
			Attempts attempts = entityManager.find(Attempts.class, accountNumber);
			
			if(attempts != null){
				
				attempts.setAttempts(0);
				entityManager.merge(attempts);
				isSetAttemptsZero = true;
			}
		} catch (Exception e){
			
			throw (new BankException("Something went Wrong"));
			
		}
		return isSetAttemptsZero;
	}

	@Override
	public User searchAccountUser(long accountId) throws BankException {
	
		User user = null;
		
		try {
			
			TypedQuery<User> query = entityManager.createQuery("select u from User u where u.accountId = :accId", User.class);
			query.setParameter("accId", accountId);
			List<User> userList = query.getResultList();
			user = userList.get(0);
			
		} catch(Exception e) {
			
			throw (new BankException("Something went Wrong"));
			
		}
		
		return user;
	}

	@Override
	public Admin searchAccountAdmin(long accountId) throws BankException {
		
		Admin admin = null;
		try {
			
			TypedQuery<Admin> query = entityManager.createQuery("select a from Admin a where a.accountId = :accId", Admin.class);
			query.setParameter("accId", accountId);
			List<Admin> adminList = query.getResultList();
			admin = adminList.get(0);
			
		} catch(Exception e) {
			
			throw (new BankException("Something went Wrong"));
			
		}
		
		return admin;
	}

	@Override
	public boolean isCorrectSecurityAnswer(long accountId, String answer,
			String table) throws BankException {
	
		boolean isCorrect = false;
		
		if(table.equals("admin")){
			
			TypedQuery<Admin> query = entityManager.createQuery("select a from Admin a where a.accountId = :accId", Admin.class); 
			query.setParameter("accId", accountId);
			Admin admin = query.getResultList().get(0);
			
			if(admin.getTransactionPassword().equals(answer)){
				
				isCorrect = true;
				
			}
			
		} else if(table.equals("user")){
			
			TypedQuery<User> query = entityManager.createQuery("select u from User u where u.accountId = :accId", User.class); 
			query.setParameter("accId", accountId);
			User user = query.getResultList().get(0);
			
			if(user.getTransactionPassword().equals(answer)){
				
				isCorrect = true;
				
			}
			
		}
		
		return isCorrect;
	}

	
	@Override
	public boolean changePassword(long accountId, String newPass,String table)
			throws BankException {
		
		boolean isUpdated = false;
		
		try {
			
			User user = null;
			TypedQuery<User> query = entityManager.createQuery("select u from User u where accountId = :accId", User.class);
			query.setParameter("accId", accountId);
			
			user = query.getResultList().get(0);
			
			if( user != null ){
				
				user.setLoginPass(newPass);
				entityManager.merge(user);
				isUpdated = true;
			}
			
			
		} catch(Exception e){
			
			throw (new BankException("Something went wrong"));
			
		}
		
		return isUpdated;
	}

	
}
