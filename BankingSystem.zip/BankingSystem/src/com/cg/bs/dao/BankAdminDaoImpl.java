package com.cg.bs.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bs.bean.AccountMaster;
import com.cg.bs.bean.Attempts;
import com.cg.bs.bean.Customer;
import com.cg.bs.bean.Transactions;
import com.cg.bs.bean.User;
import com.cg.bs.exception.BankException;

@Repository
@Transactional
public class BankAdminDaoImpl implements IBankAdminDao {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public long createAccount(AccountMaster accountMaster, Customer customer,
			User user) throws BankException {

		long accountId = 0l;
		
		try{
			
			entityManager.persist(customer);
			accountId = customer.getAccountId();
			
		//----------------------------------------------
			user.setAccountId(accountId);
			user.setLockStatus("A");
			
			entityManager.persist(user);
		
		//--------------------------------------------------
			accountMaster.setAccountId(accountId);;
			accountMaster.setOpenDate(Date.valueOf(LocalDate.now()));
			
			entityManager.persist(accountMaster);
			
		//--------------------------------------------------
			
			Attempts attempts = new Attempts();
			attempts.setAcountId(accountId);
			attempts.setAttempts(0);
			
			entityManager.persist(attempts);
		
			
			
		} catch(Exception e){
			
			throw new BankException("Something went wrong");
			
		}
		
		
		
		return accountId;
	}

	@Override
	public List<Transactions> getTransactions(Date dateOfTransaction,String transactionType)
			throws BankException {
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateOfTransaction);
		int date = cal.get(Calendar.DAY_OF_MONTH);
		int month = cal.get(Calendar.MONTH)+1;
		int year = cal.get(Calendar.YEAR);
		
		int dateConstraint = 0;
		String queryExecute = "";
		TypedQuery<Transactions> query = null;
		
		if(transactionType.equals("daily")){
			
			queryExecute = "select t from Transactions t where FUNCTION('DAY', t.dateOfTransaction) = :DATE_CONSTRAINT";
			dateConstraint = date;
			
		} else if (transactionType.equals("monthly")){
			
			queryExecute = "select t from Transactions t where FUNCTION('MONTH', t.dateOfTransaction) = :DATE_CONSTRAINT";
			dateConstraint = month;
			
		} else if (transactionType.equals("yearly")){
			
			queryExecute = "select t from Transactions t where FUNCTION('YEAR', t.dateOfTransaction) = :DATE_CONSTRAINT";
			dateConstraint = year;
			
		}
		
		query = entityManager.createQuery(queryExecute, Transactions.class);
		query.setParameter("DATE_CONSTRAINT", dateConstraint);
		
		
		List<Transactions> listTransaction = query.getResultList();
			
		return listTransaction;
	}
	
	
	
}
