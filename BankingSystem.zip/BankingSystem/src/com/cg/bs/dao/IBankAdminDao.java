package com.cg.bs.dao;

import java.sql.Date;
import java.util.List;

import com.cg.bs.bean.AccountMaster;
import com.cg.bs.bean.Customer;
import com.cg.bs.bean.Transactions;
import com.cg.bs.bean.User;
import com.cg.bs.exception.BankException;

public interface IBankAdminDao {

	long createAccount(AccountMaster accountMaster, Customer customer, User user) throws BankException;

	List<Transactions> getTransactions(Date dateOfTransaction,String transactionType)throws BankException;


}
