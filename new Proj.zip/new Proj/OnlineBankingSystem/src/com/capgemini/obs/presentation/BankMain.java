/**
 * 
 */
package com.capgemini.obs.presentation;

import java.util.Random;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.obs.dto.AccountMaster;
import com.capgemini.obs.dto.Customer;
import com.capgemini.obs.dto.User;
import com.capgemini.obs.exception.BankException;
import com.capgemini.obs.service.BankServiceImpl;
import com.capgemini.obs.service.IBankService;

public class BankMain {

	static final int ATTEMPT_LIMIT=3;// Attempt limits for the wrong password
	
	// --------Default values for the accountNumber and password
	static long accountNumber = 0l ;
	static String password = "UNKNOWN";
	
	
	 //Console object for the input from the user
	static Logger logger = Logger.getRootLogger();// Logger object for log generation

	private static Scanner sc;
	
	public static void main(String[] args) {
	
		PropertyConfigurator.configure("resources//log4j.properties");
		IBankService iBankService = null;// Create a bank service object 
		//List<String> errors=null ;
		int attempts=0;
		sc = new Scanner(System.in);
		boolean flag = true;
		String loginTable = "";

		
		//-----------------------------------------------------------
		do {
			System.out.println("Login as : ");
			System.out.println("----------------------------");
			System.out.println("1. Admin");
			System.out.println("2. Customer");
			
			int choice = sc.nextInt();
			
			switch(choice){
			
				case 1 : 
					loginTable = "AdminTable";
					flag = false;
					break;
				
				case 2 : 
					loginTable = "UserTable";
					flag = false;
					break;
					
				default:
					System.out.println("Please enter a valid option");
			}
			
		}while(flag);
		
		//-----------------------------------------------------------
		
		
		while(true){
				System.out.print("Enter Account Number : ");
				accountNumber = Long.parseLong(sc.next());

				System.out.print("Enter Password : ");
				password = sc.next();
			
				
	
			try {
				
				iBankService = new BankServiceImpl();
				boolean isValidUser = iBankService.isValidUser(accountNumber,password,loginTable);
				boolean isValid = false;
				if(isValidUser){
					System.out.println("VALID USER");
					
					isValid = true;
				}else {
					System.out.println("Enter VALID USER CREDENTIALS");
					isValid = false;
				}
				
			
			if(isValid){
				attempts = iBankService.getUserAttempts(accountNumber,loginTable);
				
				iBankService = new BankServiceImpl();
				boolean isLocked = iBankService.isLockedAccount(accountNumber,loginTable);
				
				while(isLocked) {
					System.out.println("Please Change Your Password.");
					System.out.println("Enter New Password");
					
				String password= sc.next();
					
					System.out.println("Re Enter Your Password");
					String rePassword = sc.next();
					
					
					if(password.equals(rePassword))
					{
						iBankService = new BankServiceImpl();
						iBankService.updatePassword(accountNumber, rePassword,loginTable);
						iBankService = new BankServiceImpl();
						iBankService.unLockAccount(accountNumber,loginTable);
						iBankService = new BankServiceImpl();
						isLocked = iBankService.isLockedAccount(accountNumber,loginTable);
						iBankService = new BankServiceImpl();
						iBankService.setUserAttemptsZero(accountNumber,loginTable);
					}
					else
					{
						System.out.println("Please Try Again!");
					}
				}
				if(attempts < ATTEMPT_LIMIT){
								
					System.out.println("YOU HAVE USED "+attempts+" ATTEMPTS");
				
				
				} else {
				
						}	
			} else {
				//password incorrect
				iBankService = new BankServiceImpl();
				iBankService.setUserAttempts(accountNumber,loginTable);
				
				iBankService = new BankServiceImpl();
				if(iBankService.getUserAttempts(accountNumber,loginTable) == ATTEMPT_LIMIT){
					iBankService = new BankServiceImpl();
					iBankService.lockAccount(accountNumber,loginTable);
				}
				
			}
			iBankService = new BankServiceImpl();
			System.out.println("Please  "+iBankService.getUserAttempts(accountNumber,loginTable));
			
			
			
			
			
			
			
			iBankService = new BankServiceImpl();
			if(iBankService.getUserAttempts(accountNumber,loginTable) > ATTEMPT_LIMIT){
				System.out.println("YOU HAVE USED ALL THE "+ ATTEMPT_LIMIT+"  ATTEMPTS");
				iBankService = new BankServiceImpl();
				iBankService .lockAccount(accountNumber,loginTable);
				
				System.out.println("Forget Password?");
				System.out.println("Answer this Question.To retrive your account");
				
				
				iBankService = new BankServiceImpl();
				String question= iBankService.getUserQuestion(accountNumber,loginTable);
				System.out.println(question);
				
				
				System.out.println("Enter the transaction password?");
				String transactionpassword =sc.next();
				iBankService = new BankServiceImpl();
				
				
				boolean isValidTransactionPassword=iBankService.isValidTransactionPassword(transactionpassword,accountNumber,loginTable);
				if(isValidTransactionPassword)
				{
					
					System.out.println("your new password is sbq500# .Please Reset As early as possible");
					String newPassword="sbq500#";
					iBankService = new BankServiceImpl();
					iBankService.updatePassword(accountNumber, newPassword,loginTable);
					
					
				}
				else
					System.out.println("You Have Again Entered the Wrong Answer ! Please Reach Us at the Nearest Branch!");
				
					
				}
				
				
			///////////////////////////////////////
			
			if(loginTable.equals("AdminTable") && isValid && attempts<ATTEMPT_LIMIT)
			{
				
				System.out.println("Select An Option :");
				System.out.println("---------------------------");
				System.out.println("1. Open an Account");
				System.out.println("2. View Transactions");
				System.out.println("2. Exit");
				int choice = sc.nextInt();
				
				
				switch(choice){
				case 1 :
					openAccount();
					
					break;
					
				case 2 :
					viewTransactions();
					break;
				
				case 3 :
					System.exit(0);
					break;
				default :
					
				
				}
				
				
				
				
			}
			else if(loginTable.equals("UserTable")&& isValid && attempts<ATTEMPT_LIMIT)
			{
				
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
			///////////////////////////////////////
		
				
				
				
				
				
			} catch (BankException bankException) {
				
				logger.error("Exception Eccured : ", bankException);				
				System.out.println("Exception Eccured : "+ bankException);
				
			}
		
			
			
		}	
		
	}

	private static void viewTransactions() {
		// TODO Auto-generated method stub
		
	}

	private static void openAccount() {
		
		AccountMaster accountMaster = new AccountMaster();
		Customer customer = new Customer();
		User user = new User();
		
		
		
			
		System.out.println("Enter the Details : ");
		System.out.println("-------------------------------");
		System.out.print("Enter the Name : ");
		String cusName= sc.nextLine();
		System.out.println("Enter the Email id:");
		String email= sc.nextLine();
		System.out.println("Enter the Address:");
		String address= sc.nextLine();
		System.out.println("Enter PANCARD Number");
		String panCard = sc.nextLine();
		
		
		
		
		
	}

}
