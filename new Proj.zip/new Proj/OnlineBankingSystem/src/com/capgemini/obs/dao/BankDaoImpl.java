package com.capgemini.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.obs.exception.BankException;
import com.capgemini.obs.util.DBConnection;

public class BankDaoImpl implements IBankDao {

	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	
	public BankDaoImpl() throws BankException{
		
		connection = DBConnection.getInstance().getConnection();

	}
	
	
	
	/*
	 * override method 
	 * isValidUser() 
	 * to check the user is valid or not 
	 * 
	 * */
	@Override
	public boolean isValidUser(long accountNumber, String password,String loginTable) throws BankException {
	
		boolean isValidUser = false;
		
		try {
			
			// checking the user exists or not 
			
			
			
				
			preparedStatement = connection.prepareStatement(QueryMapper.VALID_USER.replace("$tableName", loginTable));
			
			preparedStatement.setLong(1, accountNumber);
			resultSet = preparedStatement.executeQuery();
			
			if (resultSet.next()) {
				// if the user exists check the password is correct
				preparedStatement = connection.prepareStatement(QueryMapper.VALID_USER_PASSWORD.replace("$tableName", loginTable));
				preparedStatement.setLong(1, accountNumber);
				preparedStatement.setString(2, password);
				resultSet = preparedStatement.executeQuery();
				
				if (resultSet.next()) {
					//if the account number and password is correct
					isValidUser = true;
					
				} else {
					//if the account number and password is incorrect
					isValidUser = false;
					
				}
								
			} else {
				// users not found 
				throw (new BankException("\nUser with Account number : "+accountNumber+" does not exist\n"));
				
			}
			
		} catch (SQLException e) {
			//Sql Exception 
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		} 
		// if the Account number and password is correct then true otherwise false return 
		return isValidUser;
	}

	
	
	@Override
	public int getUserAttempts(long accountNumber,String loginTable) throws BankException {
		
		int attempts = 0;
		
		try {
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.PASSWORD_ATTEMPTS.replace("$tableName", loginTable));
			preparedStatement.setLong(1, accountNumber);
			resultSet = preparedStatement.executeQuery();
			
			// checking if data found in query for id
			if (resultSet.next()) {
				// if attempts are here
				attempts = resultSet.getInt(1);
				
			
			} 		
			System.out.println("REVHV  :  "+attempts);
			
			
		} catch (SQLException e) {
			//Sql Exception 
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		} finally {
			
			// releasing the connections and objects
			//try {
				
				//resultSet.close();
				resultSet = null;
				
				//preparedStatement.close();
				preparedStatement = null;
				
				//connection.close();
				connection = null;
				
				
			/*} catch (SQLException e) {
				// error in closing the connection
				throw (new BankException("\nTechnical Error, In closing the connection\n"));
			}*/
			
		}
		
		
		return attempts;
	
	}



	@Override
	public void lockAccount(long accountNumber,String loginTable) throws BankException {
	
		int result=0;
		try {
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.LOCK_ACCOUNT.replace("$tableName", loginTable));
			preparedStatement.setLong(1, accountNumber);
			result = preparedStatement.executeUpdate();
			
		
			
		} catch (SQLException e) {
			//Sql Exception 
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		} finally {
			
			// releasing the connections and objects
			//try {
				
				//resultSet.close();
				resultSet = null;
				
				//preparedStatement.close();
				preparedStatement = null;
				
				//connection.close();
				connection = null;
				
				
			/*} catch (SQLException e) {
				// error in closing the connection
				throw (new BankException("\nTechnical Error, In closing the connection\n"));
			}*/
			
		}
		
		
		
		
	}



	@Override
	public void setUserAttempts(long accountNumber,String loginTable) throws BankException {
	
		
		int result=0;
		try {
			connection = DBConnection.getInstance().getConnection();
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.SETPASSWORD_ATTEMPTS.replace("$tableName", loginTable));
			preparedStatement.setLong(1, accountNumber);
			result = preparedStatement.executeUpdate();
			
		
			
		} catch (SQLException e) {
			//Sql Exception 
			throw (new BankException("\nTechnical Error, Unable to Connect durin setting\n"));
			
			
		} finally {
			
			// releasing the connections and objects
			//try {
				
				//resultSet.close();
				resultSet = null;
				
				//preparedStatement.close();
				preparedStatement = null;
				
				//connection.close();
				connection = null;
				
				
			/*} catch (SQLException e) {
				// error in closing the connection
				throw (new BankException("\nTechnical Error, In closing the connection\n"));
			}*/
		}
	}



	@Override
	public String getUserQuestion(long accountNumber,String loginTable) throws BankException {
        String question = null;
		
		try {
			System.out.println("here1");
			connection = DBConnection.getInstance().getConnection();
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.GET_QUESTION.replace("$tableName", loginTable));
			preparedStatement.setLong(1, accountNumber);
			resultSet = preparedStatement.executeQuery();

			System.out.println("here2");
			// checking if data found in query for id
			if (resultSet.next()) {
				// if attempts are here
				question = resultSet.getString("secret_question");
				//System.out.println(question);
			
			} 		
			
			
		} catch (SQLException e) {
			//Sql Exception 
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		} finally {
			
			// releasing the connections and objects
			//try {
				
				//resultSet.close();
				resultSet = null;
				
				//preparedStatement.close();
				preparedStatement = null;
				
				//connection.close();
				connection = null;
				
				
			/*} catch (SQLException e) {
				// error in closing the connection
				throw (new BankException("\nTechnical Error, In closing the connection\n"));
			}*/
			
		}
		
		
		return question;
	}



	@Override
	public boolean isValidTransactionPassword(String transactionpassword,long accountNumber,String loginTable) throws BankException {
		
		
		String transactpassword=null;
		boolean isValidTransactionPassword=false;
		
		
		try {
			connection = DBConnection.getInstance().getConnection();
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.TRANSACTION_PASSWORD.replace("$tableName", loginTable));
			preparedStatement.setLong(1, accountNumber);
			resultSet = preparedStatement.executeQuery();
			
			// checking if data found in query for id
			if (resultSet.next()) {
				// if attempts are here
				transactpassword = resultSet.getString(1);
				
				if(transactpassword.equals(transactionpassword))
				{
					
					isValidTransactionPassword=true;
				}
				else
					isValidTransactionPassword=false;
			
			} 		
			
			
			
			
		} catch (SQLException e) {
			//Sql Exception 
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		} finally {
			
			// releasing the connections and objects
			//try {
				
				//resultSet.close();
				resultSet = null;
				
				//preparedStatement.close();
				preparedStatement = null;
				
				//connection.close();
				connection = null;
				
				
			/*} catch (SQLException e) {
				// error in closing the connection
				throw (new BankException("\nTechnical Error, In closing the connection\n"));
			}*/
			
		}
		
		
		return isValidTransactionPassword;
		
		
		
		
	}



	@Override
	public void unLockAccount(long accountNumber,String loginTable) throws BankException {
		 ResultSet resultSet =null;
		try {
			//0System.out.println("Upated DAo");
			preparedStatement=null;
			connection = DBConnection.getInstance().getConnection();
			preparedStatement = connection.prepareStatement(QueryMapper.UNLOCK_ACCOUNT.replace("$tableName", loginTable));
			//System.out.println("Upated DAo");
			preparedStatement.setLong(1, accountNumber);
			//System.out.println("Upated DAo"+accountNumber);
			resultSet = preparedStatement.executeQuery();
			//System.out.println("Updated : "+result);
		
			
		} catch (SQLException e) {
			//Sql Exception 
			e.printStackTrace();
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			
			// releasing the connections and objects
			//try {
				
				//resultSet.close();
				resultSet = null;
				
				//preparedStatement.close();
				preparedStatement = null;
				
				//connection.close();
				connection = null;
				
				
			/*} catch (SQLException e) {
				// error in closing the connection
				throw (new BankException("\nTechnical Error, In closing the connection\n"));
			}*/
			
		}
		
	}

	
	@Override
	public void updatePassword(long accountNumber,String newPassword,String loginTable) throws BankException {
		
		int result=0;
		try {
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_PASSWORD.replace("$tableName", loginTable));
			preparedStatement.setString(1, newPassword);
			preparedStatement.setLong(2, accountNumber);
			result = preparedStatement.executeUpdate();
			
		
			
		} catch (SQLException e) {
			//Sql Exception 
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		} finally {
			
			// releasing the connections and objects
			//try {
				
				//resultSet.close();
				resultSet = null;
				
				//preparedStatement.close();
				preparedStatement = null;
				
				//connection.close();
				connection = null;
				
				
			/*} catch (SQLException e) {
				// error in closing the connection
				throw (new BankException("\nTechnical Error, In closing the connection\n"));
			}*/
			
		}
		
		
		
	}



	@Override
	public boolean isLockedAccount(long accountNumber,String loginTable) throws BankException {

		String lockStatus=null;
		boolean isLockedAccount=false;
		
		
		try {
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.LOCK_STATUS.replace("$tableName", loginTable));
			preparedStatement.setLong(1, accountNumber);
			resultSet = preparedStatement.executeQuery();
			
			// checking if data found in query for id
			if (resultSet.next()) {
				// if attempts are here
				lockStatus = resultSet.getString(1).trim();
				System.out.println("Status : "+lockStatus);
				if(lockStatus.equals("L"))
				{
					isLockedAccount=true;
				}
				else{
					
					isLockedAccount=false;
				}
			} 		
			
			
			
			
		} catch (SQLException e) {
			//Sql Exception 
			throw (new BankException("\nTechnical Error, Unable to Connect\n"));
			
		} finally {
			
			// releasing the connections and objects
			//try {
				
				//resultSet.close();
				resultSet = null;
				
				//preparedStatement.close();
				preparedStatement = null;
				
				//connection.close();
				connection = null;
				
				
			/*} catch (SQLException e) {
				// error in closing the connection
				throw (new BankException("\nTechnical Error, In closing the connection\n"));
			}*/
			
		}
		
		
		return isLockedAccount;
		
	}



	@Override
	public void setUserAttemptsZero(long accountNumber,String loginTable) throws BankException {
		int result=0;
		try {
			connection = DBConnection.getInstance().getConnection();
			preparedStatement=null;
			preparedStatement = connection.prepareStatement(QueryMapper.SETPASSWORD_ATTEMPTS_ZERO.replace("$tableName", loginTable));
			preparedStatement.setLong(1, accountNumber);
			result = preparedStatement.executeUpdate();
			
		
			
		} catch (SQLException e) {
			//Sql Exception 
			throw (new BankException("\nTechnical Error, Unable to Connect durin setting\n"));
			
			
		} finally {
			
			// releasing the connections and objects
			//try {
				
				//resultSet.close();
				resultSet = null;
				
				//preparedStatement.close();
				preparedStatement = null;
				
				//connection.close();
				connection = null;
				
				
			/*} catch (SQLException e) {
				// error in closing the connection
				throw (new BankException("\nTechnical Error, In closing the connection\n"));
			}*/
		}
		
	}
}
