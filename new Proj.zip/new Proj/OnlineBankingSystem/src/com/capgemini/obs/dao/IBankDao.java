package com.capgemini.obs.dao;

import com.capgemini.obs.exception.BankException;

public interface IBankDao {

	boolean isValidUser(long accountNumber, String password,String loginTable) throws BankException;

	int getUserAttempts(long accountNumber,String loginTable) throws BankException;

	void lockAccount(long accountNumber,String loginTable) throws BankException;
	
	void setUserAttempts(long accountNumber,String loginTable) throws BankException;
	
	String getUserQuestion(long accountNumber,String loginTable) throws BankException ;
	
	boolean isValidTransactionPassword(String transactionpassword,long accountNumber,String loginTable) throws BankException;
	
	void unLockAccount(long accountNumber,String loginTable) throws BankException;
	
	void updatePassword(long accountNumber,String newPassword,String loginTable) throws BankException;
	
	boolean isLockedAccount(long accountNumber,String loginTable) throws BankException;

	void setUserAttemptsZero(long accountNumber,String loginTable)throws BankException;

}
