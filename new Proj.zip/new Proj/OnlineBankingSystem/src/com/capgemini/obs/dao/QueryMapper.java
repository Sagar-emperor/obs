package com.capgemini.obs.dao;

public interface QueryMapper {

	public static final String VALID_USER = "SELECT Account_ID from $tableName WHERE Account_ID=?";
	public static final String VALID_USER_PASSWORD = "SELECT Account_ID from $tableName WHERE Account_ID=? AND login_password=?";
	public static final String PASSWORD_ATTEMPTS = "SELECT Attempts from Attempts WHERE Account_Id=?";
	public static final String LOCK_ACCOUNT ="UPDATE  $tableName SET lock_status='L' WHERE Account_Id=? ";
	public static final String SETPASSWORD_ATTEMPTS = "UPDATE Attempts SET Attempts=Attempts+1 WHERE  Account_Id=? ";
	public static final String SETPASSWORD_ATTEMPTS_ZERO = "UPDATE Attempts SET Attempts=0 WHERE  Account_Id=? ";
	public static final String GET_QUESTION = "SELECT secret_question from $tableName WHERE Account_ID=? ";
	public static final String UNLOCK_ACCOUNT = "UPDATE  $tableName SET lock_status='A' WHERE Account_Id=? ";
	public static final String UPDATE_PASSWORD = "UPDATE  $tableName SET login_password=? WHERE Account_Id=?";
	public static final String TRANSACTION_PASSWORD = "SELECT Transaction_password from $tableName WHERE Account_ID=? ";
	public static final String LOCK_STATUS = "select lock_status from $tableName where Account_Id=?";
}
