package com.capgemini.obs.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;























import com.capgemini.obs.dao.BankDaoImpl;
import com.capgemini.obs.dao.IBankDao;
import com.capgemini.obs.exception.BankException;

public class BankServiceImpl implements IBankService {

	private IBankDao iBankDao;// creating reference of the DAO Interface
	
	public BankServiceImpl() throws BankException {
		
		iBankDao = new BankDaoImpl();//assigning  object of the Implementation class that contains methods
	}


	@Override
	public boolean isValidUser(long accountNumber, String password,String loginTable) throws BankException {
		
		boolean isValidUser = false;
		
		isValidUser = iBankDao.isValidUser(accountNumber,password,loginTable);
		
		return isValidUser;
	}
	
	@Override
	public int getUserAttempts(long accountNumber,String loginTable) throws BankException {
		
		int attempts = 0;// default number of attempts
		
		attempts = iBankDao.getUserAttempts(accountNumber,loginTable);// retrieving number of attempts
		
		return attempts;
	
	}


	@Override
	public List<String> validateCredentials(long accountNumber, String password) {
		// TODO Auto-generated method stub
		List<String> validationErrors = new ArrayList<>();

		
		if(!(isValidAccountNumber(accountNumber))) {
			validationErrors.add("\n Account Number  Should Be In Digits and  10 characters long(please Enter Proper Account Number) ! \n");
		}
		
		if(!(isValidPassword(password))) {
			validationErrors.add("\n Account Password should contain a digit,a lowercase letter, a uppercase letter,one special symbols in the list (@#$%),minimum 6 characters maximum 20  \n");
		}
		
		
		return validationErrors;
	}
	
	 boolean isValidAccountNumber(long accountNumber)
	{
		 Pattern accountNumberPattern=Pattern.compile("[0-9]{10}$");
		 String accountNumberString = Long.toString(accountNumber);
			Matcher accountNumberMatcher=accountNumberPattern.matcher(accountNumberString);
			return accountNumberMatcher.matches();		
	}
	 
	 boolean isValidPassword(String password)
	 {
		 String passwordPatternString = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
	/*  (				# Start of group
  		(?=.*\d)		#   must contains one digit from 0-9
  		(?=.*[a-z])		#   must contains one lowercase characters
  		(?=.*[A-Z])		#   must contains one uppercase characters
  		(?=.*[@#$%])	#   must contains one special symbols in the list "@#$%"
              .			#   match anything with previous condition checking
                {6,20}	#   length at least 6 characters and maximum of 20
			)			# End of group                     
	*/
		 Pattern passwordPattern = Pattern.compile(passwordPatternString);
		 Matcher passwordPatternMatcher = passwordPattern.matcher(password);
		 return passwordPatternMatcher.matches();
	 }


	@Override
	public void lockAccount(long accountNumber,String loginTable) throws BankException {
		
		iBankDao.lockAccount(accountNumber,loginTable);
		
	}


	@Override
	public void setUserAttempts(long accountNumber,String loginTable) throws BankException {
		
		iBankDao.setUserAttempts(accountNumber,loginTable);
		
	}


	@Override
	public String getUserQuestion(long accountNumber,String loginTable) throws BankException {
		
		String question =iBankDao.getUserQuestion(accountNumber,loginTable);
		return question;
	}


	@Override
	public boolean isValidTransactionPassword(String transactionpassword,long accountNumber,String loginTable) throws BankException {
		boolean isValidTransactionPassword = iBankDao.isValidTransactionPassword(transactionpassword, accountNumber, loginTable);
		return isValidTransactionPassword;
	}


	@Override
	public void unLockAccount(long accountNumber,String loginTable) throws BankException {
		System.out.println("Iam Service");
		iBankDao.unLockAccount(accountNumber, loginTable);
		System.out.println("Iam Service");
		
		
	}


	@Override
	public void updatePassword(long accountNumber,String newPassword,String loginTable) throws BankException {
		
		
		iBankDao.updatePassword(accountNumber, newPassword,loginTable);
	}


	@Override
	public boolean isLockedAccount(long accountNumber,String loginTable) throws BankException {
	boolean isLockedAccount=iBankDao.isLockedAccount(accountNumber,loginTable);
	return isLockedAccount;
		
	}


	@Override
	public void setUserAttemptsZero(long accountNumber,String loginTable) throws BankException {
		// TODO Auto-generated method stub
		iBankDao.setUserAttemptsZero(accountNumber,loginTable);
	}


	
	

}
