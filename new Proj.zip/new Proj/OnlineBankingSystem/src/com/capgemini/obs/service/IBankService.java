/**
 * 
 */
package com.capgemini.obs.service;

import java.util.List;

import com.capgemini.obs.exception.BankException;

public interface IBankService {

	int getUserAttempts(long accountNumber,String loginTable) throws BankException;

	boolean isValidUser(long accountNumber, String password,String loginTable) throws BankException;
	
	List<String> validateCredentials(long  accountNumber,String password); 
	
	void lockAccount(long accountNumber,String loginTable) throws BankException;
	
	void setUserAttempts(long accountNumber,String loginTable) throws BankException;
	
	String getUserQuestion(long accountNumber,String loginTable) throws BankException ;
	
	boolean isValidTransactionPassword(String transactionpassword,long accountNumber,String loginTable) throws BankException;
	
	void unLockAccount(long accountNumber,String loginTable) throws BankException;
	
	void updatePassword(long accountNumber,String newPassword,String loginTable) throws BankException;
	
	boolean isLockedAccount(long accountNumber,String loginTable) throws BankException;

	void setUserAttemptsZero(long accountNumber,String loginTable) throws BankException;

}
