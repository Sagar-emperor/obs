package com.cg.ti.service;


import java.util.List;
	







import com.cg.ti.bean.TrainBean;
import com.cg.ti.dao.TrainDAO;
import com.cg.ti.dao.TrainDAOImpl;
import com.cg.ti.exception.TrainException;

public class TrainServiceImpl implements TrainService {

	TrainDAO dao = new TrainDAOImpl();

	@Override
	public List<TrainBean> getAllTrains() throws TrainException {
		List<TrainBean> list = dao.getAllTrains();
		return list;
		
	}
	public void makeBooking(int seatBook, String trainId) throws TrainException
	{
		dao.makeBooking(seatBook,trainId);
	}
	public void addTrain(TrainBean dto) throws TrainException {
		// TODO Auto-generated method stub
		dao.addTrain(dto);
		//return 0;
	}
	@Override
	public TrainBean getTrain(String trainId) throws TrainException {
		
		
			TrainBean dto = new TrainBean();

			dto = dao.getTrain(trainId);
			return dto;

		}
	}
	

