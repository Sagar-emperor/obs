package com.cg.ti.dao;

public interface QueryMapper {

	String VIEWALL = "SELECT trainid,trainname,destination,journeydate,noofseats,fare  FROM traininfo";
	String UPDATE = "UPDATE traininfo SET noofseats=noofseats-? WHERE trainId=?";
	String INSERTQUERY="INSERT INTO TRAININFO VALUES(?,?,?,?,?,?)";
	String VIEW ="SELECT trainname,destination,noofseats,fare  FROM traininfo where trainId=?";

}
