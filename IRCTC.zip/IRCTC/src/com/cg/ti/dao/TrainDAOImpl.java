  package com.cg.ti.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;








import com.cg.ti.utility.DbConnection;
import com.cg.ti.bean.TrainBean;
import com.cg.ti.exception.TrainException;

public class TrainDAOImpl implements TrainDAO {
	PreparedStatement preparedStatement = null;
	Connection conn = null;
	ResultSet resultSet = null;

	@Override
	public List<TrainBean> getAllTrains() throws TrainException {
		
		List<TrainBean> list = new ArrayList<TrainBean>();
		TrainBean dto = new TrainBean();
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(QueryMapper.VIEWALL);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				//dto.setTrainId(resultSet.getString(1));
				dto.setTrainId(resultSet.getString(1));
				dto.setTrainName(resultSet.getString(2));
				dto.setDestination(resultSet.getString(3));
				dto.setJourneyDate(resultSet.getDate(4).toLocalDate());
				dto.setNoOfSeats(resultSet.getInt(5));
				dto.setFare(resultSet.getDouble(6));
				
				list.add(dto);
				dto = new TrainBean();
			}
		} catch (SQLException e) {
			throw new TrainException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new TrainException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new TrainException(
						"Could not close the connection");
			}
		}
		return list;
	}

	@Override
	public void makeBooking(int seatBook, String trainId) throws TrainException {
		
		
		
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(QueryMapper.UPDATE);
			preparedStatement.setInt(1,seatBook);
			preparedStatement.setString(2, trainId);
			preparedStatement.executeUpdate();
		}
		 catch (SQLException e) {
			 e.printStackTrace();
				throw new TrainException("Error while database interaction:::"
						+ e.getMessage());
			}
			
			
	}

	@Override
	public void addTrain(TrainBean dto) throws TrainException {
		
		int result = 0;
		//int sequence = 0;
		
		//RegBean regbean  = new RegBean();
		
		//String take[]=regbean.getSkillset();
		//Integer trainno=null;
		
		
		
		
		try {
			//conn = DbConnection.getConnection();
			
				conn = DbConnection.getConnection();
			
			preparedStatement = conn.prepareStatement(QueryMapper.INSERTQUERY);
		
			//preparedStatement.setInt(1, bean.getBill_num());
				preparedStatement.setString(1, dto.getTrainId());
				preparedStatement.setString(2, dto.getTrainName());
				preparedStatement.setString(3, dto.getDestination());
				preparedStatement.setDate(4, java.sql.Date.valueOf(dto.getJourneyDate()));
				preparedStatement.setInt(5, dto.getNoOfSeats());
				preparedStatement.setDouble(6, dto.getFare());		
				System.out.println(dto.getTrainId()+" "+dto.getTrainName()+" "+dto.getJourneyDate());
				
				result = preparedStatement.executeUpdate();
				
				

				

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Invalid USer");
		}

		
		
	}

	@Override
	public TrainBean getTrain(String trainId) throws TrainException {
		
			TrainBean dto = new TrainBean();
			try {
				conn = DbConnection.getConnection();
				preparedStatement = conn.prepareStatement(QueryMapper.VIEW);
				preparedStatement.setString(1, trainId);
				resultSet = preparedStatement.executeQuery();
				while (resultSet.next()) {
					
					dto.setTrainName(resultSet.getString(1));
					dto.setDestination(resultSet.getString(2));
					dto.setNoOfSeats(resultSet.getInt(3));
					dto.setFare(resultSet.getDouble(4));
					// Convert SQL to Calendar Date
					// Date date = resultSet.getDate(6);
					/*
					 * Calendar cDate = Calendar.getInstance(); cDate.setTime(date);
					 */
					
				}

			} catch (SQLException e) {
				throw new TrainException("dao/sql/ERROR:"
						+ e.getMessage());
			} catch (Exception e) {
				throw new TrainException("ERROR:" + e.getMessage());
			} finally {
				try {
					if (conn != null) {
						preparedStatement.close();
						conn.close();
						resultSet.close();
					}
				} catch (Exception e) {
					throw new TrainException(
							"Could not close the connection");
				}
			}
			return dto;
		}

		
	
	
	

}

