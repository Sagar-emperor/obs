package com.cg.ti.exception;

public class TrainException extends Exception {
	
	public TrainException(String message)
	{
		super(message);
	}

}
