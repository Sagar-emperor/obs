CREATE TABLE customer
(customer_name VARCHAR2(20),
user_name VARCHAR2(20) PRIMARY KEY,
password VARCHAR2(20),
mobile_number VARCHAR2(20),
amount NUMBER(4) default 1000,
bill_date DATE);