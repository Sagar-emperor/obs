package com.cg.dth.dao;

public interface IDthDao {

}
