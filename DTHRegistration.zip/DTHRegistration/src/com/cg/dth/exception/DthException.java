package com.cg.dth.exception;

public class DthException {

}
