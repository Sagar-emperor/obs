package com.cg.dth.bean;

public class DthBean {

}
