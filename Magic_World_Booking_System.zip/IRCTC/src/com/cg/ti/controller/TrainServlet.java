package com.cg.ti.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;







import com.cg.ti.bean.TrainBean;
import com.cg.ti.dao.TrainDAO;
import com.cg.ti.exception.TrainException;
import com.cg.ti.service.TrainServiceImpl;

/**
 * Servlet implementation class TrainServlet
 */
@WebServlet("*.obj")
public class TrainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TrainServlet() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		TrainServiceImpl trainService = null;
		TrainBean dto = null;
		String target = "";
		PrintWriter out = response.getWriter();
		

		HttpSession session = request.getSession(true);
		// Object creations
		dto =  new TrainBean();
		trainService = new TrainServiceImpl();
		//int donorId = 0;
		
		String targetSuccess = "sucess.jsp";
		
		String targetViewAll = "viewAllTrains.jsp";
		String targetError = "error.jsp";
		String targetHome = "index.jsp";
		String targetBook = "book.jsp";
		String targetInsert = "insert.jsp";
		String targetSearch = "search.jsp";
		String targetView="viewtrain.jsp";
	

		String path = request.getServletPath().trim();

		switch (path) {

		case "/Home.obj":
			session.setAttribute("error", null);
			session.setAttribute("dto", null);
			target = targetHome;
			break;
			
		case "/searchById.obj":
			target=targetSearch;
			break;
			
		case "/insert.obj":
			
			target = targetInsert;
			String trainno = request.getParameter("trainno");
			String trainName = request.getParameter("trainName");
			String destination = request.getParameter("destination");
			LocalDate journeyDate = (LocalDate.parse(request.getParameter("journeyDate")));
			Integer noofSeats = Integer.parseInt(request.getParameter("noOfSeats"));
			System.out.println(noofSeats);
			Double fare = Double.parseDouble(request.getParameter("fare"));
			 
			
			
			
			//TrainService trainservice = new TrainServiceImpl();
			//TrainBean bean = new TrainBean();
			dto.setTrainId(trainno);
			dto.setTrainName(trainName);
			dto.setDestination(destination);
			dto.setJourneyDate(journeyDate);
			dto.setNoOfSeats(noofSeats);
			dto.setFare(fare);
			
			
			
			
			try {
				
				trainService.addTrain(dto);
				//out.println("Done");
				RequestDispatcher dispatcher = request.getRequestDispatcher("Display.jsp");
				dispatcher.forward(request, response);
				
				
				
				}
				
				
				
			 catch (TrainException e) {
				
				out.println("Failure");
			
			}
			
			
			response.setContentType("text/html");
			
			
			break;
			

			
		
		

			case "/ViewAllTrains.obj":
			List<TrainBean> trainList = null;
			try {
				trainList = trainService.getAllTrains();
			} catch (TrainException e) {
				session.setAttribute("error", e.getMessage());
				target = targetError;
			}
			if (!trainList.isEmpty()) {
				session.setAttribute("error", null);
				session.setAttribute("trainList", trainList);
				target = targetViewAll;
			} else {
				session.setAttribute("trainList", null);
				session.setAttribute("error", "Sorry No data Found!");
				target = targetViewAll;
			}

			break;
		
		
		case "/book.obj":
			session.setAttribute("name", request.getParameter("name"));
			session.setAttribute("fare", request.getParameter("fare"));
			session.setAttribute("trainId", request.getParameter("trainId"));
			session.setAttribute("noOfSeats", request.getParameter("noOfSeats"));
			target = targetBook;
			break;
			
		case "/success.obj":
			
			String passName = request.getParameter("passname");
			String mobno = request.getParameter("mobno");
			Integer seatBook = Integer.parseInt(request.getParameter("seatBook"));
			String trainId=(String)session.getAttribute("trainId");
			session.setAttribute("passName",passName);
			session.setAttribute("mobno",mobno);
			session.setAttribute("seatBook",seatBook);
			System.out.println(trainId);
			try{
				trainService.makeBooking(seatBook,trainId);
			}
			catch (TrainException e1)
			{
				e1.printStackTrace();
			}
			target=targetSuccess;
			break;
		case "/addtrain.obj":
			target=targetInsert;
			break;
		
		
		case "/viewTrain.obj":
			dto=new TrainBean();
			trainId = request.getParameter("trainId");
			try {
				dto = trainService.getTrain(trainId);
			} catch (TrainException e) {
				session.setAttribute("error", e.getMessage());
				target = targetError;
			}
			if (dto.getTrainId() == null) {
				session.setAttribute("dto", null);
				session.setAttribute("error",
						"Sorry No data Found for given ID!");
				target = targetError;
				session.setAttribute("error", null);
				session.setAttribute("dto", dto);
				target = targetView;
			} else {
				session.setAttribute("error", null);
				session.setAttribute("dto", dto);
				//System.out.println(dto.getTrainName());
				target = targetView;
				
			}

			break;
		}
		

		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}
	
	}


