package com.cg.ti.service;

import java.util.List;



import com.cg.ti.bean.TrainBean;
import com.cg.ti.exception.TrainException;



public interface TrainService {

	
	public List<TrainBean> getAllTrains()throws TrainException;
	public void makeBooking(int seatBook, String trainId)throws TrainException;
	public void addTrain(TrainBean dto) throws TrainException;
	public TrainBean getTrain(String trainId) throws TrainException;
}
