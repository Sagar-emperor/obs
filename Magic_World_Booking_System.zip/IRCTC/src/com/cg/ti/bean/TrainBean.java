package com.cg.ti.bean;

import java.sql.Date;
import java.time.LocalDate;

public class TrainBean {

	private String trainId;
	private String trainName;
	private String destination;
	private LocalDate journeyDate;
	private int noOfSeats;
	private double fare;
	
	
	public TrainBean()
	{
		super();
	}


	public TrainBean(String trainId, String trainName, String destination,
			int noOfSeats, double fare) {
		super();
		this.trainId = trainId;
		this.trainName = trainName;
		this.destination = destination;
		
		this.noOfSeats = noOfSeats;
		this.fare = fare;
	}


	public String getTrainId() {
		return trainId;
	}


	public void setTrainId(String trainId) {
		this.trainId = trainId;
	}


	public String getTrainName() {
		return trainName;
	}


	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}


	public String getDestination() {
		return destination;
	}


	public void setDestination(String destination) {
		this.destination = destination;
	}

	public LocalDate getJourneyDate() {
		/* Calendar Date Converted to String format for Displaying to User */
		/*java.util.Date date = donationDate.getTime();
		SimpleDateFormat frmat = new SimpleDateFormat("dd-MMM-yyyy");
		String jDate = frmat.format(date);*/
		return  journeyDate;
	}
	
	
	

	public void setJourneyDate(LocalDate journeyDate) {
		this.journeyDate = journeyDate;
	}
	

	public int getNoOfSeats() {
		return noOfSeats;
	}


	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}


	public double getFare() {
		return fare;
	}


	public void setFare(double fare) {
		this.fare = fare;
	}


	@Override
	public String toString() {
		return "TrainBean [trainId=" + trainId + ", trainName=" + trainName
				+ ", destination=" + destination + ", journeyDate="
				+ journeyDate + ", noOfSeats=" + noOfSeats + ", fare=" + fare
				+ "]";
	}
	
	
}
