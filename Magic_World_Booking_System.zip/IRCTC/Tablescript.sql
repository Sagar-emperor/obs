 create table traininfo(trainid varchar2(6) primary key,
 trainname varchar2(20) unique,
 destination varchar2(25),
 journeydate date,
 noofseats number(3),
 fare number(5,2));


INSERT INTO traininfo values('S100','SHATABADI EXPRESS','DELHI',TO_DATE('17/09/2017','DD/MM/YYYY'),60,250);
INSERT INTO traininfo values('S101','DURONTO EXPRESS','BANGLORE',TO_DATE('25/10/2017','DD/MM/YYYY'),50,223.23);
INSERT INTO traininfo values('S102','COALFIELD EXPRESS','DHANBAD',TO_DATE('12/11/2017','DD/MM/YYYY'),20,102.03);

INSERT INTO traininfo values('S103','BLACK DIAMOND','HOWRAH',TO_DATE('28/04/2017','DD/MM/YYYY'),56,500.23);
INSERT INTO traininfo values('S104','GARIBRATH EXPRESS','PATNA',TO_DATE('14/03/2017','DD/MM/YYYY'),30,270);


