package com.cg.ticketbooking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ticketbooking.bean.BookingBean;
import com.cg.ticketbooking.exception.BookingException;
import com.cg.ticketbooking.util.DBConnection;


/**
 *  Author 		: DINESH_135142
 *  Class Name 	: ShowDAO
 *  Package 	:com.cg.ticketbooking.dao 
 *  Date 		: Sept 25, 2017
 */

public class ShowDAO implements IShowDAO {
	List<BookingBean> list =new ArrayList<BookingBean>();
	PreparedStatement preparedStatement=null;
	ResultSet resultSet = null;
	
	//-------------------1. View All Show Details -------------
	@Override
	public List<BookingBean> viewAllTrains() throws BookingException {
		// TODO Auto-generated method stub
		Connection connection = DBConnection.getConnection();
		try{
		preparedStatement = connection.prepareStatement(QueryMapper.VIEWALL);
		resultSet = preparedStatement.executeQuery();
		while(resultSet.next()){
		BookingBean bean = new BookingBean();
		bean.setShowId(resultSet.getString(1));
		bean.setShowName(resultSet.getString(2));
		bean.setLocation(resultSet.getString(3));
		bean.setShowDate(resultSet.getDate(4).toLocalDate());
		bean.setSeats(resultSet.getInt(5));
		bean.setFare(resultSet.getDouble(6));

		list.add(bean);
		}
		}catch(SQLException sqlException){
			sqlException.printStackTrace();
			throw new BookingException("Technical Problem occured refer log");
		}
		return list;
	}

	
	//-------------------2. Updating Booked show seats--------------
	@Override
	public void seatCount(int val, String id) throws BookingException {
		// TODO Auto-generated method stub
		Connection connection = DBConnection.getConnection();
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.SEATUPDATE);
			preparedStatement.setInt(1, val);
			preparedStatement.setString(2, id);
			int result = preparedStatement.executeUpdate();
			//System.out.println(result);
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		throw new BookingException("dao/sql/ERROR:"
				+ e.getMessage());
		}catch (Exception e) {
			throw new BookingException("ERROR:" + e.getMessage());
	}
}
}