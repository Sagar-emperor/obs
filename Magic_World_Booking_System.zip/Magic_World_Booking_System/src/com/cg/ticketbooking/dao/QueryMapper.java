package com.cg.ticketbooking.dao;

public class QueryMapper {
	public static final String VIEWALL = "SELECT showId,showName,location,showDate,avSeats,priceTicket FROM ShowDetails";
	public static final String SEATUPDATE = "UPDATE ShowDetails SET avSeats=? WHERE showId=?";
}
