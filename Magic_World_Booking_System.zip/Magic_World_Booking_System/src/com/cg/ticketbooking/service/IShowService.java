package com.cg.ticketbooking.service;

import java.util.List;

import com.cg.ticketbooking.bean.BookingBean;
import com.cg.ticketbooking.exception.BookingException;

public interface IShowService {
	public List<BookingBean> viewAllTrains() throws BookingException;
	public void seatCount(int val,String id) throws BookingException;
}
