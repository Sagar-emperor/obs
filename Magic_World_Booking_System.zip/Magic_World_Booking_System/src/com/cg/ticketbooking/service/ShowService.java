package com.cg.ticketbooking.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.ticketbooking.bean.BookingBean;
import com.cg.ticketbooking.dao.IShowDAO;
import com.cg.ticketbooking.dao.ShowDAO;
import com.cg.ticketbooking.exception.BookingException;


/**
* Author 		: DINESH_135142 
* Class Name 	: ShowService 
* Package 		: com.cg.ticketbooking.service 
* Date 			: Sept 25, 2017
*/
public class ShowService implements IShowService {
	IShowDAO daoobj = new ShowDAO();
	
	@Override
	public List<BookingBean> viewAllTrains() throws BookingException {
		// TODO Auto-generated method stub
		//List<BookingBean> list = new  ArrayList<BookingBean>();
		List<BookingBean> list = daoobj.viewAllTrains();
		return list;
	}

	@Override
	public void seatCount(int val, String id) throws BookingException {
		// TODO Auto-generated method stub
		daoobj.seatCount(val, id);
	}

}
