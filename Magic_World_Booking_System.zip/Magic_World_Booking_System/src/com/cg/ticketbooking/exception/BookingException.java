package com.cg.ticketbooking.exception;

/**
 * Author 		: Dinesh 
 * Class Name 	: BookingExceptions
 * Package 		: com.capgemini.ticketbooking.exception
 * Date 		: Sept 25, 2017
 */

public class BookingException extends Exception{
	public BookingException(String message){
		super(message);
	}
}
