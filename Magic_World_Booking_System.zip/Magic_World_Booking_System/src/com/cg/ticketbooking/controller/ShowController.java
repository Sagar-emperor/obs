package com.cg.ticketbooking.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ticketbooking.bean.BookingBean;
import com.cg.ticketbooking.exception.BookingException;
import com.cg.ticketbooking.service.IShowService;
import com.cg.ticketbooking.service.ShowService;


/**
 *  Author : CAPGEMINI
 *  Class Name : ShowController
 *  Package :com.cg.ticketbooking.controller; 
 *  Date : Sept 25, 2017
 */
/**
 * Servlet implementation class ShowController
 */
@WebServlet("*.obj")
public class ShowController extends HttpServlet {
	double fare;
	String id;
	int seats;
	String name;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ShowService sService = null;
		BookingBean bean = null;
		String target ="";
		HttpSession session = request.getSession(true);
		bean = new BookingBean();
		sService = new ShowService();
		String targetviewall = "view/showdetails.jsp";
		String targetbook = "view/booknow.jsp";
		String targetsuccess = "view/success.jsp";
		String targeterror = "view/error.jsp";
		
		String path = request.getServletPath().trim();
		System.out.println(path);
		switch(path){
		
		// Code for view all **********************/
		case "/viewshows.obj":
			List<BookingBean> beanList = null;

			try {                          
				beanList = sService.viewAllTrains();
			} catch (BookingException e) {
				// TODO Auto-generated catch block  
				session.setAttribute("error", e.getMessage());
				e.printStackTrace();
				target = targeterror;
			}
			if(!beanList.isEmpty()){
				session.setAttribute("error", null);
				session.setAttribute("beanList", beanList);
				target = targetviewall;
			}
			
			break;
		case "/bookNow.obj":
			//Code for updating seats count in data base************/
			id = request.getParameter("id");
			name = request.getParameter("name");
			seats = Integer.parseInt(request.getParameter("seats"));
			fare = Double.parseDouble(request.getParameter("cost"));
			session.setAttribute("id",id);
			session.setAttribute("name",name);
			session.setAttribute("seats",seats);
			session.setAttribute("fare",fare);
			target = targetbook;
			break;
		case "/success.obj":
			String custname = request.getParameter("custname");
			String custnumber=request.getParameter("custnumber");
			int seatsbooked = Integer.parseInt(request.getParameter("seatscount"));
			
			
			try {
				IShowService update = new ShowService();
				int remaining = seats - seatsbooked;
				update.seatCount(remaining, id);
			} catch (BookingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				System.out.println("here comes the problem");
			}
			session.setAttribute("sname", name);
			session.setAttribute("cname", custname);
			session.setAttribute("number", custnumber);
			session.setAttribute("seats", seatsbooked);
			double tfare =seatsbooked*fare;
			session.setAttribute("fare", tfare);
			target = targetsuccess;
		break;
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}

}
