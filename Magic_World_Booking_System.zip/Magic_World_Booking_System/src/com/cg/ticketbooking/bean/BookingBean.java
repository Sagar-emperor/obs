package com.cg.ticketbooking.bean;

import java.time.LocalDate;

/**
 * Author 		: Dinesh_135142 
 * Class Name 	: BookingBean 
 * Package 		: com.cg.ticketbooking.bean 
 * Date 		: Sept 25, 2017
 */

public class BookingBean {
	private String showId;
	private String showName;
	private String location;
	private LocalDate showDate;
	private int seats;
	private double fare;
	
	/**
	 * Getter and Setter Methods
	 * 
	 */
	public String getShowId() {
		return showId;
	}
	public void setShowId(String showId) {
		this.showId = showId;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public LocalDate getShowDate() {
		return showDate;
	}
	public void setShowDate(LocalDate showDate) {
		this.showDate = showDate;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public double getFare() {
		return fare;
	}
	public void setFare(double fare) {
		this.fare = fare;
	}
	
	
	
	/**
	 * Constructors
	 */
	public BookingBean() {
		super();
		this.showId = showId;
		this.showName = showName;
		this.location = location;
		this.showDate = showDate;
		this.seats = seats;
		this.fare = fare;
	}
	
	
}
