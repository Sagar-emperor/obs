package com.cg.tds.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.tds.bean.TraineeBean;
import com.cg.tds.service.ITraineeService;

@Controller
public class TraineeController {
	ModelAndView model;
	
	@Autowired
	ITraineeService traineeservice;

	@RequestMapping("/showhomepage")
	public String showpage(){
		return("login");
	}
	
	@RequestMapping("/login")
	public ModelAndView authenticate(@RequestParam("name") String name, @RequestParam("password") String password){
		//boolean response = traineeservice.authenticate(name, password);
		model = new ModelAndView();
		if(name.equals("admin") && password.equals("admin123")){
			model.setViewName("menu");
		}
		else {
			model.setViewName("error");
			model.addObject("message", "Wrong credentials");
		}
		return model;
	}
	
	@RequestMapping("/addtrainee")
	public String adddetails(){
		return ("adddetails");
	}
	
	@RequestMapping("/add")
	public ModelAndView addTrainee(@ModelAttribute("traineeBean") TraineeBean traineeBean, BindingResult result){
		
		model = new ModelAndView();
		if(result.hasErrors()){
			//System.out.println(result);
			model.setViewName("error");
			model.addObject("message", "Binding Error");
		}
		else{
			traineeservice.addTrainee(traineeBean);
			model.setViewName("success");
			model.addObject("message","Trainee Added");
		}
		return(model);
	}
	
	@RequestMapping("/deletetrainee")
	public String deleteTrainee(){
		return("idrequest");
	}
	
	@RequestMapping("/dataretrieve")
	public ModelAndView displayTraineeDetailsById(@RequestParam("traineeId") int id){
		model = new ModelAndView();
		TraineeBean bean = traineeservice.displayTraineeDetailsById(id);
		if(bean != null){
			model.setViewName("displayoptionfordelete");
			model.addObject("bean", bean);
		}
		return(model);
	}
	
	@RequestMapping("/deletethistrainee")
	public ModelAndView deleteThisTrainee(@RequestParam("id") int id){
		boolean response = traineeservice.deleteThisTrainee(id);
		if(!response){
			model.setViewName("error");
			model.addObject("message", "Error in Deleting");
		}
		else{
			model.setViewName("success");
			model.addObject("message","Trainee Deleted");
		}
		return(model);
	}
	
	@RequestMapping("/modifytrainee")
	public String modify(){
		return("modifyoperation");
	}
	
	@RequestMapping("/getBeanUsingIdToModify")
	public ModelAndView detailsOfTraineetoModify(@RequestParam("traineeId") int id){
		model = new ModelAndView();
		TraineeBean bean = traineeservice.detailsOfTraineetoModify(id);
		if(bean != null){
			model.setViewName("diplaydetailstomodify");
			model.addObject("bean", bean);
		}
		return(model);
	}
	
	@RequestMapping("/updatedetails")
	public ModelAndView modifyTrainee(@ModelAttribute("traineeBean") TraineeBean traineeBean, BindingResult result){
		
		model = new ModelAndView();
		if(result.hasErrors()){
			//System.out.println(result);
			model.setViewName("error");
			model.addObject("message", "Binding Error");
		}
		else{
			traineeservice.modifyTrainee(traineeBean);
			model.setViewName("success");
			model.addObject("message","Trainee Modified");
		}
		return(model);
	}
	
	
	@RequestMapping("/retrievetrainee")
	public String viewTrainee(){
		return("viewtrainee");
	}
	
	@RequestMapping("/viewtrainee")
	public ModelAndView viewTrainee(@RequestParam("traineeId") int id){
		model = new ModelAndView();
		TraineeBean bean = traineeservice.displayTraineeDetailsById(id);
		if(bean != null){
			model.setViewName("traineedetail");
			model.addObject("bean", bean);
		}
		return(model);
	}
	
	@RequestMapping("/retrievealltrainee")
	public ModelAndView viewAllTrainees(){
		List<TraineeBean> list = traineeservice.viewAllTrainee();
		ModelAndView model = new ModelAndView("viewAllTrainee");
		model.addObject("traineelist", list);
		return(model);
	}
	
	
}
