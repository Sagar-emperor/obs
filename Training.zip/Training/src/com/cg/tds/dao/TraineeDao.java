package com.cg.tds.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.tds.bean.TraineeBean;

@Repository
@Transactional
public class TraineeDao implements ITraineeDao {

	@PersistenceContext
	EntityManager em;
	
	@Override
	public boolean addTrainee(TraineeBean bean) {
		try{
			em.persist(bean);
			return true;
		}catch(Exception e){
			return false;
		}
	}

	@Override
	public TraineeBean displayTraineeDetailsById(int id) {
		TraineeBean bean = em.find(TraineeBean.class, id);
		return bean;
	}

	@Override
	public boolean deleteThisTrainee(int id) {
		TraineeBean bean = em.find(TraineeBean.class, id);
		if(bean != null){
			em.remove(bean);
			return true;
		}
		return false;
	}

	@Override
	public TraineeBean detailsOfTraineetoModify(int id) {
		TraineeBean bean = em.find(TraineeBean.class, id);
		return bean;
	}

	@Override
	public List<TraineeBean> viewAllTrainee() {
		TypedQuery<TraineeBean> query = em.createQuery("from TraineeBean", TraineeBean.class);
		//Query query = em.createQuery("update TraineeBean set traineeName='lucky' where traineeId=103" );
		List<TraineeBean> list = query.getResultList();
/*int p= query.executeUpdate();
List<TraineeBean> list = null;
if(p>0)
{	TypedQuery<TraineeBean> query1 = em.createQuery("from TraineeBean", TraineeBean.class);
		list = query1.getResultList();
		
}*/
		return list;
		//return null;
	}

	@Override
	public boolean modifyTrainee(TraineeBean traineeBean) {
		TraineeBean bean = em.find(TraineeBean.class, traineeBean.getTraineeId());
		if(bean != null){
			em.remove(bean);}
		try{
			em.persist(traineeBean);
			return true;
		}catch(Exception e){
			return false;
		}
	}

	
}
