package com.cg.tds.dao;

import java.util.List;

import com.cg.tds.bean.TraineeBean;

public interface ITraineeDao {
	public boolean addTrainee(TraineeBean bean);
	public TraineeBean displayTraineeDetailsById(int id);
	public boolean deleteThisTrainee(int id);
	public TraineeBean detailsOfTraineetoModify(int id);
	public List<TraineeBean> viewAllTrainee();
	public boolean modifyTrainee(TraineeBean traineeBean);

}
