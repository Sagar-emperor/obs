package com.cg.tds.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tds.bean.TraineeBean;
import com.cg.tds.dao.ITraineeDao;

@Service
public class TraineeService implements ITraineeService {

	@Autowired
	ITraineeDao traineedao;
	
	@Override
	public boolean addTrainee(TraineeBean bean) {
		return traineedao.addTrainee(bean);
	}

	@Override
	public TraineeBean displayTraineeDetailsById(int id) {
		TraineeBean bean = traineedao.displayTraineeDetailsById(id);
		return bean;
	}

	@Override
	public boolean deleteThisTrainee(int id) {
		boolean response = traineedao.deleteThisTrainee(id);
		return response;
	}

	@Override
	public TraineeBean detailsOfTraineetoModify(int id) {
		return traineedao.detailsOfTraineetoModify(id);
	}

	@Override
	public List<TraineeBean> viewAllTrainee() {
		return traineedao.viewAllTrainee();
	}

	@Override
	public boolean modifyTrainee(TraineeBean traineeBean) {
		return traineedao.modifyTrainee(traineeBean); 
		//return response;
	}

}
