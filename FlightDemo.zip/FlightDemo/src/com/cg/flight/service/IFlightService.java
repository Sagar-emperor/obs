package com.cg.flight.service;

import java.util.List;

import com.cg.flight.bean.FlightBean;
import com.cg.flight.exception.FlightException;

public interface IFlightService {
	public List<FlightBean> fetachall() throws FlightException;
	public boolean updateflight(FlightBean flight) throws FlightException;
	public boolean udeleteflight(int id) throws FlightException;
}
