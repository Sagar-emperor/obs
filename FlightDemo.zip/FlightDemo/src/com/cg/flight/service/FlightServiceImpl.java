package com.cg.flight.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.flight.bean.FlightBean;
import com.cg.flight.dao.IFlightDAO;
import com.cg.flight.exception.FlightException;

@Service
public class FlightServiceImpl implements IFlightService {

	@Autowired
	IFlightDAO dao;
	
	public IFlightDAO getDao() {
		return dao;
	}

	public void setDao(IFlightDAO dao) {
		this.dao = dao;
	}

	@Override
	public List<FlightBean> fetachall() throws FlightException {
		
		return dao.fetachall();
	}

	@Override
	public boolean updateflight(FlightBean flight) throws FlightException {
		// TODO Auto-generated method stub
		return dao.updateflight(flight);
	}

	@Override
	public boolean udeleteflight(int id) throws FlightException {
		// TODO Auto-generated method stub
		return dao.udeleteflight(id);
	}

}
