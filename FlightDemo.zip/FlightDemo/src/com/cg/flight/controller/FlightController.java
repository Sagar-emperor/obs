package com.cg.flight.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.flight.bean.FlightBean;
import com.cg.flight.exception.FlightException;
import com.cg.flight.service.IFlightService;



@Controller
public class FlightController {

	@Autowired
	IFlightService service;

	public IFlightService getService() {
		return service;
	}

	public void setService(IFlightService service) {
		this.service = service;
	}
	
	@RequestMapping("/showHomePage")
	public ModelAndView showHomePage() {
		
		ModelAndView model = new ModelAndView("index");
		try {
		List<FlightBean> flights = 	service.fetachall();
		
		model.addObject("flights",flights);
		} catch (FlightException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return model;
	}
	
	@RequestMapping("/update")
	public ModelAndView update(@ModelAttribute("employee") FlightBean flight,BindingResult result) {
		
		ModelAndView model = new ModelAndView("update");
		//try {
		System.out.println(flight);
		model.addObject("flight",flight);
		/*model.addObject("flights",flights);
		} catch (FlightException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return model;
	}
	@RequestMapping("/delete")
	public ModelAndView delete(@RequestParam("flightId")int id) {
		
		ModelAndView model = new ModelAndView("index");
		//try {
		System.out.println(id);
		
		try {
			System.out.println(service.udeleteflight(id));
			List<FlightBean> flights = 	service.fetachall();
			model.addObject("flights",flights);
		} catch (FlightException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*model.addObject("flights",flights);
		} catch (FlightException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return model;
	}
	
	@RequestMapping("/updateflight")
	public ModelAndView updateflight(@ModelAttribute("employee") FlightBean flight,BindingResult result) {
		
		ModelAndView model = new ModelAndView("index");
		//try {
		System.out.println(flight);
		try {
			System.out.println(service.updateflight(flight));
			List<FlightBean> flights = 	service.fetachall();
			
			model.addObject("flights",flights);
		} catch (FlightException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*model.addObject("flights",flights);
		} catch (FlightException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return model;
	}
}
