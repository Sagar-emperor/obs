package com.cg.flight.dao;

import java.util.List;

import com.cg.flight.bean.FlightBean;
import com.cg.flight.exception.FlightException;

public interface IFlightDAO {

	public List<FlightBean> fetachall() throws FlightException;
	public boolean updateflight(FlightBean flight) throws FlightException;
	public boolean udeleteflight(int id) throws FlightException;
}
