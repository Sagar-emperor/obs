package com.cg.flight.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.flight.bean.FlightBean;
import com.cg.flight.exception.FlightException;

@Repository
@Transactional
public class FlightDAOImpl implements IFlightDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<FlightBean> fetachall() throws FlightException {
		TypedQuery<FlightBean> query = entityManager.createQuery("SELECT d FROM FlightBean d", FlightBean.class);
		return query.getResultList();
	}

	@Override
	public boolean updateflight(FlightBean flight) throws FlightException {
		entityManager.merge(flight);
		return true;
	}

	@Override
	public boolean udeleteflight(int id) throws FlightException {
		 	FlightBean flight = entityManager.find(FlightBean.class, id);
		 	System.out.println(flight);
		 	entityManager.remove(flight);
		return true;
	}

	
}
