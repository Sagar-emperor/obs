package com.cg.flight.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="flightdetail")
public class FlightBean {

	@Id
	@Column(name="ID")
	private int flightId;
	
	@Column(name="name")
	private String flightName;
	
	@Column(name="fare")
	private double flightFare;
	
	@Column(name="seats")
	private int flightSeats;
	
	@Column(name="description")
	private String flightDescription;

	public String getFlightDescription() {
		return flightDescription;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public double getFlightFare() {
		return flightFare;
	}

	public void setFlightFare(double flightFare) {
		this.flightFare = flightFare;
	}

	public int getFlightSeats() {
		return flightSeats;
	}

	public void setFlightSeats(int flightSeats) {
		this.flightSeats = flightSeats;
	}

	public void setFlightDescription(String flightDescription) {
		this.flightDescription = flightDescription;
	}

	@Override
	public String toString() {
		return "FLightBean [flightId=" + flightId + ", flightName="
				+ flightName + ", flightFare=" + flightFare + ", flightSeats="
				+ flightSeats + ", flightDescription=" + flightDescription
				+ "]";
	}
	
}
