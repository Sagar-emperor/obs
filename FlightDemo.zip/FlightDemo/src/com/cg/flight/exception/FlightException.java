package com.cg.flight.exception;

public class FlightException extends Exception {
	public FlightException()
	{
		
	}
	public FlightException(String msg)
	{
		super(msg);
	}

}
