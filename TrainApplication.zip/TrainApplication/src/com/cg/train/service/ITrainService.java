package com.cg.train.service;

import com.cg.train.bean.TrainBean;
import com.cg.train.exception.TrainException;

public interface ITrainService {

	int addTrain(TrainBean bean) throws TrainException;

}
