package com.cg.train.service;

import com.cg.train.bean.TrainBean;
import com.cg.train.dao.ITrainDao;
import com.cg.train.dao.TrainDao;
import com.cg.train.exception.TrainException;

public class TrainService implements ITrainService{

	@Override
	public int addTrain(TrainBean bean) throws TrainException {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
