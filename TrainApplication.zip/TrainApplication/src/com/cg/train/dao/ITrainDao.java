package com.cg.train.dao;

import com.cg.train.bean.TrainBean;

public interface ITrainDao {

	int addTrain(TrainBean bean);

}
