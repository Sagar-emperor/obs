package com.cg.train.dao;

import com.cg.train.bean.TrainBean;

public class TrainDao implements ITrainDao{

	@Override
	public int addTrain(TrainBean bean) {
		// TODO Auto-generated method stub
		return 0;
	}

}
