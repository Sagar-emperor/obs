package com.cg.train.exception;

public class TrainException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1407318303842072634L;

	public TrainException(String message) {
		super(message);

}
}
