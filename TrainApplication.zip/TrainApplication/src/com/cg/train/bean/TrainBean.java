package com.cg.train.bean;

public class TrainBean {

	
}
