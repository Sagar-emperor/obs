package com.capgemini.magicworld.dao;

public class QueryMapper {
	public static final String SHOWALL = "SELECT showId,showName,location,date,availableSeats,price,FROM ShowDetails";
	public static final String UPDATE="UPDATE ShowDetails SET availableseats=availableseats-? WHERE showId = ?";
}
