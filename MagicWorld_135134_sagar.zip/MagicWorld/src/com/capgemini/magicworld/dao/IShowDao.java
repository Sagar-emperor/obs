package com.capgemini.magicworld.dao;

import java.util.List;

import com.capgemini.magicworld.dto.ShowBean;
import com.capgemini.magicworld.exception.ShowException;


public interface IShowDao {
	public List<ShowBean> getShowDetails() throws ShowException;
	public void updateSeats(int availableseats,String showId) throws ShowException;
}
