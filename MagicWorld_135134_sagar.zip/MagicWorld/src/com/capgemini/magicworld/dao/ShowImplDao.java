package com.capgemini.magicworld.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.magicworld.dto.ShowBean;
import com.capgemini.magicworld.exception.ShowException;
import com.capgemini.magicworld.util.DbConnection;
/**
 *  Author : SAGAR
 *  Class Name : ShowImplDAO 
 *  Package :com.capgemini.magicworld.dao;
 *  Date : Sep 25, 2017
 */



public class ShowImplDao implements IShowDao{
	PreparedStatement preparedStatement = null;
	Connection conn = null;
	ResultSet resultSet = null;
	
	// ---------------- 1. Get all Show details ---------------
		/**************************************************************
		 * - Method Name : getShowDetails() 
		 * - Input Parameters : - 
		 * - Return Type :List<ShowBean> 
		 * - Throws : ShowException 
		 * - Author : SAGAR
		 * - Creation Date : Sep 25, 2017 
		 * - Description : Retrieval of show details
		 *************************************************************/
	@Override
	public List<ShowBean> getShowDetails() throws ShowException {
		List<ShowBean> list = new ArrayList<ShowBean>();
		ShowBean bean = new ShowBean();
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(QueryMapper.SHOWALL);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()){
				bean = new ShowBean();
				bean.setShowId(resultSet.getString(1));
				bean.setShowName(resultSet.getString(2));
				bean.setLocation(resultSet.getString(3));
				bean.setDate(resultSet.getDate(4).toLocalDate());
				
				bean.setAvailableSeats(resultSet.getInt(5));
				bean.setPrice(resultSet.getDouble(6));
				
				list.add(bean);
				
		}
		}
		catch (SQLException e) {
			throw new ShowException("bean/sql/ERROR:"
					+ e.getMessage());
		}catch (Exception e) {
			throw new ShowException("ERROR:"+ e.getMessage());
		}finally {
			try{
				if(conn!=null){
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			}catch(Exception e){
				throw new ShowException(
						"Could not close the connection");
			}
		}
		return list;
		
		
		
	}
	@Override
	public void updateSeats(int availableseats, String showId)	throws ShowException {
		// TODO Auto-generated method stub
		try {
			conn = DbConnection.getConnection();
			
			preparedStatement = conn.prepareStatement(QueryMapper.UPDATE);
			preparedStatement.setInt(1, availableseats);
			preparedStatement.setString(2, showId);
			preparedStatement.executeUpdate();
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			
			try {
				preparedStatement.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

}
