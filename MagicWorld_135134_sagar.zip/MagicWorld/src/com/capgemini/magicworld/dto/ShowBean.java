package com.capgemini.magicworld.dto;

import java.time.LocalDate;

public class ShowBean {
	private String showId;
	private String showName;
	private String location;
	private LocalDate date;
	private int availableSeats;
	private double price;

	



	public String getShowId() {
		return showId;
	}





	public void setShowId(String showId) {
		this.showId = showId;
	}





	public String getShowName() {
		return showName;
	}





	public void setShowName(String showName) {
		this.showName = showName;
	}





	public String getLocation() {
		return location;
	}





	public void setLocation(String location) {
		this.location = location;
	}





	public LocalDate getDate() {
		return date;
	}





	public void setDate(LocalDate date) {
		this.date = date;
	}





	public int getAvailableSeats() {
		return availableSeats;
	}





	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}





	public double getPrice() {
		return price;
	}





	public void setPrice(double price) {
		this.price = price;
	}





	public ShowBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
