package com.capgemini.magicworld.service;

import java.util.List;

import com.capgemini.magicworld.dto.ShowBean;
import com.capgemini.magicworld.exception.ShowException;


public interface IShowService {

	public List<ShowBean> getShowDetails() throws ShowException;

	public void updateSeats(int availableseats, String showId) throws ShowException;

}
