package com.capgemini.magicworld.service;

import java.util.List;

import com.capgemini.magicworld.dao.IShowDao;
import com.capgemini.magicworld.dao.ShowImplDao;
import com.capgemini.magicworld.dto.ShowBean;
import com.capgemini.magicworld.exception.ShowException;




public class ShowImplService implements IShowService{
	IShowDao dao = new ShowImplDao();
	@Override
	public List<ShowBean> getShowDetails() throws ShowException {
		// TODO Auto-generated method stub
		List<ShowBean> list= dao.getShowDetails();
		return list;
	}
	@Override
	public void updateSeats(int availableseats, String showId)
			throws ShowException {
		// TODO Auto-generated method stub
		try {
			dao.updateSeats(availableseats, showId);
		} catch (ShowException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
