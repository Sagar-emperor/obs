package com.capgemini.magicworld.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.magicworld.dto.ShowBean;
import com.capgemini.magicworld.exception.ShowException;
import com.capgemini.magicworld.service.IShowService;



/**
 * Servlet implementation class MagicServlet
 *  Author : SAGAR
 *  Class Name : ShowControllerServlet 
 *  Package :com.capgemini.magicworld.controller;
 *  Date : sep 25, 2017
 */
@WebServlet("*.obj")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		IShowService mservice = null;
		ShowBean show = null;
		String target = "";
		HttpSession session = request.getSession(true);
		show = new ShowBean();
		String showId = null;
		String targetShow = "showdetails.jsp";
		String targetBook = "bookNow.jsp";
		String targetSuccess = "success.jsp";
		String targetError = "error.jsp";
		String targetHome = "index.jsp";

		String path = request.getServletPath().trim();
		
		switch (path) {
		
		case "/showdetails.obj":
			List<ShowBean> slist = null;
			try{
				slist = mservice.getShowDetails();
			}catch (ShowException e) {
				session.setAttribute("error", e.getMessage());
				target = targetError;
			}
			if(!slist.isEmpty()){
				session.setAttribute("error",null);
				session.setAttribute("slist",slist);
				target = targetShow;
			}else {
				session.setAttribute("slist",null);
				session.setAttribute("error","Sorry No data Found!");
				target = targetShow;
			}
			break;	
		
		case "/bookNow.obj":
			session.setAttribute("name", request.getParameter("name"));
			session.setAttribute("price", request.getParameter("price"));
			session.setAttribute("availableseats", request.getParameter("availableseats"));
			session.setAttribute("showid",request.getParameter("showid"));
			
			target=targetBook;
			break;
			
		case "/success.obj":
			session.setAttribute("custname", request.getParameter("customername"));
			session.setAttribute("mobnumber",request.getParameter("mobilenumber"));
			session.setAttribute("book",request.getParameter("availableseats"));
			int availableseats=Integer.parseInt(request.getParameter("availableseats"));
		
			String ShowId=(String)session.getAttribute("showid");
			
			try {
				mservice.updateSeats(availableseats,showId);
			} catch (ShowException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
			
			target=targetSuccess;
			break;
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
		
	
		}
}
	
