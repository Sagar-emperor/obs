package com.cg.flightapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.flightapplication.bean.FlightBean;
import com.cg.flightapplication.service.IFlightService;


@Controller
public class FlightController {

	@Autowired
	IFlightService flightservice;
	
	@RequestMapping("/viewAll")
	public ModelAndView viewAll() {
		
		List<FlightBean> list = flightservice.viewAll();
		ModelAndView mv = new ModelAndView("Home");
		mv.addObject("flightList",list);
		
		return mv;
		
	}
	@RequestMapping("/delete")
	public ModelAndView delete(@RequestParam("id") long id)
	{
		
		FlightBean bean =  flightservice.deleteFlight(id);
		List<FlightBean> list = flightservice.viewAll();
		ModelAndView mv = new ModelAndView("Home");
		mv.addObject("flightList",list);
		
		return mv;
	}
	
	@RequestMapping("/viewUpdate")
	public ModelAndView update(@RequestParam("id") long id)
	{
		FlightBean bean = flightservice.getFlight(id);
		ModelAndView mv = new ModelAndView("ViewUpdate");
		mv.addObject("flight", bean);
		return mv;
	}
	
	@RequestMapping("/update")
	public ModelAndView updateFinal(@ModelAttribute("bean") FlightBean bean)
	{
		bean.setFlightDescription("Luxurious");
		FlightBean newBean = flightservice.update(bean);
		//newBean.setFlightDescription("Luxurious");
		ModelAndView mv = new ModelAndView("success");
		mv.addObject("flight", newBean);
		return mv;
		
	}
	
}
