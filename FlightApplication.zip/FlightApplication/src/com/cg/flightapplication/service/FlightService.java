package com.cg.flightapplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.flightapplication.bean.FlightBean;
import com.cg.flightapplication.dao.IFlightDAO;
@Service
public class FlightService implements IFlightService {
	
	@Autowired
	IFlightDAO flightDao;

	@Override
	public List<FlightBean> viewAll() {
		
		return flightDao.viewAll();
	}

	@Override
	public FlightBean deleteFlight(long id) {
		
		return flightDao.deleteFlight(id);
	}

	@Override
	public FlightBean getFlight(long id) {
	
		return flightDao.getFlight(id);
	}

	@Override
	public FlightBean update(FlightBean bean) {
		// TODO Auto-generated method stub
		return flightDao.update(bean);
	}

}
