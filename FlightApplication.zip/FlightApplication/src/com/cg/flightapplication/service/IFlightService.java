package com.cg.flightapplication.service;

import java.util.List;

import com.cg.flightapplication.bean.FlightBean;

public interface IFlightService {
	public List<FlightBean> viewAll();
	public FlightBean deleteFlight(long id);
	public FlightBean getFlight(long id);
	public FlightBean update(FlightBean bean);
}
