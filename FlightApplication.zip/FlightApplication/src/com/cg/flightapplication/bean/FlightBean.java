package com.cg.flightapplication.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="flight")
public class FlightBean {

	@Id
	@Column(name = "FLIGHT_ID")
	private long flightId;
	@Column(name = "FLIGHT_NAME")
	private  String flightName;
	@Column(name = "FLIGHT_FARE")
	private long flightFare;
	@Column(name = "FLIGHT_SEATS")
	private int flightSeats;
	@Column(name = "FLIGHT_DISCRIPTION")
	private String flightDescription;
	public long getFlightId() {
		return flightId;
	}
	
	public FlightBean()
	{
		super();
	}
	public FlightBean(long flightId, String flightName, long flightFare,
			int flightSeats, String flightDescription) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.flightFare = flightFare;
		this.flightSeats = flightSeats;
		this.flightDescription = flightDescription;
	}
	public void setFlightId(long flightId) {
		this.flightId = flightId;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public long getFlightFare() {
		return flightFare;
	}
	public void setFlightFare(long flightFare) {
		this.flightFare = flightFare;
	}
	public int getFlightSeats() {
		return flightSeats;
	}
	public void setFlightSeats(int flightSeats) {
		this.flightSeats = flightSeats;
	}
	public String getFlightDescription() {
		return flightDescription;
	}
	public void setFlightDescription(String flightDescription) {
		this.flightDescription = flightDescription;
	}
	
	
	
}
