package com.cg.flightapplication.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.flightapplication.bean.FlightBean;



@Repository
@Transactional
public class FlightDAO implements IFlightDAO {
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<FlightBean> viewAll() {
		
		TypedQuery<FlightBean>	query=	entityManager.createQuery("from FlightBean",FlightBean.class);

		return query.getResultList();
	}

	@Override
	public FlightBean deleteFlight(long id) {
		
		FlightBean bean = entityManager.find(FlightBean.class, id);
		if(bean != null)
		{
			
			entityManager.remove(bean);
			
		}
		
			return bean;
	}

	@Override
	public FlightBean getFlight(long id) {
		return entityManager.find(FlightBean.class ,id);
	}

	@Override
	public FlightBean update(FlightBean bean) {
		FlightBean newBean = entityManager.merge(bean);
		return newBean;
	}

}
