package com.cg.flightapplication.dao;

import java.util.List;

import com.cg.flightapplication.bean.FlightBean;

public interface IFlightDAO {
	
	public List<FlightBean> viewAll();
	public FlightBean deleteFlight(long id);
	public FlightBean getFlight(long id);
	public FlightBean update(FlightBean bean);

}
