package com.capgemini.mw.service;

import java.util.List;

import com.capgemini.mw.bean.MovieBean;
import com.capgemini.mw.exception.MovieException;


public interface MovieService {
	
	public List<MovieBean> getAllMovies()throws MovieException; 
	
	public void makeBooking(int seatBook, String showId)throws MovieException;

}
