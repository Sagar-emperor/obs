package com.capgemini.mw.dao;

import java.util.List;


import com.capgemini.mw.bean.MovieBean;
import com.capgemini.mw.exception.MovieException;



public interface MovieDAO {
	
	public List<MovieBean> getAllMovies()throws MovieException;
	public void makeBooking(int seatBook, String showId)throws MovieException;

}
