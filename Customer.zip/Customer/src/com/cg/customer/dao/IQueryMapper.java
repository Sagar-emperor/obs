package com.cg.customer.dao;

public class IQueryMapper {
	
	public static String insertDetails = "INSERT INTO customer VALUES(?,?,?,?)";

}
