package com.cg.customer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;


import java.sql.SQLException;

import com.cg.customer.bean.CustomerBean;
import com.cg.customer.exception.CustomerException;
import com.cg.customer.util.DBConnection;

public class CustomerDao implements ICustomerDao {

	Connection conn=null;
	PreparedStatement ps = null;
	
	
	@Override
	public boolean addCustomer(CustomerBean bean) {
		// TODO Auto-generated method stub
		
		try {
			
				conn = DBConnection.getConnection();
				ps = conn.prepareStatement(IQueryMapper.insertDetails);
				ps.setString(1, bean.getCustomerName());
				ps.setString(2, bean.getMobileNumber());
				ps.setString(3, bean.getUserName());
				ps.setString(4, bean.getPassword());
				int exe = ps.executeUpdate();
				System.out.println("983217490184"+exe);
				if( exe <= 0){
					
					throw new CustomerException("customer details not inserted");
					
				}
			
				else
					return true;
			
		} catch (CustomerException e) {
			// TODO Auto-generated catch block
				e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
		
	}

}
