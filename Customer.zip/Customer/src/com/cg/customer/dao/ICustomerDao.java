package com.cg.customer.dao;

import com.cg.customer.bean.CustomerBean;

public interface ICustomerDao {
	
	public boolean addCustomer(CustomerBean bean);

}
