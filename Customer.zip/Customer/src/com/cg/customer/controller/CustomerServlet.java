package com.cg.customer.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.customer.bean.CustomerBean;
import com.cg.customer.service.CustomerService;
import com.cg.customer.service.ICustomerService;

/**
 * Servlet implementation class CustomerServlet
 */
@WebServlet("*.obj")
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		doPost(request,response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		CustomerBean cbean = new CustomerBean();
		ICustomerService customerService = new CustomerService();
		String target = " ";
		
		HttpSession session = request.getSession(true);
		
		String targetAdd = "Register.jsp";
		String targetHome = "customerHome.jsp";
		String targetBill = "bill.jsp";
		String targetSuccess = "success.jsp";
		
		String path = request.getServletPath().trim();

		
		switch(path){
		
			case "/index.obj":
				
				session.setAttribute("error", null);
				session.setAttribute("customer", null);
				target = targetAdd;
				break;
			
			case "/AddCustomer.obj":
				
				target = targetAdd;
				break;
			
			case "/customerHome.obj":
				
				String name = request.getParameter("uName");
				String mobile = request.getParameter("mobileNumber");
				String cname = request.getParameter("customerName");
				String pass = request.getParameter("password");
				
				cbean.setCustomerName(cname);
				cbean.setMobileNumber(mobile);
				cbean.setPassword(pass);
				cbean.setUserName(name);
				System.out.println(cbean);
				customerService.addCustomer(cbean);
				System.out.println("done");
				session.setAttribute("uname", name);
				session.setAttribute("mobile", mobile);
				
				
				
				target = targetHome;
				break;
		
			case "/bill.obj":
				
				target = targetBill;
				break;
				
			case "/success.obj":
				
				String am = request.getParameter("amountPay");
				double total = 1000 - Double.parseDouble(am) ;
				session.setAttribute("total", total);
				target = targetSuccess;
				break;
				
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
		
	}

}
