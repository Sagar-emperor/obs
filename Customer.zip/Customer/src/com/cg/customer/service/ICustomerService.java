package com.cg.customer.service;

import com.cg.customer.bean.CustomerBean;

public interface ICustomerService {
	
	public boolean addCustomer(CustomerBean bean);


}
