package com.cg.customer.service;

import com.cg.customer.bean.CustomerBean;
import com.cg.customer.dao.CustomerDao;
import com.cg.customer.dao.ICustomerDao;

public class CustomerService implements ICustomerService {

	ICustomerDao customerDao = new CustomerDao();
	
	@Override
	public boolean addCustomer(CustomerBean bean) {

		return customerDao.addCustomer(bean);
		
	}

}
