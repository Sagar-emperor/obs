CREATE TABLE customer(
customerName varchar(30),
userName varchar(30) PRIMARY KEY,
password varchar(30),
mobileNumber varchar(30)
);